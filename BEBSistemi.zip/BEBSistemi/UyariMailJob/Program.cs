﻿using Beb.Mail;
using Beb.Models;
using Beb.UOW;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Configuration;
using System.Text;
using System.Threading.Tasks;

namespace UyariMailJob
{
    class Program
    {
       static Beb.Models.BEBDb db;
        static IUnitOfWork _uow;
         static  void Main(string[] args)
        {
         
            _uow = new UnitOfWork();
            db = _uow.basvuruRepo.GetContext();

            SonGunHesaplamalari(27, 12);
            SonGunHesaplamalari(30, 15);
        } 
        
        public static void SonGunHesaplamalari(int btip1, int btip2)
        {
            string _adminMail1 = ConfigurationSettings.AppSettings["AdminMailAdresi1"];
            string _adminMail2 = ConfigurationSettings.AppSettings["AdminMailAdresi2"];

            IMailService mail = new MailService();
           
            List<mailJob> sonuc = new List<mailJob>();
            try
            {
              
                string sqL = "SELECT bas.TCKIMLIK, bas.ADSOYAD, bas.TEL, dbs.YONEPOSTA,dbs.DBSID, (SELECT aciklama FROM BilgiEdinmeSozluk WHERE id = bas.KONU) AS KONU, " +
             "bas.ADRES, (SELECT explanation FROM Sozluk WHERE id = bas.IL) AS IL, bas.BASVURUICERIK, (SELECT CASE bas.BASVURUCEVAP WHEN 0 THEN 'Elektronik' WHEN 1 THEN 'Yazılı' END) AS BASVURUCEVAP, " +
              "beb.ACIKLAMA, bas.TARIH " +
             "FROM BSB_BEB beb, BSB_DBS dbs, BSB_BASVURU bas " +
             "WHERE " +
              "bas.BASVURUID = beb.BASVURUID and beb.BEBID = dbs.BEBID and(beb.DURUM = 'BDUR03' or beb.DURUM = 'BDUR04') " +
              "and dbs.IADE != 1 and dbs.BASVURUCEVAPTARIHI is null and beb.KAPANISTARIHI is null " +
              "and beb.BASVURUTIPI in ('BTIP01', 'BTIP02') " +
              "and ((beb.BASVURUTIPI = 'BTIP01' AND(beb.KAPANISTARIHI is null AND(datediff(day, bas.LOGISLEMTARIH, GETDATE()) = " + btip1 + "))) " +
              "or (beb.BASVURUTIPI = 'BTIP02' AND(beb.KAPANISTARIHI is null AND(dbo.getDiffDateWithRestDay(bas.LOGISLEMTARIH, GETDATE()) = " + btip2 + "))) )";

                sonuc = db.Database.SqlQuery<mailJob>(sqL).ToList(); 

                foreach(mailJob item in sonuc)
                {
                    string strSubject="", strMessageBody = "";
                    mailOlustur(item,ref strSubject, ref strMessageBody);


                    mail.SendMail(item.YONEPOSTA, strSubject, strMessageBody);
                }


                mail.SendMail(_adminMail1, "BEB Bilgilendirme", "BEB uyarı maili atma işlemi başarılı");

                mail.SendMail(_adminMail2, "BEB Bilgilendirme", "BEB uyarı maili atma işlemi başarılı");

            }
            catch (Exception ex)
            {
                mail.SendMail(_adminMail1, "BEB Bilgilendirme Hata", "BEB uyarı maili gönderiminde hata oluştu: " + ex.Message + " " + ex.InnerException);

                mail.SendMail(_adminMail2, "BEB Bilgilendirme Hata", "BEB uyarı maili gönderiminde hata oluştu: " + ex.Message + " " + ex.InnerException);
            }

        } 
        public static void mailOlustur(mailJob mailjob , ref string strSubject, ref string strMessageBody)
        {
            string _urlBase = ConfigurationSettings.AppSettings["UrlBase"];


            strSubject = "BEB Bilgilendirme ";
            string urladres = $"{_urlBase}Dbs/DBSDetay/" + mailjob.DBSID;
 

            strMessageBody = "Aşağıda verilen başvurunun süresi geçmek üzeredir. En kısa sürede cevaplanması hususu arz olunur.<br><br><br>";


            strMessageBody += "<html><head><title>BEB</title><style type='text/css'>td {padding-left:2px; font-family:Verdana; font-size:8pt; border-width:1px; border-style:solid; border-color:#BEC1E2;} .thead { background-color:#695DB3; color:#FFFFFF; font-size:7pt; font-weight:bold; } .log { border-width:0px; font-family:Verdana; font-size:7pt; } </style></head><body><p>&nbsp;</p><table style='border-width:0px; border-style:solid; border-color:#BEC1E2; width:90%;'><tr><td width='100%' align='center' colspan='2' class='thead'>" + strSubject + "</td></tr>";
            strMessageBody += "<tr><td width='25%' align='right'>TC Kimlik No : </td><td width='75%'>" + mailjob.TCKIMLIK + "</td></tr>";
            strMessageBody += "<tr><td width='25%' align='right'>Adı Soyadı : </td><td width='75%'>" + mailjob.ADSOYAD + "</td></tr>";
            strMessageBody += "<tr><td width='25%' align='right'>Başvuru Tarihi : </td><td width='75%'>" + String.Format("{0:dd.MM.yyyy}", mailjob.TARIH) + "</td></tr>";
            strMessageBody += "<tr><td width='25%' align='right'>Telefon : </td><td width='75%'>" + mailjob.TEL + "</td></tr>";
            strMessageBody += "<tr><td width='25%' align='right'>E-Posta : </td><td width='75%'>" + mailjob.EMAIL + "</td></tr>";
            strMessageBody += "<tr><td width='25%' align='right'>Konu : </td><td width='75%'>" + mailjob .KONU+ "</td></tr>";
            strMessageBody += "<tr><td width='25%' align='right'>Adres : </td><td width='75%'>" + mailjob.ADRES + "</td></tr>";
            strMessageBody += "<tr><td width='25%' align='right'>İl : </td><td width='75%'>" + mailjob.IL + "</td></tr>";
            strMessageBody += "<tr><td width='25%' align='right'>Başvuru İçeriği : </td><td width='75%'>" + mailjob.BASVURUICERIK + "</td></tr>";
            strMessageBody += "<tr><td width='25%' align='right'>Başvuru Cevabı : </td><td width='75%'>" + mailjob.BASVURUCEVAP + "</td></tr>";
            strMessageBody += "<tr><td width='25%' align='right'>Bağlantı : </td><td width='75%'>&nbsp;<a href=' " + urladres + "'>Bildirimi Göster</a></td></tr>";
            strMessageBody += "</table>";
            strMessageBody += "</body></html>";
        }

    }
}
