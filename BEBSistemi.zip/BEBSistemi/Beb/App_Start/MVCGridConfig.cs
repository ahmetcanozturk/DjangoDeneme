﻿[assembly: WebActivatorEx.PreApplicationStartMethod(typeof(Beb.App_Start.MVCGridConfig), "RegisterGrids")]

namespace Beb.App_Start
{
    using Beb.Models;
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Web;
    using MVCGrid.Models;
    using MVCGrid.Web;

    public static class MVCGridConfig
    {
        public static void RegisterGrids()
        {
            var db = new BEBDb();



            GridDefaults gridDefaults = new GridDefaults()
            {
                Sorting = true,
                DefaultSortColumn = "Oncelik",
                DefaultSortDirection = SortDirection.Asc,
                Filtering = true,
                ProcessingMessage = "Bekleyiniz",
                PreviousButtonCaption = "Önceki",
                NextButtonCaption = "Sonraki",
                SummaryMessage = "Gösterilen: {0} - {1} / {2}",
                NoResultsMessage = "Kayıt yok!",
                Paging = true,
                ItemsPerPage = 20,
                MaxItemsPerPage = 100,
                AllowChangingPageSize = true
            };

            MVCGridDefinitionTable.Add("BEBGenelRaporGrid", new MVCGridBuilder<BEBGenelRapor>(gridDefaults) 
              
                .WithAuthorizationType(AuthorizationType.AllowAnonymous)
                //.WithSorting(sorting: true, defaultSortColumn: "SPKyaIletimTarihi", defaultSortDirection: SortDirection.Asc)
                .WithPaging(paging: true, itemsPerPage: 20, allowChangePageSize: true, maxItemsPerPage: 100)
               // .RemoveRenderingEngine("export").AddRenderingEngine("export", typeof(ExcelRenderingEngine))

                .AddColumns(cols =>
                {
      
                    cols.Add().WithColumnName("BasvuruNo").WithHeaderText("BasvuruNo").WithSorting(true)
                        .WithVisibility(true, true)
                        .WithFiltering(true)
                        .WithValueExpression(i => i.BasvuruNo == null ? " " : i.BasvuruNo.ToString());
                    cols.Add().WithColumnName("Basvuran").WithHeaderText("Basvuran").WithSorting(true)
                       .WithVisibility(true, true)
                       .WithFiltering(true)
                       .WithValueExpression(i => i.Basvuran == null ? " " : i.Basvuran.ToString());
                    cols.Add().WithColumnName("BasvuruKonusu").WithHeaderText("BasvuruKonusu").WithSorting(true)
                      .WithVisibility(true, true)
                      .WithFiltering(true)
                      .WithValueExpression(i => i.BasvuruKonusu == null ? " " : i.BasvuruKonusu.ToString());
                    cols.Add().WithColumnName("BasvuruTipi").WithHeaderText("BasvuruTipi").WithSorting(true)
                   .WithVisibility(true, true)
                   .WithFiltering(true)
                   .WithValueExpression(i => i.BasvuruTipi == null ? " " : i.BasvuruTipi.ToString());
                    cols.Add().WithColumnName("CimereBasvuruTarihi").WithHeaderText("CimereBasvuruTarihi").WithSorting(true)
                .WithVisibility(true, true)
                .WithFiltering(true)
                .WithValueExpression(i => i.CimereBasvuruTarihi == null ? " " :((DateTime) i.CimereBasvuruTarihi).ToShortDateString());
                    cols.Add().WithColumnName("SPKyaIletimTarihi").WithHeaderText("SPKyaIletimTarihi").WithSorting(true)
               .WithVisibility(true, true)
               .WithFiltering(true)
               .WithValueExpression(i => i.SPKyaIletimTarihi == null ? " " : ((DateTime)i.SPKyaIletimTarihi).ToShortDateString());
                    cols.Add().WithColumnName("DaireyeSevkTarihi").WithHeaderText("DaireyeSevkTarihi").WithSorting(true)
             .WithVisibility(true, true)
             .WithFiltering(true)
             .WithValueExpression(i => i.DaireyeSevkTarihi==null ? " " : ((DateTime)i.DaireyeSevkTarihi).ToShortDateString());
                    cols.Add().WithColumnName("SevkEdilenDaire").WithHeaderText("SevkEdilenDaire").WithSorting(true)
           .WithVisibility(true, true)
           .WithFiltering(true)
           .WithValueExpression(i => i.SevkEdilenDaire == null ? " " : i.SevkEdilenDaire.ToString());
                    cols.Add().WithColumnName("SevkEdilenUzman").WithHeaderText("SevkEdilenUzman").WithSorting(true)
          .WithVisibility(true, true)
          .WithFiltering(true)
          .WithValueExpression(i => i.SevkEdilenUzman == null ? " " : i.SevkEdilenUzman.ToString());

                    cols.Add().WithColumnName("UzmaninDaireyeGonderdiğiTarih").WithHeaderText("UzmaninDaireyeGonderdiğiTarih").WithSorting(true)
       .WithVisibility(true, true)
       .WithFiltering(true)
       .WithValueExpression(i => i.UzmaninDaireyeGonderdigiTarih == null ? " " : ((DateTime)i.UzmaninDaireyeGonderdigiTarih).ToShortDateString());

                    cols.Add().WithColumnName("DaireninCevapladigiTarih").WithHeaderText("DaireninCevapladigiTarih").WithSorting(true)
      .WithVisibility(true, true)
      .WithFiltering(true)
      .WithValueExpression(i => i.DaireninCevapladigiTarih == null ? " " : ((DateTime)i.DaireninCevapladigiTarih).ToShortDateString());
                    cols.Add().WithColumnName("KidKapatmaTarihi").WithHeaderText("KidKapatmaTarihi").WithSorting(true)
  .WithVisibility(true, true)
  .WithFiltering(true)
  .WithValueExpression(i => i.KidKapatmaTarihi == null ? " " : ((DateTime)i.KidKapatmaTarihi).ToShortDateString());
                }) 
                
                .WithRetrieveDataMethod((context) =>
                {
                    var result = new QueryResult<BEBGenelRapor>();


                    using (db = new BEBDb())
                    {
                        var options = context.QueryOptions;

                        List<BEBGenelRapor> liste = null;
                        string sql = "";

                        sql = "select bas.BASVURUID as BasvuruNo, " +
                                        "bas.ADSOYAD as Basvuran," +
                                        "konuSozluk.aciklama as BasvuruKonusu," +
                                        "sozluk.explanation as BasvuruTipi ," +
                                        "bas.LOGISLEMTARIH as CimereBasvuruTarihi, " +
                                        "bas.TARIH as SPKyaIletimTarihi, " +
                                        "dbs.YONTARIHI as DaireyeSevkTarihi," +
                                        "daire.explanation as SevkEdilenDaire,  " +
                                        "gorevli.ADSOYAD as SevkEdilenUzman, " +
                                        "gorevli.ISLEMTARIHI as UzmaninDaireyeGonderdiğiTarih," +
                                        "dbs.BASVURUCEVAPTARIHI as DaireninCevapladigiTarih, " +
                                        "beb.KAPANISTARIHI as KidKapatmaTarihi " +
                                        "from BSB_BASVURU bas left join BSB_BEB beb on bas.BASVURUID = beb.BASVURUID " +
                                        "left join BSB_DBS dbs on beb.BEBID = dbs.BEBID " +
                                        "left join BSB_DBS_GOREVLI gorevli on dbs.DBSID = gorevli.DBSID " +
                                        "left join BilgiEdinmeSozluk konuSozluk on konuSozluk.id = bas.KONU " +
                                        "left join Sozluk sozluk on sozluk.id = beb.BASVURUTIPI " +
                                        "left join Sozluk daire on daire.id = dbs.YONBIRIM " +
                                         //"where bas.TARIH >= '" + (DateTime.Parse(tarih1)).ToString("MM.dd.yyyy") + " 00:00:00.000" + "' AND bas.TARIH <= '" + (DateTime.Parse(tarih2)).ToString("MM.dd.yyyy") + " 23:59:59.000' " +
                                         "order by bas.LOGISLEMTARIH desc";

                        liste = db.Database.SqlQuery<BEBGenelRapor>(sql).ToList();


                        //if (!String.IsNullOrWhiteSpace(options.SortColumnName))
                        //{
                        //    switch (options.SortColumnName.ToLower())
                        //    {
                        //        case "kimlikno":
                        //            query = options.SortDirection == SortDirection.Asc ? query.OrderBy(p => p.KimlikNo) : query.OrderByDescending(p => p.KimlikNo);
                        //            break;
           

                        //    }
                        //}


                        result.TotalRecords = liste.Count();
                        if (options.GetLimitOffset().HasValue)
                        {
                            liste = liste.Skip(options.GetLimitOffset().Value).Take(options.GetLimitRowcount().Value).ToList();
                        }


                        result.Items = liste;

                    }

                    return result;
                })
            );
        }
    }
}