﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Beb.Utilities
{
    public class MersisSirket
    {
        public Guid SirketId { get; set; }
        public string Unvani { get; set; }
    }
}