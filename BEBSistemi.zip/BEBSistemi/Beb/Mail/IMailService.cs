﻿using Beb.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Beb.Mail
{
   public interface IMailService
    {
        string MailOlustur(string aciklama, string islemYapanKullaniciTamAd, string yapilanIslemAciklama);
         bool SendMail(string to, string strSubject, string strMessage);
        bool DisariSendMail(string to, string strSubject, string strMessage ,List<UploadedFile> files);
        
       void DbsMailIcerik(Basvuru basvuru, string ekMesaj,string tur, decimal turId, ref string strSubject, ref string strMessageBody);
        
        }
}
