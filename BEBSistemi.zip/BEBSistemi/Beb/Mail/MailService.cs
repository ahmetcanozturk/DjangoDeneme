﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Web;
using System.Web.Configuration;
using Beb.Models;

namespace Beb.Mail
{
    public class MailService :IMailService
    {
        private string _errorMessage;
        private string _mailAktif;
        private string _mailPassword;
        private string _mailServer;
        private string _mailUser;
        public string _senderAddress { get; set; }
        public string _senderDisplayName { get; set; } 
        private string _testOrtami; 

        private string _disarimailAktif;
        private string _disarimailPassword;
        private string _disarimailServer;
        private string _disarimailUser;
        public string _disarisenderAddress { get; set; }
        public string _disarisenderDisplayName { get; set; }
        private string _disaritestOrtami;
        private string _urlBase;


        public MailService()
        {
            InitVariable();
        }

        private void InitVariable()
        {
            _mailServer = Singleton.GetConfigSetting("MailServer", null);
            _mailUser = Singleton.GetConfigSetting("MailUser", null);
            _mailPassword = Singleton.GetConfigSetting("MailPassword", null);

            _senderAddress = WebConfigurationManager.AppSettings["senderAddress"];
            _senderDisplayName = WebConfigurationManager.AppSettings["senderDisplayName"];

            _errorMessage = "";

            _mailAktif = Singleton.GetConfigSetting("MailAktif", "false");
            _testOrtami = Singleton.GetConfigSetting("TestOrtami", "true");
            _urlBase = WebConfigurationManager.AppSettings["UrlBase"]; 

            _disarimailServer = Singleton.GetConfigSetting("DisariMailServer", null);
            _disarimailUser = Singleton.GetConfigSetting("DisariMailUser", null);
            _disarimailPassword = Singleton.GetConfigSetting("DisariMailPassword", null);

            _disarisenderAddress = WebConfigurationManager.AppSettings["DisarisenderAddress"];
            _disarisenderDisplayName = WebConfigurationManager.AppSettings["DisarisenderDisplayName"];

            _errorMessage = "";

            _disarimailAktif = Singleton.GetConfigSetting("DisariMailAktif", "false");
            _disaritestOrtami = Singleton.GetConfigSetting("DisariTestOrtami", "true");
            //_urlBase = WebConfigurationManager.AppSettings["UrlBase"]; 
           
            
        }

        public string MailOlustur(string aciklama, string islemYapanKullaniciTamAd, string yapilanIslemAciklama)
        {
            throw new NotImplementedException();
        }

        public bool SendMail(string to, string strSubject, string strMessage)
        {
            //ekelenecek list List<UploadedFile> file
            if (to == null)
            {
                return false;
            }

            using (var msg = new MailMessage())
            {

                var mFrom = new MailAddress(_senderAddress, "Beb Bilgilendirme");
                msg.From = mFrom;

                if (_testOrtami == "true")
                {
                    return false;
                }
                else
                {
                    msg.To.Add(to);
                    
                }

                msg.Subject = strSubject;
                msg.IsBodyHtml = true;
                msg.Body = strMessage;

                //if (file != null)
                //{
                    //Attachments eklemeye dikkat
                    //msg.Attachments.Add(file);
                //}

                using (var smtpClient = new SmtpClient(_mailServer, 25))
                {
                    smtpClient.EnableSsl = false;
                    smtpClient.UseDefaultCredentials = false;
                    smtpClient.Credentials = new NetworkCredential(_mailUser, _mailPassword, "spkdom");
                    smtpClient.Send(msg);
                }

            }

            return true;


        }
        public bool DisariSendMail(string to, string strSubject, string strMessage, List<UploadedFile> files)
        {
            //ekelenecek list List<UploadedFile> file
            if (to == null)
            {
                return false;
            }

            using (var msg = new MailMessage())
            {

                var mFrom = new MailAddress(_disarisenderAddress, "Beb Bilgilendirme");
                msg.From = mFrom;

                //if (_testOrtami == "true")
                //{
                //}
                //else
                //{
                msg.To.Add(to);

                //}

                msg.Subject = strSubject;
                msg.IsBodyHtml = true;
                msg.Body = strMessage;

                if (files != null)
                {
                    for (int i = 0; i < files.Count; i++)
                    {
                        Stream s = new MemoryStream(files[i].filecontent);
                      Attachment attach = new Attachment(s, files[i].filename, files[i].filetype);
                      msg.Attachments.Add(attach);

                    }
                   

                }

                using (var smtpClient = new SmtpClient(_disarimailServer, 25))
                {
                    smtpClient.EnableSsl = false;
                    smtpClient.UseDefaultCredentials = false;
                    smtpClient.Credentials = new NetworkCredential(_disarimailUser, _disarimailPassword, "spkdom");
                    smtpClient.Send(msg);
                }

            }

            return true;


        }
        public void DbsMailIcerik(Basvuru basvuru, string ekMesaj, string tur,decimal turId, ref string strSubject, ref string strMessageBody)
        {


            string basvuruCevap = "";
            string onemli = "Başvuru cevabı 'YAZILI' olarak seçildiği için lütfen başvuruya cevabı belirtilen adrese ve bir kopyasını BEB'ne gönderiniz.<br><br><strong>Bilgi Edinme Birimi</strong>";
           
          
            //if (basvuru.BebListesi[0].bas.BasvuruCevap == 0)
            //    basvuruCevap = "Elektronik";
            //else
            //    basvuruCevap = "Yazılı";

            if (basvuru.BebListesi[0].BASVURUTIPI == OrtakSabitler.GORUS_ONERI_SIKAYET_KOD)
            {
                strSubject = OrtakSabitler.strMailSubject + "SPK Şikayet, Görüş ve Öneriler";
            }

            else if (basvuru.BebListesi[0].BASVURUTIPI == OrtakSabitler.BILGIEDINME_KOD)
            {
                strSubject = OrtakSabitler.strMailSubject + "SPK Bilgi Edinme Başvurusu";
            }

            else if (basvuru.BebListesi[0].BASVURUTIPI == OrtakSabitler.YATIRIMCI_GORUS_ONERI_SIKAYET_KOD)
            {
                strSubject = OrtakSabitler.strMailSubject + "SPK Kurumsal Yatırımcı Görüş ve Öneriler";
            }

            strMessageBody = "<html><head><title>SPK Bilgi Edinme</title><style type='text/css'>td {padding-left:2px; font-family:Verdana; font-size:8pt; border-width:1px; border-style:solid; border-color:#BEC1E2;} .thead { background-color:#695DB3; color:#FFFFFF; font-size:7pt; font-weight:bold; } .log { border-width:0px; font-family:Verdana; font-size:7pt; } </style></head><body><p>" + ekMesaj + "&nbsp;</p><table style='border-width:0px; border-style:solid; border-color:#BEC1E2; width:90%;'><tr><td width='100%' align='center' colspan='2' class='thead'>" + strSubject + "</td></tr>";
            strMessageBody += "<tr><td width='25%' align='right'>Tüzel Kişilik Unvanı:</td><td width='75%'>" + basvuru.TUZELKISILIK + "</td></tr>";

            if (basvuru.BebListesi[0].BASVURUTIPI == "BTIP02")
                strMessageBody += "<tr><td width='25%' align='right'>TC Kimlik No : </td><td width='75%'>" + basvuru.TCKIMLIK + "</td></tr>";

            strMessageBody += "<tr><td width='25%' align='right'>Başvuru No : </td><td width='75%'>" + basvuru.BASVURUID + "</td></tr>";
            strMessageBody += "<tr><td width='25%' align='right'>Başvuru Tarihi : </td><td width='75%'>" + String.Format("{0:dd.MM.yyyy}", basvuru.TARIH) + "</td></tr>";
            strMessageBody += "<tr><td width='25%' align='right'>Adı Soyadı : </td><td width='75%'>" + basvuru.ADSOYAD + "</td></tr>";
            strMessageBody += "<tr><td width='25%' align='right'>Telefon : </td><td width='75%'>" + basvuru.TEL + "</td></tr>";
            strMessageBody += "<tr><td width='25%' align='right'>E-Posta : </td><td width='75%'>" + basvuru.EMAIL + "</td></tr>";
            strMessageBody += "<tr><td width='25%' align='right'>Konu : </td><td width='75%'>" + basvuru.KonuSozluk.aciklama + "</td></tr>";
            strMessageBody += "<tr><td width='25%' align='right'>Adres : </td><td width='75%'>" + basvuru.ADRES + "</td></tr>";
            strMessageBody += "<tr><td width='25%' align='right'>İl : </td><td width='75%'>" + basvuru.IL + "</td></tr>";

            if (basvuru.BebListesi[0].BASVURUTIPI == "BTIP02")
            {
                strMessageBody += "<tr><td width='25%' align='right'>Başvuru İçeriği : </td><td width='75%'>" + basvuru.BASVURUICERIK + "<br>" + OrtakSabitler.bebKanunu + "</td></tr>";
                strMessageBody += "<tr><td width='25%' align='right'>Başvuru Cevabı : </td><td width='75%'>" + basvuruCevap + "</td></tr>";
            }
            else
                strMessageBody += "<tr><td width='25%' align='right'>Başvuru İçeriği : </td><td width='75%'>" + basvuru.BASVURUICERIK + "<br>" + "</td></tr>";

            strMessageBody += "<tr><td width='25%' align='right'>Ek not : </td><td width='75%'>" + basvuru.BebListesi[0].ACIKLAMA + "</td></tr>";
          
            string urladres = null;
            if (tur == OrtakSabitler.DBS_LINK)
            {
                urladres = $"{_urlBase}Dbs/DBSDetay/" + turId;
               
            }
            else
            {
                urladres = $"{_urlBase}Uzman/UzmanDetay/" + turId;
            }
            strMessageBody += "<tr><td width='25%' align='right'>Link : </td><td width='75%'>&nbsp;<a href=' " + urladres + "'>Kayıtı Göster</a>";
            //if (basvuru.BasvuruCevap == OrtakSabitler.YAZILI_CEVAP_KOD)
            //    strMessageBody += "<tr><td width='25%' align='right' style=\"color:red\">Önemli : </td><td width='75%' style=\"color:red\">" + onemli + "</td></tr>";

            strMessageBody += "</td></tr></table>";

            strMessageBody += "</body></html>";
        }



    }
}