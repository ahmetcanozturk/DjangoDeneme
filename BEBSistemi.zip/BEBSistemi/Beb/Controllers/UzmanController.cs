﻿using Beb.Filter;
using Beb.Interfaces;
using Beb.Logger;
using Beb.Models;
using Beb.Services;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;

namespace Beb.Controllers
{

    [AuthFilter(Roles = "UZMAN")]
    [ActFilter]
    public class UzmanController : BaseController
    {
        //private readonly ILogger _logger;
        //public UzmanController()
        //{
        //    _logger = new MyLogger();
        //}
        // GET: Uzman
        public ActionResult Index()
        {
            return View();
        }
        public ActionResult UzmanYonetim()
        {
            ViewBag.CurrentPage = 0;
            BEBDb db = _uow.dbsgorevliRepo.GetContext();
            db = _uow.dbsgorevliRepo.GetContext();

            var list = db.Dbs.Join(db.DbsGorevli, b => b.DBSID, e => e.DBSID, (dbs, gorev) => new { dbs = dbs, gorev = gorev }).Where(dbsgorev => dbsgorev.dbs.SONDURUM == OrtakSabitler.DAIRE_DURUM_GOREVLIYE_YONLENDIRILMIS && dbsgorev.gorev.KULLANICIADI == kullanici.username && dbsgorev.dbs.Beb.KAPANISTARIHI == null).Select(i => i.gorev).OrderByDescending(m => m.ATANMATARIHI);


            logManager.Log(OrtakSabitler.LOG_UZMANYONETIM_GORUNTULE, "");
            ViewBag.Liste = OrtakSabitler.DAIRE_DURUM_GOREVLIYE_YONLENDIRILMIS;
            return View(list);

        }
        public ActionResult UzmanDetay(int id, string Tur, int? currentPage)
        {
            ViewBag.Tur = Tur;
            ViewBag.CurrentPage = currentPage ?? 0;
            if (id == null) { return new HttpStatusCodeResult(HttpStatusCode.BadRequest); }
            DbsGorevli gorevli = _uow.dbsgorevliRepo.Find(x => x.DBSGOREVLIID == id);
            if (gorevli == null) { return HttpNotFound(); }


            gorevli.METINSONRAKI = gorevli.Dbs.BIRIMKAPATMETIN;
            logManager.Log(OrtakSabitler.LOG_UZMANDETAY_GORUNTULE, "", null, gorevli);
            UzmanViewBag(gorevli);
            ViewBag.SirketAdi = MersisApiService.Instance.SirketAdiBySirketID(gorevli.Dbs.Beb.Basvuru.SIRKETID);
            var basvuruId = Convert.ToDecimal(gorevli.Dbs?.Beb?.BASVURUID);
            var logbilgisi = _uow.LogRepo.Find(x => x.BasvuruId == basvuruId && x.DbsId != null && x.Aciklama == "Dbs tatafından beb onaylama");
            ViewBag.DbsAdSoyad = logbilgisi?.IslemYapan;

            ViewBag.uzman = "Uzman";

            return View(gorevli);

        }
        public ActionResult FarkliUzmanDetay(int id)
        {
            if (id == null) { return new HttpStatusCodeResult(HttpStatusCode.BadRequest); }
            Dbs dbs = _uow.dbsRepo.Find(i => i.DBSID == id);
            if (dbs == null) { return HttpNotFound(); }
            // Dbs ViewBag leri kaldırıldı.
            logManager.Log(OrtakSabitler.LOG_FARKLIUZMANDETAY_GORUNTULE, "", null, null, dbs);
            ViewBag.SirketAdi = MersisApiService.Instance.SirketAdiBySirketID(dbs.Beb.Basvuru.SIRKETID);
            ViewBag.uzman = "Uzman";
            var basvuruId = Convert.ToDecimal(dbs.Beb?.BASVURUID);
            var logbilgisi = _uow.LogRepo.Find(x => x.BasvuruId == basvuruId && x.DbsId != null && x.Aciklama == "Dbs tatafından beb onaylama");
            ViewBag.DbsAdSoyad = logbilgisi?.IslemYapan;


            return View(dbs);


        }
        [HttpPost]
        [ValidateInput(false)]
        public ActionResult UzmanTopluOnayla(List<decimal> secilidbsgorevli, string CevapMetni, string SirketID)
        {
            foreach (decimal dbsgorevliid in secilidbsgorevli)
            {
                DbsGorevli dgorevli = _uow.dbsgorevliRepo.Find(x => x.DBSGOREVLIID == dbsgorevliid);
                dgorevli.METINSONRAKI = CevapMetni;
                dgorevli.Dbs.BIRIMKAPATMETIN = CevapMetni;
                dgorevli.Dbs.TOPLUCEVAPMI = true;
                DbsGorevliOnay(dgorevli, SirketID);
            }
            return RedirectToAction("UzmanYonetim");
        }
        public DbsGorevli DbsGorevliOnay(DbsGorevli gorevli, string SirketID)
        {
            //Uzman onayladıktan sonra dbs birimimi değişiyor ama beb kapanış metni değişmiyor
            //Aynı daire kontrolü yapımalı  
            DbsGorevli dgorevli = _uow.dbsgorevliRepo.Find(x => x.DBSGOREVLIID == gorevli.DBSGOREVLIID);
            if (gorevli.METINSONRAKI == null || gorevli.METINSONRAKI == "")
            {
                Message("Lütfen Cevap Metni Giriniz.");
                return dgorevli;
            }
            else
            {
                dgorevli.METINSONRAKI = gorevli.METINSONRAKI;
                dgorevli.METINONCEKI = dgorevli.Dbs.BIRIMKAPATMETIN;
                dgorevli.Dbs.BIRIMKAPATMETIN = gorevli.METINSONRAKI;
                dgorevli.ISLEMTARIHI = DateTime.Now;
                //Beb kapanış metni dbs onayladıktan sonra yapılmalı.
                //dgorevli.Dbs.Beb.KAPANISMETNI += gorevli.METINSONRAKI; 
                _uow.dbsgorevliRepo.Update(dgorevli);

                DaireDurumOlustur(OrtakSabitler.DAIRE_DURUM_DAIRE_YETKILI_ONAYI_BEKLENIYOR, dgorevli.DBSID, dgorevli.Dbs.BIRIMKAPATMETIN, dgorevli.Dbs.IADE);
                logManager.Log(OrtakSabitler.LOG_BEB_UZMAN_ONAYA_GONDER, "", null, gorevli);
                string strSubject = "", strMessageBody = "", mailmesaj = "";
                Dbs ilgilidbs = dgorevli.Dbs;
                Basvuru bs = dgorevli.Dbs.Beb.Basvuru;

                if (bs.SIRKETID != null || bs.SIRKETID != SirketID)
                {
                    bs.SIRKETID = SirketID;
                    _uow.SaveChanges();
                    Message("Şirket Adı eklenmiştir/güncellenmiştir. " + mailmesaj);
                }

                mailService.DbsMailIcerik(bs, "Başvuruda güncelleme yapılmıştır.", OrtakSabitler.DBS_LINK, ilgilidbs.DBSID, ref strSubject, ref strMessageBody);
                bool mailGonderme = mailService.SendMail(ilgilidbs.YONEPOSTA, strSubject, strMessageBody);
                if (mailGonderme)
                {
                    mailmesaj = "Mail Gönderme işlemi başarıyla gerçekleşti.";
                }
                else
                {
                    mailmesaj = "Mail Gönderilemedi.";
                }


                Message("Daire Yetkilisi Onayına Gönderilmiştir. " + mailmesaj);

                return dgorevli;
            }
        }
        [HttpPost]
        public ActionResult UzmanDetay(DbsGorevli gorevli, string SirketID)
        {
            DbsGorevli dgorevli = DbsGorevliOnay(gorevli, SirketID);
            UzmanViewBag(dgorevli);
            ViewBag.SirketAdi = MersisApiService.Instance.SirketAdiBySirketID(SirketID);
            ViewBag.uzman = "Uzman";

            var basvuruId = Convert.ToDecimal(gorevli.Dbs?.Beb.BASVURUID);
            var logbilgisi = _uow.LogRepo.Find(x => x.BasvuruId == basvuruId && x.DbsId != null && x.Aciklama == "Dbs tatafından beb onaylama");
            ViewBag.DbsAdSoyad = logbilgisi?.IslemYapan;

            return View(dgorevli);


        }
        [HttpPost]
        [ValidateInput(false)]
        public ActionResult UzmanTopluIade(List<decimal> secilidbsgorevli, string CevapMetni, string SirketID)
        {
            foreach (decimal dbsgorevliid in secilidbsgorevli)
            {
                DbsGorevli dgorevli = _uow.dbsgorevliRepo.Find(x => x.DBSGOREVLIID == dbsgorevliid);
                dgorevli.METINSONRAKI = CevapMetni;
                dgorevli.Dbs.BIRIMKAPATMETIN = CevapMetni;

                DbsGorevliIade(dgorevli, SirketID);
            }
            return RedirectToAction("UzmanYonetim");
        }
        public DbsGorevli DbsGorevliIade(DbsGorevli gorevli, string SirketID)
        {
            DbsGorevli dgorevli = _uow.dbsgorevliRepo.Find(x => x.DBSGOREVLIID == gorevli.DBSGOREVLIID);
            dgorevli.METINSONRAKI = gorevli.METINSONRAKI;
            dgorevli.METINONCEKI = dgorevli.Dbs.BIRIMKAPATMETIN;
            dgorevli.Dbs.BIRIMKAPATMETIN = gorevli.METINSONRAKI;
            dgorevli.ISLEMTARIHI = DateTime.Now;
            //Beb kapanış metni dbs onayladıktan sonra yapılmalı.
            //dgorevli.Dbs.Beb.KAPANISMETNI += gorevli.METINSONRAKI;
            _uow.dbsgorevliRepo.Update(dgorevli);
            DaireDurumOlustur(OrtakSabitler.DAIRE_DURUM_DAIRE_YETKILI_IADESI_BEKLENIYOR, dgorevli.DBSID, dgorevli.Dbs.BIRIMKAPATMETIN, dgorevli.Dbs.IADE);
            string strSubject = "", strMessageBody = "", mailmesaj = "";
            Dbs ilgilidbs = dgorevli.Dbs;
            Basvuru bs = dgorevli.Dbs.Beb.Basvuru;
            if (SirketID != null || SirketID != bs.SIRKETID)
            {
                bs.SIRKETID = SirketID;
                _uow.SaveChanges();
                Message("Şirket değiştirilmiştir/güncellenmiştir. " + mailmesaj);
            }


            mailService.DbsMailIcerik(bs, "Başvuruda güncelleme yapılmıştır.", OrtakSabitler.DBS_LINK, ilgilidbs.DBSID, ref strSubject, ref strMessageBody);
            bool mailGonderme = mailService.SendMail(ilgilidbs.YONEPOSTA, strSubject, strMessageBody);
            if (mailGonderme)
            {
                mailmesaj = "Mail Gönderme işlemi başarıyla gerçekleşti.";
            }
            else
            {
                mailmesaj = "Mail Gönderilemedi.";
            }

            Message("Daire Yetkilisine İade Gönderilmiştir." + mailmesaj);
            logManager.Log(OrtakSabitler.LOG_BEB_UZMAN_IADEYE_GONDER, "", null, gorevli);
            return dgorevli;
        }
        [HttpPost]
        [ValidateInput(false)]
        public ActionResult UzmanIadeEt(DbsGorevli gorevli, string SirketID)
        {
            DbsGorevli dgorevli = DbsGorevliIade(gorevli, SirketID);

            UzmanViewBag(dgorevli);
            return View("UzmanDetay", dgorevli);

        }
        public ActionResult BasvuruAra(string id, int? CurrentPage)
        {
            ViewBag.CurrentPage = CurrentPage ?? 0;
            BEBDb db = _uow.dbsgorevliRepo.GetContext();
            db = _uow.dbsgorevliRepo.GetContext();

            ViewBag.Liste = id;

            if (id != OrtakSabitler.DAIRE_DURUM_DAIRE_YETKILISI_IADE_ETTI && id != OrtakSabitler.DAIRE_DURUM_DAIRE_YETKILISI_ONAYLADI)
            {
                var list = db.Dbs.Join(db.DbsGorevli, b => b.DBSID, e => e.DBSID, (dbs, gorev) => new { dbs = dbs, gorev = gorev }).Where(dbsgorev => dbsgorev.dbs.SONDURUM == id && dbsgorev.gorev.KULLANICIADI == kullanici.username && dbsgorev.dbs.Beb.KAPANISTARIHI == null).Select(i => i.gorev).OrderByDescending(m => m.ATANMATARIHI);

                return View("UzmanYonetim", list);
            }
            else
            {
                var list = db.Dbs.Join(db.DbsGorevli, b => b.DBSID, e => e.DBSID, (dbs, gorev) => new { dbs = dbs, gorev = gorev }).Where(dbsgorev => dbsgorev.dbs.SONDURUM == id && dbsgorev.gorev.KULLANICIADI == kullanici.username).Select(i => i.gorev).OrderByDescending(m => m.ATANMATARIHI);

                return View("UzmanYonetim", list);
            }
        }
        public void UzmanViewBag(DbsGorevli dbsGorevli = null)
        {
            ViewBag.Daire = kullanici.daire;
        }

    }
}