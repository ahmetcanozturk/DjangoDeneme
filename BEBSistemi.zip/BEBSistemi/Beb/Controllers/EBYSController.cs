﻿using Beb.Interfaces;
using Beb.Models;
using Beb.UOW;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Configuration;
using System.Web.Http;

namespace Beb.Controllers
{
   [AllowAnonymous]
    public class EBYSController : ApiController
    {
        public IUnitOfWork _uow;
        BEBDb db;
        string _urlBase;

        private EBYSController()
        {
            _urlBase = WebConfigurationManager.AppSettings["UrlBase"];
            _uow = new UnitOfWork();
            db = _uow.basvuruRepo.GetContext();
        }

        [System.Web.Http.AcceptVerbs("GET", "POST")]
        public List<BebUyari> BEBUyariBilgileriniGetir(string id)
        {
            string kullaniciAd = id;
            bool uzman = false;

            try
            {
                List<string> rolList = new List<string>();

                var roller = _uow.KullaniciRolRepo.Get(x => x.USERADID == kullaniciAd, x => new { x.USERADID, x.RolBilgisi.ROLADI });

                if (roller != null && roller.Count > 0)
                {
                    foreach (var item in roller)
                    {
                        rolList.Add(item.ROLADI);
                    }
                }
                else
                {
                    rolList.Add(OrtakSabitler.ROLES_UZMAN);
                    uzman = true;
                }


                List<BebUyari> sonuc = new List<BebUyari>();

                if (rolList != null && rolList.Contains(OrtakSabitler.ROLES_BEB))
                {
                    sonuc.Add(new BebUyari { Description = OrtakSabitler.BEBUyari_Yonlendirme_Bekleyen, Count = 0, Link = uzman ? $"{_urlBase}Uzman/BasvuruAra/DDUR03" : $"{_urlBase}Dbs/BasvuruAra/DDUR03" });
                    sonuc.Add(new BebUyari { Description = OrtakSabitler.BEBUyari_Uzmanda_Bekleyen, Count = 0, Link = uzman ? $"{_urlBase}Uzman/BasvuruAra/DDUR04" : $"{_urlBase}Dbs/BasvuruAra/DDUR04" });
                    sonuc.Add(new BebUyari { Description = OrtakSabitler.BEBUyari_Onay_Bekleyen, Count = 0, Link = uzman ? $"{_urlBase}Uzman/BasvuruAra/DDUR01" : $"{_urlBase}Dbs/BasvuruAra/DDUR01" });
                    sonuc.Add(new BebUyari { Description = OrtakSabitler.BEBUyari_Iade_Bekleyen, Count = 0, Link = uzman ? $"{_urlBase}Uzman/BasvuruAra/DDUR02" : $"{_urlBase}Dbs/BasvuruAra/DDUR02" });
                    sonuc.Add(new BebUyari { Description = OrtakSabitler.BEBUyari_Tarihi_Gecen, Count = 0, Link = uzman ? $"{_urlBase}Uzman/UzmanYonetim" : $"{_urlBase}Dbs/DbsYonetim" });
                    sonuc.Add(new BebUyari { Description = OrtakSabitler.BEBUyari_Son_Gun, Count = 0, Link = uzman ? $"{_urlBase}Uzman/UzmanYonetim" : $"{_urlBase}Dbs/DbsYonetim" });
                    sonuc.Add(new BebUyari { Description = OrtakSabitler.BEBUyari_Son_Uc_Gun, Count = 0, Link = uzman ? $"{_urlBase}Uzman/UzmanYonetim" : $"{_urlBase}Dbs/DbsYonetim" });

                    return sonuc;
                }

   
                sonuc.AddRange(UzmanBirimYetBekleyen(uzman, kullaniciAd));

                sonuc.AddRange(SonGunHesaplamaları(uzman, kullaniciAd));


                return sonuc;
            }
            catch (Exception e)
            {
                return null;
            }            
        }

        private List<BebUyari> UzmanBirimYetBekleyen(bool uzman, string kullaniciAd)
        {
            //Beb uyarıya 3 tane ekleme yapıyor uzmanda bekleyen, onay/iade bekleyen,uzmana yönlendirilmemiş başvurular
            List<BebUyari> uyariList = new List<BebUyari>();
            List<BebUyari> sonuc = null;

            int uzmandaBekleyen = 0, yonlendirmeBekleyen = 0, onayBekleyen = 0, iadeBekleyen = 0;

            try
            {
                string sqL = "select count(*) as Count, (SELECT S.explanation from Sozluk S where S.id = ddurum.DAIREDURUM) as Description, ddurum.DAIREDURUM as DurumSozlukKod " +
                  "from BSB_BASVURU bas, BSB_BEB beb, BSB_DBS dbs, BSB_DAIREDURUM ddurum "; 

                if(uzman)
                {
                    sqL += ", BSB_DBS_GOREVLI gorevli ";
                }

                sqL += "where beb.BASVURUID = bas.BASVURUID " +
                          "and dbs.BEBID = beb.BEBID ";

                if(uzman)
                {
                    sqL += "and dbs.DBSID = gorevli.DBSID and gorevli.KULLANICIADI = '" + kullaniciAd + "' ";
                }
                else
                {
                    sqL += "and dbs.YONBIRIM = (select kullanici.BIRIMID from BSB_KULLANICIROL kullanici where kullanici.USERADID = '" + kullaniciAd + "') ";
                }
                
                
                sqL += "and ddurum.DAIREDURUMID = (select max(DAIREDURUMID) from BSB_DAIREDURUM ddurum1 WHERE ddurum1.DBSID = dbs.DBSID) " +
                       "and ddurum.DAIREDURUM not in ('DDUR05', 'DDUR06') " +
                       "and beb.KAPANISTARIHI is null " +
                       "group by ddurum.DAIREDURUM";

                sonuc = db.Database.SqlQuery<BebUyari>(sqL).ToList();

                foreach (BebUyari uyari in sonuc)
                {
                    if (uyari.DurumSozlukKod.Equals(OrtakSabitler.DAIRE_DURUM_DAIREYE_YONLENDIRILMIS))
                    {
                        yonlendirmeBekleyen = uyari.Count;
                    }
                    else if (uyari.DurumSozlukKod.Equals(OrtakSabitler.DAIRE_DURUM_GOREVLIYE_YONLENDIRILMIS))
                    {
                        uzmandaBekleyen = uyari.Count;
                    }
                    else if (uyari.DurumSozlukKod.Equals(OrtakSabitler.DAIRE_DURUM_DAIRE_YETKILI_ONAYI_BEKLENIYOR))
                    {
                        onayBekleyen = uyari.Count;
                    }
                    else if (uyari.DurumSozlukKod.Equals(OrtakSabitler.DAIRE_DURUM_DAIRE_YETKILI_IADESI_BEKLENIYOR))
                    {
                        iadeBekleyen = uyari.Count;
                    }
                }

                uyariList.Add(new BebUyari { Description = OrtakSabitler.BEBUyari_Yonlendirme_Bekleyen, Count = yonlendirmeBekleyen, Link = uzman ? $"{_urlBase}Uzman/BasvuruAra/DDUR03" : $"{_urlBase}Dbs/BasvuruAra/DDUR03" });

                uyariList.Add(new BebUyari { Description = OrtakSabitler.BEBUyari_Uzmanda_Bekleyen, Count = uzmandaBekleyen, Link = uzman ? $"{_urlBase}Uzman/BasvuruAra/DDUR04" : $"{_urlBase}Dbs/BasvuruAra/DDUR04" });

                uyariList.Add(new BebUyari { Description = OrtakSabitler.BEBUyari_Onay_Bekleyen, Count = onayBekleyen, Link = uzman ? $"{_urlBase}Uzman/BasvuruAra/DDUR01" : $"{_urlBase}Dbs/BasvuruAra/DDUR01" });

                uyariList.Add(new BebUyari { Description = OrtakSabitler.BEBUyari_Iade_Bekleyen, Count = iadeBekleyen, Link = uzman ? $"{_urlBase}Uzman/BasvuruAra/DDUR02" : $"{_urlBase}Dbs/BasvuruAra/DDUR02" });
               
                return uyariList;
            }
            catch (Exception ex)
            {
                return null;
            }      
        }

        private List<BebUyari> SonGunHesaplamaları(bool uzman, string kullaniciAd)
        {
            int yasalsuresidolan = 0, Ucgunkalan = 0, SonGun = 0;

            List<BebUyari> sonuc = new List<BebUyari>();
            try
            {
                string sqL = "SELECT ISNULL((case when beb.BASVURUTIPI = 'BTIP01' then datediff(day, bas.LOGISLEMTARIH, GETDATE()) else dbo.getDiffDateWithRestDay(bas.LOGISLEMTARIH, GETDATE()) end), 0 ) as Count, " +
               " beb.BASVURUTIPI as Description" +
               " FROM BSB_BEB beb, BSB_DBS dbs, BSB_BASVURU bas ";

                if (uzman)
                {
                    sqL += " ,BSB_DBS_GOREVLI gorevli";
                }

                sqL += "  WHERE bas.BASVURUID = beb.BASVURUID and beb.BEBID = dbs.BEBID and (beb.DURUM = 'BDUR03' or beb.DURUM = 'BDUR04') and dbs.IADE != 1 and dbs.BASVURUCEVAPTARIHI is null";                

                if (uzman)
                {
                    sqL += " and gorevli.DBSID = dbs.DBSID and gorevli.KULLANICIADI = '" + kullaniciAd + "'";
                }
                else
                {
                    sqL += " and dbs.YONBIRIM = (select kullanici.BIRIMID from BSB_KULLANICIROL kullanici where kullanici.USERADID ='" + kullaniciAd + "')";
                }

                sqL += " and beb.KAPANISTARIHI is null and beb.BASVURUTIPI in ('BTIP01', 'BTIP02') ";

                sonuc = db.Database.SqlQuery<BebUyari>(sqL).ToList();
                if (sonuc != null && sonuc.Count() > 0)
                {
                    foreach (BebUyari sonucuyari in sonuc)
                    {
                        if (sonucuyari.Description == "BTIP01")
                        {
                            if (sonucuyari.Count > 30)
                            {
                                yasalsuresidolan++;
                            }
                            else if (sonucuyari.Count == 30)
                            {
                                SonGun++;
                            }
                            else if (sonucuyari.Count == 27)
                            {
                                Ucgunkalan++;
                            }
                        }
                        else
                        {
                            if (sonucuyari.Count > 15)
                            {
                                yasalsuresidolan++;
                            }
                            else if (sonucuyari.Count == 15)
                            {
                                SonGun++;
                            }
                            else if (sonucuyari.Count == 12)
                            {
                                Ucgunkalan++;
                            }
                        }
                    }
                }
                List<BebUyari> hesapsonuc = new List<BebUyari>();

                hesapsonuc.Add(new BebUyari { Description = OrtakSabitler.BEBUyari_Tarihi_Gecen, Count = yasalsuresidolan, Link=uzman ? $"{_urlBase}Uzman/UzmanYonetim" : $"{_urlBase}Dbs/DbsYonetim" });
                hesapsonuc.Add(new BebUyari { Description = OrtakSabitler.BEBUyari_Son_Gun, Count = SonGun, Link = uzman ? $"{_urlBase}Uzman/UzmanYonetim" : $"{_urlBase}Dbs/DbsYonetim" });
                hesapsonuc.Add(new BebUyari { Description = OrtakSabitler.BEBUyari_Son_Uc_Gun, Count = Ucgunkalan, Link = uzman ? $"{_urlBase}Uzman/UzmanYonetim" : $"{_urlBase}Dbs/DbsYonetim" });

                return hesapsonuc;
            }
            catch (Exception ex)
            {
                return null;
            }
        }

    }
}
