﻿using Beb.Models;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using Beb.Repository;
using Beb.Interfaces;
using Beb.File;
//using System.Web.Script.Serialization;
using Newtonsoft.Json;
using Beb.Filter;
using Beb.Logger;
using Beb.UOW;
using Beb.Mail;
using Beb.Utilities;
using System.Data.SqlClient;
using System.Data;
using Beb.Services;

namespace Beb.Controllers
{
    [ExFilter]
    [BrowserFilter("Edge", "Chrome", "Firefox", "Opera")]
    public class BaseController : Controller
    {

        protected IUser _userManager;
        protected ILogger logManager;
        protected SYN_DomainUsers kullanici;
        protected IMailService mailService;
        protected IUnitOfWork _uow;
        BEBDb db = new BEBDb();

        public BaseController()
        {
            _userManager = new Users.UserManager();
            kullanici = _userManager.UserInfo();
            _uow = new UnitOfWork();
            mailService = new MailService();
            logManager = new MyLogger(_uow.AuditLoggerRepo.GetContext());
        }
        public ActionResult NotFound()
        {
            return View();
        }

        public void Message(string mesaj)
        {
            TempData["message"] = mesaj;

        }
        public bool DaireDurumOlustur(string daireDurum, decimal dbsid, string BIRIMKAPATMAMETNI, bool? IADE)
        {
            DaireDurum ddurum = new DaireDurum
            {
                DAIREDURUM = daireDurum,
                KAYITTARIH = DateTime.Now,
                DBSID = dbsid,
                BIRIMKAPATMAMETNI = BIRIMKAPATMAMETNI,
                IADE = IADE
            };
            _uow.dairedurumRepo.Insert(ddurum);
            Dbs dbs = _uow.dbsRepo.Find(d => d.DBSID == dbsid);
            dbs.SONDURUM = daireDurum;
            _uow.dbsRepo.Update(dbs);
            return true;
        }
        public ActionResult YetkisizErisim()
        {

            return View();
        }
        public JsonResult GetKonu(string id)// 3. parametre her zaman id ismiyle okunur route config den
        {
            List<BilgiEdinmeSozluk> result = null;
            List<string> bilgiedinme = new List<string> { "KON000000", "KON010000", "KON020000", "KON030000", "KON040000", "KON050000", "KON060000",
                                 "KON070000", "KON080000", "KON090000", "KON100000", "KON110000", "KON120000", "KON130000", "KON140000"};
            if (id.Equals(OrtakSabitler.BILGIEDINME_KOD))
            {

                result = _uow.bilgiedinmesozlukRepo.List(x => bilgiedinme.Contains(x.id));

            }
            else if (id.Equals(OrtakSabitler.GORUS_ONERI_SIKAYET_KOD) || id.Equals(OrtakSabitler.YATIRIMCI_GORUS_ONERI_SIKAYET_KOD))
            {
                List<string> onerisikayet = new List<string> {"ONR000", "ONR001", "ONR002", "ONR003", "ONR004", "ONR005", "ONR006", "ONR007",
                                   "ONR008", "ONR009", "ONR010", "ONR011", "ONR012", "ONR013", "ONR014", "ONR015" };
                result = _uow.bilgiedinmesozlukRepo.List(x => onerisikayet.Contains(x.id));
            }
            else if (id.Equals(OrtakSabitler.ISTEK))
            {
                List<string> Istek = new List<string> {"ONR000", "ONR001", "ONR002", "ONR003", "ONR004", "ONR005", "ONR006", "ONR007",
                                   "ONR008", "ONR009", "ONR010", "ONR011", "ONR012", "ONR013", "ONR014" , "ONR015"};
                result = _uow.bilgiedinmesozlukRepo.List(x => Istek.Contains(x.id));
            }
            return Json(result, JsonRequestBehavior.AllowGet);
        }

        public JsonResult GetAltKonu(string id)
        {
            string substring = id.Substring(0, 5);
            List<BilgiEdinmeSozluk> result = _uow.bilgiedinmesozlukRepo.List(i => i.id.StartsWith(substring) && i.id.EndsWith("00") && !i.id.Equals(id) && !i.id.Equals("KON000000") && !i.id.Equals("ONR000"));
            return Json(result, JsonRequestBehavior.AllowGet);
        }


        public JsonResult GetAltAltKonu(string id)
        {
            string substring = id.Substring(0, 7);
            List<BilgiEdinmeSozluk> result = _uow.bilgiedinmesozlukRepo.List(i => i.id.StartsWith(substring) && !i.id.Equals(id) && !i.id.Equals("KON000000") && !i.id.Equals("ONR000"));
            return Json(result, JsonRequestBehavior.AllowGet);
        }


        public ActionResult Filtreleme()
        {
            ViewBagFiltreleme();
            return View();
        }

        [HttpPost]
        public ActionResult Filtreleme(string TCKIMLIK, string ADSOYAD, string CIMERNO, string reservation, string kapatmareservation, string TUZELKISILIK, string BASVURUTURU, string BASVURUTIPI, string KONU, string Birim,
            string BASVURUDURUMU, string DAIREDURUMU, string BASVURUSONUCU, string UZMAN, string BASVURUICERIK, string BASVURUCEVABI, string SIRKETID)
        {

            FiltreTur filtre = new FiltreTur();
            List<Basvuru> basvurular = new List<Basvuru>();
            Dictionary<decimal, decimal> basDbs = new Dictionary<decimal, decimal>();
            var querybeb = _uow.bebRepo.Queryable();
            var querysonuc = _uow.basvuruRepo.Queryable().Where(c => c.BebListesi.Any()).Join(querybeb, i => i.BASVURUID, b => b.BASVURUID, (bas, beb) => new { bas = bas, beb = beb }).Select(i => new { i.bas, i.beb });
            var querydbs = _uow.dbsRepo.Queryable();

            string daire = kullanici.daire;

            Sozluk s = _uow.sozlukRepo.Find(i => i.explanation == daire);
            if ((TCKIMLIK != null && !TCKIMLIK.Equals("")) || (ADSOYAD != null && !ADSOYAD.Equals("")) || (kapatmareservation != null && !kapatmareservation.Equals("")) || (reservation != null && !reservation.Equals("")))
            {
                if (!((List<string>)Session["Rol"]).Contains(Beb.Models.OrtakSabitler.ROLES_BEB))
                {

                    var list = querysonuc.Join(querydbs, b => b.beb.BEBID, e => e.BEBID, (bas, dbs) => new { bas = bas, dbs = dbs }).Where(basdbs => basdbs.dbs.YONBIRIM == s.id).Select(i => new { i.bas, i.dbs });
                    querysonuc = list.Select(i => i.bas);
                    if (UZMAN != null && !UZMAN.Equals(""))
                    {
                        var querydbsgorevli = _uow.dbsgorevliRepo.Queryable();
                        querysonuc = list.Join(querydbsgorevli, b => b.dbs.DBSID, e => e.DBSID, (bas, dbsgor) => new { bas = bas, dbsgor = dbsgor }).Where(basdbs => basdbs.dbsgor.KULLANICIADI == UZMAN).Select(i => i.bas.bas);
                    }
                    if (DAIREDURUMU != null && !DAIREDURUMU.Equals("") && !DAIREDURUMU.Equals("DDUR00"))
                    {
                        querysonuc = list.Where(basdbs => basdbs.dbs.SONDURUM == DAIREDURUMU).Select(i => i.bas);

                    }
                }

                if (TCKIMLIK != null && !TCKIMLIK.Equals(""))
                {
                    querysonuc = querysonuc.Where(w => w.bas.TCKIMLIK == TCKIMLIK);
                }
                if (ADSOYAD != null && !ADSOYAD.Equals(""))
                {
                    querysonuc = querysonuc.Where(w => w.bas.ADSOYAD.ToLower().Contains(ADSOYAD.ToLower()));

                }
                if (TUZELKISILIK != null && !TUZELKISILIK.Equals(""))
                {
                    querysonuc = querysonuc.Where(w => w.bas.TUZELKISILIK.ToLower().Contains(TUZELKISILIK.ToLower()));

                }
                if (CIMERNO != null && !CIMERNO.Equals(""))
                {
                    querysonuc = querysonuc.Where(w => w.bas.CIMERBASVURUNO.ToLower().Contains(CIMERNO.ToLower()));

                }

                if (SIRKETID != null && !SIRKETID.Equals(""))
                {
                    var sirketId = MersisApiService.Instance.AdinaGoreSirketAra(SIRKETID).Select(x => x.SirketId).FirstOrDefault();
                    var qu = querysonuc.ToList();

                    
                        querysonuc = querysonuc.Where(x => x.bas.SIRKETID.Contains(sirketId.ToString()));
                        ViewBag.SirketAdi = MersisApiService.Instance.SirketAdiBySirketID(sirketId.ToString());
                    

                }

                if (reservation != null && !reservation.Equals(""))
                {
                    string[] tarih = reservation.Split('-');
                    DateTime tarih1 = DateTime.Parse(tarih[0]);
                    DateTime tarih2 = DateTime.Parse(tarih[1]);
                    if (tarih2.Subtract(tarih1).TotalDays <= 366)
                    {
                        querysonuc = querysonuc.Where(w => w.bas.TARIH >= tarih1 && w.bas.TARIH <= tarih2);
                        ViewBag.reservation = reservation;
                    }
                    else
                    {
                        basvurular = null;
                        ViewBagFiltreleme();
                        Message("Tarih Aralığı en fazla 1 yıl olabilir.");
                        return View();
                    }

                }
                if (kapatmareservation != null && !kapatmareservation.Equals(""))
                {
                    string[] tarih = kapatmareservation.Split('-');
                    DateTime tarih1 = DateTime.Parse(tarih[0]);
                    DateTime tarih2 = DateTime.Parse(tarih[1]);
                    if (tarih2.Subtract(tarih1).TotalDays <= 366)
                    {
                        querysonuc = querysonuc.Where(w => w.beb.KAPANISTARIHI >= tarih1 && w.beb.KAPANISTARIHI <= tarih2);
                        ViewBag.kapatmareservation = kapatmareservation;
                    }
                    else
                    {
                        basvurular = null;
                        ViewBagFiltreleme();
                        Message("Kapatma Tarih Aralığı en fazla 1 yıl olabilir.");
                        return View();
                    }
                }
                if (BASVURUTURU != null && !BASVURUTURU.Equals("") && !BASVURUTURU.Equals("BTUR00"))
                {
                    querysonuc = querysonuc.Where(w => w.beb.BASVURUTURU == BASVURUTURU);

                }
                if (BASVURUTIPI != null && !BASVURUTIPI.Equals("") && !BASVURUTIPI.Equals("BTIP00"))
                {
                    querysonuc = querysonuc.Where(w => w.beb.BASVURUTIPI == BASVURUTIPI);
                }
                if (KONU != null && !KONU.Equals("") && !KONU.Equals("id") && !KONU.Equals("KON000000") && !KONU.Equals("ONR00"))
                {
                    querysonuc = querysonuc.Where(w => w.bas.KONU == KONU);
                }
                if (Birim != null && !Birim.Equals(""))
                {
                    querysonuc = querysonuc.Join(querydbs, b => b.beb.BEBID, e => e.BEBID, (bas, dbs) => new { bas = bas, dbs = dbs }).Where(basdbs => basdbs.dbs.YONBIRIM == Birim).Select(i => i.bas);
                }
                if (BASVURUDURUMU != null && !BASVURUDURUMU.Equals("") && !BASVURUDURUMU.Equals("BDUR00"))
                {
                    querysonuc = querysonuc.Where(w => w.beb.DURUM == BASVURUDURUMU);
                }

                if (BASVURUSONUCU != null && !BASVURUSONUCU.Equals("Basvuru Sonucu Seçiniz"))
                {
                    querysonuc = querysonuc.Where(w => w.beb.BASVURUSONUC.ToString() == BASVURUSONUCU);

                }

                if (BASVURUICERIK != null && !BASVURUICERIK.Equals(""))
                {
                    querysonuc = querysonuc.Where(w => w.bas.BASVURUICERIK != null && w.bas.BASVURUICERIK.ToLower().Contains(BASVURUICERIK.ToLower()));

                }
                if (BASVURUCEVABI != null && !BASVURUCEVABI.Equals(""))
                {
                    querysonuc = querysonuc.Where(w => w.beb.KAPANISMETNI != null && w.beb.KAPANISMETNI.ToLower().Contains(BASVURUCEVABI.ToLower()));
                }

                ViewBagFiltreleme();
                basvurular = querysonuc.Select(i => i.bas).ToList();
                filtre.Basvurular = basvurular;

                if (!((List<string>)Session["Rol"]).Contains(Beb.Models.OrtakSabitler.ROLES_BEB))
                {
                    var liste = querysonuc.Join(querydbs, b => b.beb.BEBID, e => e.BEBID, (bas, dbs) => new { bas = bas, dbs = dbs }).Where(basdbs => basdbs.dbs.YONBIRIM == s.id).Select(i => new { i.bas.bas.BASVURUID, i.dbs }).GroupBy(g => g.BASVURUID, (key, group) => new { Basvuruid = key, dbss = group.ToList() }).ToList();

                    foreach (var item in liste)
                    {
                        if (!basDbs.ContainsKey(item.Basvuruid))
                        {
                            basDbs.Add(item.Basvuruid, item.dbss[0].dbs.DBSID);
                        }
                    }
                    filtre.basvuruDbs = basDbs;
                }
                return View(filtre);

            }
            else
            {
                basvurular = null;
                ViewBagFiltreleme();
                Message("Lütfen TCKimlik, Ad Soyad, Tarih Aralığı veya Kapatma Tarih Aralığı kriterlerinden en az birisini girerek filtreleme yapınız! ");
                return View();
            }



        }

        public void ViewBagFiltreleme()
        {

            ViewBag.BasvuruTuru = _uow.sozlukRepo.List(i => i.id.StartsWith("BTUR") && i.Durum == 1).Select(i => new SelectListItem { Value = i.id, Text = i.explanation });
            ViewBag.BasvuruTipi = _uow.sozlukRepo.List(i => i.id.StartsWith("BTIP") && i.Durum == 1).Select(i => new SelectListItem { Value = i.id, Text = i.explanation });
            ViewBag.Konu = null;
            ViewBag.Birim = _uow.sozlukRepo.List(d => d.id.StartsWith("BRM")).Select(i => new SelectListItem { Value = i.id, Text = i.explanation });
            ViewBag.BasvuruDurumu = _uow.sozlukRepo.List(d => d.id.StartsWith("BDUR")).Select(i => new SelectListItem { Value = i.id, Text = i.explanation });
            ViewBag.DaireDurumu = _uow.sozlukRepo.List(d => d.id.StartsWith("DDUR")).Select(i => new SelectListItem { Value = i.id, Text = i.explanation });
            ViewBag.BasvuruSonucu = new List<SelectListItem>
                                        {
                                        new SelectListItem{ Text="Basvuru Sonucu Seçiniz", Value = null},
                                        new SelectListItem{ Text="Olumlu", Value = "1"},
                                        new SelectListItem{ Text="Kısmen Olumlu", Value = "2" },
                                        new SelectListItem{ Text="Red", Value = "3"}

                                    };

            //if (kullanici.birim != null && kullanici.birim.Equals("LSG"))
            //{
            //    ViewBag.UzmanListesi = _uow.userRepo.List(i => i.daire == "MSD").Select(i => new SelectListItem { Value = i.username, Text = i.adsoyad });
            //}
            //else
            //{
            //    ViewBag.UzmanListesi = _uow.userRepo.List(i => i.daire == kullanici.daire).Select(i => new SelectListItem { Value = i.username, Text = i.adsoyad });
            //}
            //HttpPost edildiğinde geri dönen değer için yazılmış
            //ViewBag.Konu = _uow.bilgiedinmesozlukRepo.List().Select(i => new SelectListItem { Value = i.id, Text = i.aciklama });

        }


        [AuthFilter(Roles = "BEB, DENETCI")]
        public ActionResult Raporlama()
        {
            Rapor rapor = new Rapor();

            ViewBag.PerformansTur = new[]
            {
             new SelectListItem{ Value="KaynakDag",Text="Kaynak Dağılımı"},
              new SelectListItem{ Value="BirimBaz",Text="Birim Bazlı Dağılım"},
               new SelectListItem{ Value="BebSonuclari",Text="Beb işlem Sonuçları"},
                new SelectListItem{ Value="BebKonu",Text="Beb Konu Dağılımı"},
                 new SelectListItem{ Value="SGOKonu",Text="SGÖ Konu Dağılımı "}
           };
            ViewBag.Tur = new[]
           {
             new SelectListItem{ Value="BTIP02",Text="Bilgi Edinme Başvurusu"},
              new SelectListItem{ Value="BTIP01",Text="Şikayet ve İhbar Başvurusu"},
               new SelectListItem{ Value="BTIP03",Text="Diğer Başvurular"}
            };


            rapor.RaporTuruList = new[]{
                 //new SelectListItem{ Value="1",Text="Standart Rapor"},
                 new SelectListItem{ Value="2",Text="Gecikme Raporu"},
                 new SelectListItem{ Value="3",Text="Performans Raporu"},
                new SelectListItem{ Value="4",Text="Birim Süreç İstatistikleri "} ,
               new SelectListItem{ Value="5",Text="Kurul Genel İstatistikleri "},
               new SelectListItem{ Value="6",Text="İade İstatistikleri"},
                new SelectListItem{ Value="7",Text="Süresi İçerisinde Kapanmayan Başvurular"},
               new SelectListItem{ Value="8",Text="Birim Bazında Süresi İçerisinde Kapanmayan Başvurular"},
               new SelectListItem{ Value="9",Text="KİD Bilgi Edinme Ortalama İşlem Süreleri"},
              new SelectListItem{ Value="10",Text="BEB Genel Rapor"},
             new SelectListItem{ Value="11",Text="KİD Performans Raporu"}};

            ViewBag.BasvuruTipi = _uow.sozlukRepo.List(i => i.id.StartsWith("BTIP") && i.Durum == 1).Select(i => new SelectListItem { Value = i.id, Text = i.explanation });

            ViewBag.Birim = _uow.sozlukRepo.List(d => d.id.StartsWith("BRM")).Select(i => new SelectListItem { Value = i.id, Text = i.explanation });

            return View(rapor);
        }

        [HttpPost]
        public ActionResult GecikmeRaporGetir(string BasvuruTipi, string birim, string reservation)
        {
            Rapor rapor = new Rapor();
            List<GecikmeRaporu> gecikmerapor = _uow.gecikmeraporRepo.GecikmeRaporList(BasvuruTipi, birim, reservation);
            ViewBag.PerformansTur = new[]
          {
             new SelectListItem{ Value="KaynakDag",Text="Kaynak Dağılımı"},
              new SelectListItem{ Value="BirimBaz",Text="Birim Bazlı Dağılım"},
               new SelectListItem{ Value="BebSonuclari",Text="Beb işlem Sonuçları"},
                new SelectListItem{ Value="BebKonu",Text="Beb Konu Dağılımı"},
                 new SelectListItem{ Value="SGOKonu",Text="SGÖ Konu Dağılımı "}
           };
            ViewBag.Tur = new[]
          {
             new SelectListItem{ Value="BTIP02",Text="Bilgi Edinme Başvurusu"},
              new SelectListItem{ Value="BTIP01",Text="Şikayet ve İhbar Başvurusu"},
               new SelectListItem{ Value="Diger",Text="Diğer Başvurular"}
            };

            rapor.RaporTuruList = new[]{
                 //new SelectListItem{ Value="1",Text="Standart Rapor"},
                  new SelectListItem{ Value="2",Text="Gecikme Raporu", Selected=true},
                  new SelectListItem{ Value="3",Text="Performans Raporu"},
                  new SelectListItem{ Value="4",Text="Birim Süreç İstatistikleri "},
                  new SelectListItem{ Value="5",Text="Kurul Genel İstatistikleri "},
                  new SelectListItem{ Value="6",Text="İade İstatistikleri"},
                new SelectListItem{ Value="7",Text="Süresi İçerisinde Kapanmayan Başvurular"},
               new SelectListItem{ Value="8",Text="Birim Bazında Süresi İçerisinde Kapanmayan Başvurular"},
               new SelectListItem{ Value="9",Text="KİD Bilgi Edinme Ortalama İşlem Süreleri"},
                new SelectListItem{ Value="10",Text="BEB Genel Rapor"},
                new SelectListItem { Value = "11", Text = "KİD Performans Raporu" }}; ;

            ViewBag.BasvuruTipi = _uow.sozlukRepo.List(i => i.id.StartsWith("BTIP") && i.Durum == 1).Select(i => new SelectListItem { Value = i.id, Text = i.explanation });

            ViewBag.Birim = _uow.sozlukRepo.List(d => d.id.StartsWith("BRM")).Select(i => new SelectListItem { Value = i.id, Text = i.explanation });
            rapor.gecikmeRaporu = gecikmerapor;
            rapor.Raporlama = 2;

            string[] tarih = reservation.Split('-');
            rapor.reservationStart = tarih[0];
            rapor.reservationEnd = tarih[1];

            logManager.Log(OrtakSabitler.LOG_GECIKME_RAPORU, "");
            return View("Raporlama", rapor);
        }

        public ActionResult BirimSurecRaporu(string BirimSurecTur, string birimsurecreservation)
        {
            Rapor rapor = new Rapor();
            List<Sozluk> birimler = _uow.sozlukRepo.List(d => d.id.StartsWith("BRM"));
            List<BirimSurec> birimSurec = new List<BirimSurec>();
            foreach (Sozluk brm in birimler)
            {
                int ToplamKapaliBirimCevap = 0;
                int ToplamKapaliSuresiGecen = 0;
                int ToplamKapaliAdedi = 0;
                int ToplamKapaliBirimUzmanSure = 0; int ToplamKapaliBirimUzmanAdet = 0;
                int ToplamKapaliUzmanCevapSure = 0; int ToplamKapaliUzmanCevapAdet = 0;
                int ToplamKapaliUzmanBirimSure = 0; int ToplamKapaliUzmanBirimAdet = 0;
                int ToplamAcikBirimCevap = 0;
                int ToplamAcikSuresiGecen = 0;
                int ToplamAcikAdedi = 0;
                int ToplamAcikBirimUzmanSure = 0; int ToplamAcikBirimUzmanAdet = 0;
                int ToplamAcikUzmanCevapSure = 0; int ToplamAcikUzmanCevapAdet = 0;
                int ToplamAcikUzmanBirimSure = 0; int ToplamAcikUzmanBirimAdet = 0;
                List<IstatistikTarihler> IstatistikTarihler = _uow.IstatistikTarihlerRepo.BirimSureHesaplama(brm.id, BirimSurecTur, birimsurecreservation);
                foreach (IstatistikTarihler tarihler in IstatistikTarihler)
                {

                    if (tarihler.KapanisTarihi is null)
                    {
                        ToplamAcikAdedi++;
                        int brimCevap = GunHesapla(tarihler.LogIslemTarihi ?? DateTime.Today, tarihler.KapanisTarihi ?? DateTime.Today, Singleton.GetTatilInstance);
                        ToplamAcikBirimCevap += brimCevap;
                        if (brimCevap > 15)
                        {
                            ToplamAcikSuresiGecen++;
                            if (tarihler.YonTarih != null && tarihler.AtanmaTarihi != null)
                            {
                                int brimUzman = GunHesapla(tarihler.YonTarih ?? DateTime.Today, tarihler.AtanmaTarihi ?? DateTime.Today, Singleton.GetTatilInstance);
                                ToplamAcikBirimUzmanSure += brimUzman;
                                ToplamAcikBirimUzmanAdet++;
                                if (tarihler.IslemTarihi != null)
                                {
                                    int UzmanCevap = GunHesapla(tarihler.AtanmaTarihi ?? DateTime.Today, tarihler.IslemTarihi ?? DateTime.Today, Singleton.GetTatilInstance);
                                    ToplamAcikUzmanCevapSure += UzmanCevap;
                                    ToplamAcikUzmanCevapAdet++;
                                    if (tarihler.BasvuruCevapTarihi != null)
                                    {
                                        int UzmanBirimCevap = GunHesapla(tarihler.IslemTarihi ?? DateTime.Today, tarihler.BasvuruCevapTarihi ?? DateTime.Today, Singleton.GetTatilInstance);
                                        ToplamAcikUzmanBirimSure += UzmanBirimCevap;
                                        ToplamAcikUzmanBirimAdet++;
                                    }
                                }
                            }
                        }
                    }
                    else
                    {
                        ToplamKapaliAdedi++;
                        int brimCevap = BirimSurecTur.Equals(OrtakSabitler.BILGIEDINME_KOD) ? GunHesapla(tarihler.LogIslemTarihi ?? DateTime.Today, tarihler.KapanisTarihi ?? DateTime.Today, Singleton.GetTatilInstance) : ((tarihler.KapanisTarihi ?? DateTime.Today) - (tarihler.LogIslemTarihi ?? DateTime.Today)).Days;
                        ToplamKapaliBirimCevap += brimCevap;
                        if (brimCevap > 15)
                        {
                            ToplamKapaliSuresiGecen++;
                            if (tarihler.AtanmaTarihi != null)
                            {
                                int brimUzman = BirimSurecTur.Equals(OrtakSabitler.BILGIEDINME_KOD) ? GunHesapla(tarihler.YonTarih ?? DateTime.Today, tarihler.AtanmaTarihi ?? DateTime.Today, Singleton.GetTatilInstance) : ((tarihler.AtanmaTarihi ?? DateTime.Today) - (tarihler.YonTarih ?? DateTime.Today)).Days;
                                ToplamKapaliBirimUzmanSure += brimUzman;
                                ToplamKapaliBirimUzmanAdet++;
                                if (tarihler.IslemTarihi != null)
                                {
                                    int UzmanCevap = BirimSurecTur.Equals(OrtakSabitler.BILGIEDINME_KOD) ? GunHesapla(tarihler.AtanmaTarihi ?? DateTime.Today, tarihler.IslemTarihi ?? DateTime.Today, Singleton.GetTatilInstance) : ((tarihler.IslemTarihi ?? DateTime.Today) - (tarihler.AtanmaTarihi ?? DateTime.Today)).Days;
                                    ToplamKapaliUzmanCevapSure += UzmanCevap;
                                    ToplamKapaliUzmanCevapAdet++;
                                    if (tarihler.BasvuruCevapTarihi != null)
                                    {
                                        int UzmanBirimCevap = BirimSurecTur.Equals(OrtakSabitler.BILGIEDINME_KOD) ? GunHesapla(tarihler.IslemTarihi ?? DateTime.Today, tarihler.BasvuruCevapTarihi ?? DateTime.Today, Singleton.GetTatilInstance) : ((tarihler.BasvuruCevapTarihi ?? DateTime.Today) - (tarihler.IslemTarihi ?? DateTime.Today)).Days; ;
                                        ToplamKapaliUzmanBirimSure += UzmanBirimCevap;
                                        ToplamKapaliUzmanBirimAdet++;
                                    }
                                }
                            }
                        }
                    }


                }
                birimSurec.Add(new BirimSurec
                {
                    BirimAdi = brm.explanation,
                    KapaliAdedi = ToplamKapaliAdedi,
                    KapaliBirimCevapOrtSuresi = ToplamKapaliBirimCevap / (ToplamKapaliAdedi == 0 ? 1 : ToplamKapaliAdedi),
                    KapaliZamanıGecenAdedi = ToplamKapaliSuresiGecen,
                    KapaliBirimUzmanOrtSure = ToplamKapaliBirimUzmanSure / (ToplamKapaliBirimUzmanAdet == 0 ? 1 : ToplamKapaliBirimUzmanAdet),
                    KapaliUzmanCevapOrtSure = ToplamKapaliUzmanCevapSure / (ToplamKapaliUzmanCevapAdet == 0 ? 1 : ToplamKapaliUzmanCevapAdet),
                    KapaliUzmanBirimOrtSure = ToplamKapaliUzmanBirimSure / (ToplamKapaliUzmanBirimAdet == 0 ? 1 : ToplamKapaliUzmanBirimAdet),
                    AcikAdedi = ToplamAcikAdedi,
                    AcikBirimCevapOrtSuresi = ToplamAcikBirimCevap / (ToplamAcikAdedi == 0 ? 1 : ToplamAcikAdedi),
                    AcikZamanıGecenAdedi = ToplamAcikSuresiGecen,
                    AcikBirimUzmanOrtSure = ToplamAcikBirimUzmanSure / (ToplamAcikBirimUzmanAdet == 0 ? 1 : ToplamAcikBirimUzmanAdet),
                    AcikUzmanCevapOrtSure = ToplamAcikUzmanCevapSure / (ToplamAcikUzmanCevapAdet == 0 ? 1 : ToplamAcikUzmanCevapAdet),
                    AcikUzmanBirimOrtSure = ToplamAcikUzmanBirimSure / (ToplamAcikUzmanBirimAdet == 0 ? 1 : ToplamAcikUzmanBirimAdet)


                });

            }


            ViewBag.PerformansTur = new[]
           {
             new SelectListItem{ Value="KaynakDag",Text="Kaynak Dağılımı"},
              new SelectListItem{ Value="BirimBaz",Text="Birim Bazlı Dağılım"},
               new SelectListItem{ Value="BebSonuclari",Text="Beb işlem Sonuçları"},
                new SelectListItem{ Value="BebKonu",Text="Beb Konu Dağılımı"},
                 new SelectListItem{ Value="SGOKonu",Text="SGÖ Konu Dağılımı "}

           };
            ViewBag.Tur = new[]
          {
             new SelectListItem{ Value="BTIP02",Text="Bilgi Edinme Başvurusu"},
              new SelectListItem{ Value="BTIP01",Text="Şikayet ve İhbar Başvurusu"},
               new SelectListItem{ Value="BTIP03",Text="Diğer Başvurular"}
            };


            rapor.RaporTuruList = new[]{
                 //new SelectListItem{ Value="1",Text="Standart Rapor"},
                new SelectListItem{ Value="2",Text="Gecikme Raporu"},
                new SelectListItem{ Value="3",Text="Performans Raporu"},
                new SelectListItem{ Value="4",Text="Birim Süreç İstatistikleri "},
                new SelectListItem{ Value="5",Text="Kurul Genel İstatistikleri "},
                new SelectListItem{ Value="6",Text="İade İstatistikleri"},
                new SelectListItem{ Value="7",Text="Süresi İçerisinde Kapanmayan Başvurular"},
               new SelectListItem{ Value="8",Text="Birim Bazında Süresi İçerisinde Kapanmayan Başvurular"},
               new SelectListItem{ Value="9",Text="KİD Bilgi Edinme Ortalama İşlem Süreleri"},
                new SelectListItem{ Value="10",Text="BEB Genel Rapor"},
            new SelectListItem{ Value="11",Text="KİD Performans Raporu"}};

            ViewBag.BasvuruTipi = _uow.sozlukRepo.List(i => i.id.StartsWith("BTIP") && i.Durum == 1).Select(i => new SelectListItem { Value = i.id, Text = i.explanation });

            ViewBag.Birim = _uow.sozlukRepo.List(d => d.id.StartsWith("BRM")).Select(i => new SelectListItem { Value = i.id, Text = i.explanation });

            rapor.BirimSurec = birimSurec;
            rapor.Raporlama = 4;

            if (BirimSurecTur == "BTIP02")
                rapor.BasvuruTipi = "Bilgi Edinme Başvurusu";
            if (BirimSurecTur == "BTIP01")
                rapor.BasvuruTipi = "Şikayet ve İhbar Başvurusu";
            if (BirimSurecTur == "BTIP03")
                rapor.BasvuruTipi = "Diğer Başvurular";

            string[] tarih = birimsurecreservation.Split('-');
            rapor.birimsurecreservationStart = tarih[0];
            rapor.birimsurecreservationEnd = tarih[1];

            logManager.Log(OrtakSabitler.LOG_BIRIMSUREC_RAPORU, "");


            return View("Raporlama", rapor);
        }



        public int GunHesapla(DateTime basTarih, DateTime bitTarih, List<DateTime> TatilList)
        {
            Func<int, bool> isWorkingDay = days =>
            {
                var currentDate = basTarih.AddDays(days);
                var isNonWorkingDay =
                    currentDate.DayOfWeek == DayOfWeek.Saturday ||
                    currentDate.DayOfWeek == DayOfWeek.Sunday ||
                    TatilList.Exists(excludedDate => excludedDate.Date.Equals(currentDate.Date));
                return !isNonWorkingDay;
            };
            if (DateTime.Compare(bitTarih, basTarih) > 0)
            {
                return Enumerable.Range(0, (bitTarih - basTarih).Days).Count(isWorkingDay);
            }
            else
            {
                return (Enumerable.Range(0, Math.Abs((bitTarih - basTarih).Days)).Count(isWorkingDay)) * (-1);
            }
        }


        public ActionResult KurulGenelRaporu(string KurulGenelTur, string kurulgenelreservation)
        {
            Rapor rapor = new Rapor();
            List<Sozluk> birimler = _uow.sozlukRepo.List(d => d.id.StartsWith("BRM") && d.id != "BRM09" && d.id != "BRM00" && d.id != "BRM16");
            List<KurulGenel> kurulgenel = new List<KurulGenel>();
            foreach (Sozluk brm in birimler)
            {
                KurulGenel genel = _uow.KurulGenelIstatistikRepo.KurulGenelHesaplama(brm.explanation, KurulGenelTur, kurulgenelreservation);
                kurulgenel.Add(genel);


            }

            ViewBag.PerformansTur = new[]
           {
             new SelectListItem{ Value="KaynakDag",Text="Kaynak Dağılımı"},
              new SelectListItem{ Value="BirimBaz",Text="Birim Bazlı Dağılım"},
               new SelectListItem{ Value="BebSonuclari",Text="Beb işlem Sonuçları"},
                new SelectListItem{ Value="BebKonu",Text="Beb Konu Dağılımı"},
                 new SelectListItem{ Value="SGOKonu",Text="SGÖ Konu Dağılımı "}

           };
            ViewBag.Tur = new[]
          {
             new SelectListItem{ Value="BTIP02",Text="Bilgi Edinme Başvurusu"},
              new SelectListItem{ Value="BTIP01",Text="Şikayet ve İhbar Başvurusu"},
               new SelectListItem{ Value="BTIP03",Text="Diğer Başvurular"}
            };


            ViewBag.Raporlama = new[]{
                 //new SelectListItem{ Value="1",Text="Standart Rapor"},
                 new SelectListItem{ Value="2",Text="Gecikme Raporu"},
                 new SelectListItem{ Value="3",Text="Performans Raporu"},
                new SelectListItem{ Value="4",Text="Birim Süreç İstatistikleri "},
                new SelectListItem{ Value="5",Text="Kurul Genel İstatistikleri "},
                new SelectListItem{ Value="6",Text="İade İstatistikleri"},
                new SelectListItem{ Value="7",Text="Süresi İçerisinde Kapanmayan Başvurular"},
               new SelectListItem{ Value="8",Text="Birim Bazında Süresi İçerisinde Kapanmayan Başvurular"},
               new SelectListItem{ Value="9",Text="KİD Bilgi Edinme Ortalama İşlem Süreleri"},
                new SelectListItem{ Value="10",Text="BEB Genel Rapor"},
                new SelectListItem{ Value="11",Text="KİD Performans Raporu"}};

            ViewBag.BasvuruTipi = _uow.sozlukRepo.List(i => i.id.StartsWith("BTIP") && i.Durum == 1).Select(i => new SelectListItem { Value = i.id, Text = i.explanation });

            ViewBag.Birim = _uow.sozlukRepo.List(d => d.id.StartsWith("BRM")).Select(i => new SelectListItem { Value = i.id, Text = i.explanation });

            rapor.KurulGenel = kurulgenel;
            rapor.Raporlama = 5;

            if (KurulGenelTur == "BTIP02")
                rapor.BasvuruTipi = "Bilgi Edinme Başvurusu";
            if (KurulGenelTur == "BTIP01")
                rapor.BasvuruTipi = "Şikayet ve İhbar Başvurusu";
            if (KurulGenelTur == "BTIP03")
                rapor.BasvuruTipi = "Diğer Başvurular";

            string[] tarih = kurulgenelreservation.Split('-');
            rapor.kurulgenelreservationStart = tarih[0];
            rapor.kurulgenelreservationEnd = tarih[1];

            logManager.Log(OrtakSabitler.LOG_KURULGENEL_RAPORU, "");


            return View("Raporlama", rapor);
        }

        public ActionResult IadeRaporu(string iadereservation)
        {
            Rapor rapor = new Rapor();
            List<Sozluk> birimler = _uow.sozlukRepo.List(d => d.id.StartsWith("BRM"));

            List<IadeRapor> bebiaderapor = _uow.IadeRaporRepo.IadeHesaplama(OrtakSabitler.BILGIEDINME_KOD, iadereservation);
            List<IadeRapor> sikayetiaderapor = _uow.IadeRaporRepo.IadeHesaplama(OrtakSabitler.GORUS_ONERI_SIKAYET_KOD, iadereservation);
            List<IadeRapor> digeriaderapor = _uow.IadeRaporRepo.IadeHesaplama(OrtakSabitler.YATIRIMCI_GORUS_ONERI_SIKAYET_KOD, iadereservation);
            ToplamIadeRapor ToplamIade = new ToplamIadeRapor { bebiade = bebiaderapor, sikayetiade = sikayetiaderapor, digeriade = digeriaderapor };

            ViewBag.PerformansTur = new[]
           {
             new SelectListItem{ Value="KaynakDag",Text="Kaynak Dağılımı"},
              new SelectListItem{ Value="BirimBaz",Text="Birim Bazlı Dağılım"},
               new SelectListItem{ Value="BebSonuclari",Text="Beb işlem Sonuçları"},
                new SelectListItem{ Value="BebKonu",Text="Beb Konu Dağılımı"},
                 new SelectListItem{ Value="SGOKonu",Text="SGÖ Konu Dağılımı "}

           };
            ViewBag.Tur = new[]
          {
             new SelectListItem{ Value="BTIP02",Text="Bilgi Edinme Başvurusu"},
              new SelectListItem{ Value="BTIP01",Text="Şikayet ve İhbar Başvurusu"},
               new SelectListItem{ Value="BTIP03",Text="Diğer Başvurular"}
            };


            rapor.RaporTuruList = new[]{
                 //new SelectListItem{ Value="1",Text="Standart Rapor"},
                 new SelectListItem{ Value="2",Text="Gecikme Raporu"},
                 new SelectListItem{ Value="3",Text="Performans Raporu"},
                new SelectListItem{ Value="4",Text="Birim Süreç İstatistikleri "},
                new SelectListItem{ Value="5",Text="Kurul Genel İstatistikleri "},
                new SelectListItem{ Value="6",Text="İade İstatistikleri"},
                new SelectListItem{ Value="7",Text="Süresi İçerisinde Kapanmayan Başvurular"},
               new SelectListItem{ Value="8",Text="Birim Bazında Süresi İçerisinde Kapanmayan Başvurular"},
               new SelectListItem{ Value="9",Text="KİD Bilgi Edinme Ortalama İşlem Süreleri"},
                new SelectListItem{ Value="10",Text="BEB Genel Rapor"},
                new SelectListItem{ Value="11",Text="KİD Performans Raporu"}};

            ViewBag.BasvuruTipi = _uow.sozlukRepo.List(i => i.id.StartsWith("BTIP") && i.Durum == 1).Select(i => new SelectListItem { Value = i.id, Text = i.explanation });

            ViewBag.Birim = _uow.sozlukRepo.List(d => d.id.StartsWith("BRM")).Select(i => new SelectListItem { Value = i.id, Text = i.explanation });

            rapor.ToplamIadeRapor = ToplamIade;

            rapor.Raporlama = 6;

            string[] tarih = iadereservation.Split('-');
            rapor.iadereservationStart = tarih[0];
            rapor.iadereservationEnd = tarih[1];

            logManager.Log(OrtakSabitler.LOG_KURULGENEL_RAPORU, "");


            return View("Raporlama", rapor);
        }

        [HttpPost]
        public ActionResult PerformansRaporGetir(string PerformansTur, string perfreservation)
        {
            Rapor rapor = new Rapor();

            if (PerformansTur.Equals("KaynakDag"))
            {

                List<KaynakDagilimi> perfKaynakDag = _uow.kaynakDagraporRepo.PerfKaynakDagilimi(perfreservation);
                rapor.kaynakDagilim = perfKaynakDag;
                logManager.Log(OrtakSabitler.LOG_KAYNAKDAG_RAPORU, "");
            }
            else if (PerformansTur.Equals("BirimBaz"))
            {
                List<BirimBazliDagilim> perfBirimBazli = _uow.BirimBazliDagilimRepo.PerfBirimBazliDagilim(perfreservation);
                rapor.BirimBazliDagilim = perfBirimBazli;
                logManager.Log(OrtakSabitler.LOG_BIRIMBAZLI_RAPORU, "");
            }
            else if (PerformansTur.Equals("BebSonuclari"))
            {
                List<BEIslemlerinSonuclari> perfBeIslemSonuc = _uow.BEIslemlerinSonuclariRepo.PerfBEIslemlerinSonuclari(perfreservation);
                rapor.BEIslemlerinSonuclari = perfBeIslemSonuc;
                logManager.Log(OrtakSabitler.LOG_BEBSONUC_RAPORU, "");
            }
            else if (PerformansTur.Equals("BebKonu"))
            {
                List<BEKonuDagilimi> perfBeKonuDag = _uow.BEKonuDagilimiRepo.PerfBEKonuDagilimi(perfreservation);
                rapor.BEKonuDagilimi = perfBeKonuDag;
                logManager.Log(OrtakSabitler.LOG_BEBKONU_RAPORU, "");
            }
            else if (PerformansTur.Equals("SGOKonu"))
            {
                List<SGOKonuDagilimi> perfSGOKonuDag = _uow.SGOKonuDagilimiRepo.PerfSGOKonuDagilimi(perfreservation);
                rapor.SGOKonuDagilimi = perfSGOKonuDag;
                logManager.Log(OrtakSabitler.LOG_SGOKonu_RAPORU, "");
            }

            ViewBag.PerformansTur = new[]
          {
             new SelectListItem{ Value="KaynakDag",Text="Kaynak Dağılımı"},
              new SelectListItem{ Value="BirimBaz",Text="Birim Bazlı Dağılım"},
               new SelectListItem{ Value="BebSonuclari",Text="Beb işlem Sonuçları"},
                new SelectListItem{ Value="BebKonu",Text="Beb Konu Dağılımı"},
                 new SelectListItem{ Value="SGOKonu",Text="SGÖ Konu Dağılımı "}
           };
            ViewBag.Tur = new[]
          {
             new SelectListItem{ Value="BTIP02",Text="Bilgi Edinme Başvurusu"},
              new SelectListItem{ Value="BTIP01",Text="Şikayet ve İhbar Başvurusu"},
               new SelectListItem{ Value="BTIP03",Text="Diğer Başvurular"}
            };

            rapor.RaporTuruList = new[]{
                 //new SelectListItem{ Value="1",Text="Standart Rapor"},
                new SelectListItem{ Value="2",Text="Gecikme Raporu"},
                new SelectListItem{ Value="3",Text="Performans Raporu", Selected=true},
                new SelectListItem{ Value="4",Text="Birim Süreç İstatistikleri "},
                new SelectListItem{ Value="5",Text="Kurul Genel İstatistikleri "},
                new SelectListItem{ Value="6",Text="İade İstatistikleri"},
                new SelectListItem{ Value="7",Text="Süresi İçerisinde Kapanmayan Başvurular"},
               new SelectListItem{ Value="8",Text="Birim Bazında Süresi İçerisinde Kapanmayan Başvurular"},
               new SelectListItem{ Value="9",Text="KİD Bilgi Edinme Ortalama İşlem Süreleri"},
                new SelectListItem{ Value="10",Text="BEB Genel Rapor"},
                new SelectListItem{ Value="11",Text="KİD Performans Raporu"}};

            ViewBag.BasvuruTipi = _uow.sozlukRepo.List(i => i.id.StartsWith("BTIP") && i.Durum == 1).Select(i => new SelectListItem { Value = i.id, Text = i.explanation });

            ViewBag.Birim = _uow.sozlukRepo.List(d => d.id.StartsWith("BRM")).Select(i => new SelectListItem { Value = i.id, Text = i.explanation });

            rapor.Raporlama = 3;

            string[] tarih = perfreservation.Split('-');
            rapor.perfreservationStart = tarih[0];
            rapor.perfreservationEnd = tarih[1];

            return View("Raporlama", rapor);
        }

        public ActionResult SüresiGecenBasvurularRaporu(string suresigecenbasreservation)
        {
            Rapor rapor = new Rapor();
            //List<Sozluk> birimler = _uow.sozlukRepo.List(d => d.id.StartsWith("BRM") && d.id != "BRM09" && d.id != "BRM00" && d.id != "BRM16");
            List<SuresiGecenBasvurular> suresiGecenBasvurular = new List<SuresiGecenBasvurular>();

            suresiGecenBasvurular = _uow.SuresiGecenRaporRepo.SuresiGecenBasvurularHesaplama(suresigecenbasreservation);


            ViewBag.PerformansTur = new[]
           {
             new SelectListItem{ Value="KaynakDag",Text="Kaynak Dağılımı"},
              new SelectListItem{ Value="BirimBaz",Text="Birim Bazlı Dağılım"},
               new SelectListItem{ Value="BebSonuclari",Text="Beb işlem Sonuçları"},
                new SelectListItem{ Value="BebKonu",Text="Beb Konu Dağılımı"},
                 new SelectListItem{ Value="SGOKonu",Text="SGÖ Konu Dağılımı "}

           };
            ViewBag.Tur = new[]
          {
             new SelectListItem{ Value="BTIP02",Text="Bilgi Edinme Başvurusu"},
              new SelectListItem{ Value="BTIP01",Text="Şikayet ve İhbar Başvurusu"},
               new SelectListItem{ Value="BTIP03",Text="Diğer Başvurular"}
            };


            rapor.RaporTuruList = new[]{
                 //new SelectListItem{ Value="1",Text="Standart Rapor"},
                 new SelectListItem{ Value="2",Text="Gecikme Raporu"},
                 new SelectListItem{ Value="3",Text="Performans Raporu"},
                new SelectListItem{ Value="4",Text="Birim Süreç İstatistikleri "},
                new SelectListItem{ Value="5",Text="Kurul Genel İstatistikleri "},
                new SelectListItem{ Value="6",Text="İade İstatistikleri"},
                new SelectListItem{ Value="7",Text="Süresi İçerisinde Kapanmayan Başvurular"},
               new SelectListItem{ Value="8",Text="Birim Bazında Süresi İçerisinde Kapanmayan Başvurular"},
               new SelectListItem{ Value="9",Text="KİD Bilgi Edinme Ortalama İşlem Süreleri"},
                new SelectListItem{ Value="10",Text="BEB Genel Rapor"},
                new SelectListItem{ Value="11",Text="KİD Performans Raporu"}};

            ViewBag.BasvuruTipi = _uow.sozlukRepo.List(i => i.id.StartsWith("BTIP") && i.Durum == 1).Select(i => new SelectListItem { Value = i.id, Text = i.explanation });

            ViewBag.Birim = _uow.sozlukRepo.List(d => d.id.StartsWith("BRM")).Select(i => new SelectListItem { Value = i.id, Text = i.explanation });

            rapor.SuresiGecenBasvurular = suresiGecenBasvurular;

            rapor.Raporlama = 7;

            string[] tarih = suresigecenbasreservation.Split('-');
            rapor.suresigecenbasreservationStart = tarih[0];
            rapor.suresigecenbasreservationEnd = tarih[1];

            logManager.Log(OrtakSabitler.LOG_SURESIGECEN_RAPORU, "");


            return View("Raporlama", rapor);
        }
        public ActionResult BirimBazliSuresiGecenBasvurularRaporu(string brm, string birimbazlisuresigecenbasreservation)
        {
            Rapor rapor = new Rapor();
            //List<Sozluk> birimler = _uow.sozlukRepo.List(d => d.id.StartsWith("BRM") && d.id != "BRM09" && d.id != "BRM00" && d.id != "BRM16");
            List<BirimBazindaSuresiGecenBasvurular> suresiGecenBasvurular = new List<BirimBazindaSuresiGecenBasvurular>();

            suresiGecenBasvurular = _uow.BirimBazindaSuresiGecenRaporRepo.BirimBazindaSuresiGecenBasvurularHesaplama(brm, birimbazlisuresigecenbasreservation);


            ViewBag.PerformansTur = new[]
           {
             new SelectListItem{ Value="KaynakDag",Text="Kaynak Dağılımı"},
              new SelectListItem{ Value="BirimBaz",Text="Birim Bazlı Dağılım"},
               new SelectListItem{ Value="BebSonuclari",Text="Beb işlem Sonuçları"},
                new SelectListItem{ Value="BebKonu",Text="Beb Konu Dağılımı"},
                 new SelectListItem{ Value="SGOKonu",Text="SGÖ Konu Dağılımı "}

           };
            ViewBag.Tur = new[]
          {
             new SelectListItem{ Value="BTIP02",Text="Bilgi Edinme Başvurusu"},
              new SelectListItem{ Value="BTIP01",Text="Şikayet ve İhbar Başvurusu"},
               new SelectListItem{ Value="BTIP03",Text="Diğer Başvurular"}
            };


            rapor.RaporTuruList = new[]{
                 //new SelectListItem{ Value="1",Text="Standart Rapor"},
                 new SelectListItem{ Value="2",Text="Gecikme Raporu"},
                 new SelectListItem{ Value="3",Text="Performans Raporu"},
                new SelectListItem{ Value="4",Text="Birim Süreç İstatistikleri "},
                new SelectListItem{ Value="5",Text="Kurul Genel İstatistikleri "},
                new SelectListItem{ Value="6",Text="İade İstatistikleri"},
                new SelectListItem{ Value="7",Text="Süresi İçerisinde Kapanmayan Başvurular"},
               new SelectListItem{ Value="8",Text="Birim Bazında Süresi İçerisinde Kapanmayan Başvurular"},
               new SelectListItem{ Value="9",Text="KİD Bilgi Edinme Ortalama İşlem Süreleri"},
                new SelectListItem{ Value="10",Text="BEB Genel Rapor"},
                new SelectListItem{ Value="11",Text="KİD Performans Raporu"}};

            ViewBag.BasvuruTipi = _uow.sozlukRepo.List(i => i.id.StartsWith("BTIP") && i.Durum == 1).Select(i => new SelectListItem { Value = i.id, Text = i.explanation });

            ViewBag.Birim = _uow.sozlukRepo.List(d => d.id.StartsWith("BRM")).Select(i => new SelectListItem { Value = i.id, Text = i.explanation });

            rapor.BirimBazindaSuresiGecenBasvurular = suresiGecenBasvurular;

            rapor.Raporlama = 8;

            string[] tarih = birimbazlisuresigecenbasreservation.Split('-');
            rapor.birimbazlisuresigecenbasreservationStart = tarih[0];
            rapor.birimbazlisuresigecenbasreservationEnd = tarih[1];

            logManager.Log(OrtakSabitler.LOG_BIRIMBAZLISURESIGECEN_RAPORU, "");


            return View("Raporlama", rapor);
        }

        public ActionResult KIDOrtalamaSureRaporu(string kidortsurereservation)
        {
            Rapor rapor = new Rapor();
            //List<Sozluk> birimler = _uow.sozlukRepo.List(d => d.id.StartsWith("BRM") && d.id != "BRM09" && d.id != "BRM00" && d.id != "BRM16");
            List<KIDOrtSure> KIDOrtSureRapor = new List<KIDOrtSure>();

            KIDOrtSureRapor = _uow.KIDOrtSureRaporRepo.KIDOrtalamaSureHesaplama(kidortsurereservation);


            ViewBag.PerformansTur = new[]
           {
             new SelectListItem{ Value="KaynakDag",Text="Kaynak Dağılımı"},
              new SelectListItem{ Value="BirimBaz",Text="Birim Bazlı Dağılım"},
               new SelectListItem{ Value="BebSonuclari",Text="Beb işlem Sonuçları"},
                new SelectListItem{ Value="BebKonu",Text="Beb Konu Dağılımı"},
                 new SelectListItem{ Value="SGOKonu",Text="SGÖ Konu Dağılımı "}

           };
            ViewBag.Tur = new[]
          {
             new SelectListItem{ Value="BTIP02",Text="Bilgi Edinme Başvurusu"},
              new SelectListItem{ Value="BTIP01",Text="Şikayet ve İhbar Başvurusu"},
               new SelectListItem{ Value="BTIP03",Text="Diğer Başvurular"}
            };


            rapor.RaporTuruList = new[]{
                 //new SelectListItem{ Value="1",Text="Standart Rapor"},
                 new SelectListItem{ Value="2",Text="Gecikme Raporu"},
                 new SelectListItem{ Value="3",Text="Performans Raporu"},
                new SelectListItem{ Value="4",Text="Birim Süreç İstatistikleri "},
                new SelectListItem{ Value="5",Text="Kurul Genel İstatistikleri "},
                new SelectListItem{ Value="6",Text="İade İstatistikleri"},
                new SelectListItem{ Value="7",Text="Süresi İçerisinde Kapanmayan Başvurular"},
               new SelectListItem{ Value="8",Text="Birim Bazında Süresi İçerisinde Kapanmayan Başvurular"},
               new SelectListItem{ Value="9",Text="KİD Bilgi Edinme Ortalama İşlem Süreleri"},
                new SelectListItem{ Value="10",Text="BEB Genel Rapor"}};

            ViewBag.BasvuruTipi = _uow.sozlukRepo.List(i => i.id.StartsWith("BTIP") && i.Durum == 1).Select(i => new SelectListItem { Value = i.id, Text = i.explanation });

            ViewBag.Birim = _uow.sozlukRepo.List(d => d.id.StartsWith("BRM")).Select(i => new SelectListItem { Value = i.id, Text = i.explanation });

            rapor.KIDOrtSure = KIDOrtSureRapor;

            rapor.Raporlama = 9;

            string[] tarih = kidortsurereservation.Split('-');
            rapor.kidortsurereservationStart = tarih[0];
            rapor.kidortsurereservationEnd = tarih[1];

            logManager.Log(OrtakSabitler.LOG_KIDORTSURE_RAPORU, "");


            return View("Raporlama", rapor);
        }

        public ActionResult BEBGenelRapor(string bebgenelraporreservation)
        {
            Rapor rapor = new Rapor();
            List<Sozluk> birimler = _uow.sozlukRepo.List(d => d.id.StartsWith("BRM") && d.id != "BRM09" && d.id != "BRM00" && d.id != "BRM16");
            List<BEBGenelRapor> BEBGenelRapor = new List<BEBGenelRapor>();

            BEBGenelRapor = _uow.BEBGenelRaporRepo.BEBGenelRaporHesaplama(bebgenelraporreservation);


            ViewBag.PerformansTur = new[]
           {
             new SelectListItem{ Value="KaynakDag",Text="Kaynak Dağılımı"},
              new SelectListItem{ Value="BirimBaz",Text="Birim Bazlı Dağılım"},
               new SelectListItem{ Value="BebSonuclari",Text="Beb işlem Sonuçları"},
                new SelectListItem{ Value="BebKonu",Text="Beb Konu Dağılımı"},
                 new SelectListItem{ Value="SGOKonu",Text="SGÖ Konu Dağılımı "}

           };
            ViewBag.Tur = new[]
          {
             new SelectListItem{ Value="BTIP02",Text="Bilgi Edinme Başvurusu"},
              new SelectListItem{ Value="BTIP01",Text="Şikayet ve İhbar Başvurusu"},
               new SelectListItem{ Value="BTIP03",Text="Diğer Başvurular"}
            };


            rapor.RaporTuruList = new[]{
                 //new SelectListItem{ Value="1",Text="Standart Rapor"},
                 new SelectListItem{ Value="2",Text="Gecikme Raporu"},
                 new SelectListItem{ Value="3",Text="Performans Raporu"},
                new SelectListItem{ Value="4",Text="Birim Süreç İstatistikleri "},
                new SelectListItem{ Value="5",Text="Kurul Genel İstatistikleri "},
                new SelectListItem{ Value="6",Text="İade İstatistikleri"},
                new SelectListItem{ Value="7",Text="Süresi İçerisinde Kapanmayan Başvurular"},
               new SelectListItem{ Value="8",Text="Birim Bazında Süresi İçerisinde Kapanmayan Başvurular"},
               new SelectListItem{ Value="9",Text="KİD Bilgi Edinme Ortalama İşlem Süreleri"},
                new SelectListItem{ Value="10",Text="BEB Genel Rapor"}};


            ViewBag.BasvuruTipi = _uow.sozlukRepo.List(i => i.id.StartsWith("BTIP") && i.Durum == 1).Select(i => new SelectListItem { Value = i.id, Text = i.explanation });

            ViewBag.Birim = _uow.sozlukRepo.List(d => d.id.StartsWith("BRM")).Select(i => new SelectListItem { Value = i.id, Text = i.explanation });

            rapor.BEBGenelRapor = BEBGenelRapor;

            // rapor.BEBGenelRapor = new BEBGenelRapor();

            rapor.Raporlama = 10;

            string[] tarih = bebgenelraporreservation.Split('-');
            rapor.bebgenelraporreservationStart = tarih[0];
            rapor.bebgenelraporreservationEnd = tarih[1];

            logManager.Log(OrtakSabitler.LOG_BEBGENEL_RAPORU, "");


            return View("Raporlama", rapor);
        }

        [HttpPost]
        public ActionResult DosyaSil(decimal id, string viewname)
        {
            //IFile file;


            foreach (string fileName in Request.Files)
            {
                HttpPostedFileBase file = Request.Files[fileName];
                IFileUploader f = new FileUploader();
                if (f.Delete(id, file, viewname))
                {

                    logManager.Log(OrtakSabitler.LOG_DOSYA_SIL, viewname + " sayfasında dosya silme işlemi " + id + " li basvuru");
                    return null;
                }
                else
                {
                    return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
                }


            }
            return null;
        }

        public ActionResult DosyaEkle(decimal id, string viewname)
        {

            foreach (string fileName in Request.Files)
            {
                HttpPostedFileBase file = Request.Files[fileName];

                IFileUploader f = new FileUploader();
                if (f.Upload(id, file, viewname))
                {
                    logManager.Log(OrtakSabitler.LOG_DOSYA_EKLE, viewname + " sayfasında dosya ekleme işlemi " + id + " li basvuru");
                    return null;
                }
                else
                {
                    return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
                }

            }

            return null;

        }

        public FileResult DosyaGoster(int id, string tur)
        {
            byte[] fileBytes;
            string fileName;
            if (tur == "basvurugiris")
            {
                UploadedBasvuruGirisFile file = _uow.basvurugirisfileRepo.Find(x => x.id == id);
                fileBytes = file.filecontent;
                fileName = file.filename;
            }
            else
            {
                UploadedFile file = _uow.uploadedfileRepo.Find(x => x.id == id);
                fileBytes = file.filecontent;
                fileName = file.filename;
            }
            logManager.Log(OrtakSabitler.LOG_DOSYA_GORUNTULE, id + " li dosya görüntüleme");
            return File(fileBytes, System.Net.Mime.MediaTypeNames.Application.Octet, fileName);
        }

        public ActionResult GetAttachments(int id)
        {

            //Get the images list from repository
            var attachmentsList = _uow.uploadedfileRepo.List(x => x.basvuruid == id);
            //var jsonSerialiser = new JavaScriptSerializer(); 
            //var json = "";
            //var json = JsonConvert.SerializeObject(attachmentsList); 

            string json = JsonConvert.SerializeObject(attachmentsList, Formatting.Indented,
  new JsonSerializerSettings { ReferenceLoopHandling = ReferenceLoopHandling.Ignore });
            return Json(new { Data = json }, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public ActionResult YapilanIslerRapor(string yapilanislerreservation)
        {
            //var ogonul = User.Identity.Name;
            //if ((ogonul != "SPKDOM\\sickilli"))
            //{
            //    return new RedirectResult("/Base/YetkisizErisim");
            //}
            try
            {


                Rapor rapor = new Rapor();

                ViewBag.BasvuruTipi = _uow.sozlukRepo.List(i => i.id.StartsWith("BTIP") && i.Durum == 1).Select(i => new SelectListItem { Value = i.id, Text = i.explanation });
                ViewBag.Birim = _uow.sozlukRepo.List(d => d.id.StartsWith("BRM")).Select(i => new SelectListItem { Value = i.id, Text = i.explanation });
                ViewBag.PerformansTur = new[]
    {
             new SelectListItem{ Value="KaynakDag",Text="Kaynak Dağılımı"},
              new SelectListItem{ Value="BirimBaz",Text="Birim Bazlı Dağılım"},
               new SelectListItem{ Value="BebSonuclari",Text="Beb işlem Sonuçları"},
                new SelectListItem{ Value="BebKonu",Text="Beb Konu Dağılımı"},
                 new SelectListItem{ Value="SGOKonu",Text="SGÖ Konu Dağılımı "}

           };
                ViewBag.Tur = new[]
              {
             new SelectListItem{ Value="BTIP02",Text="Bilgi Edinme Başvurusu"},
              new SelectListItem{ Value="BTIP01",Text="Şikayet ve İhbar Başvurusu"},
               new SelectListItem{ Value="BTIP03",Text="Diğer Başvurular"}
            };
                rapor.RaporTuruList = new[]{
                 //new SelectListItem{ Value="1",Text="Standart Rapor"},
                 new SelectListItem{ Value="2",Text="Gecikme Raporu"},
                 new SelectListItem{ Value="3",Text="Performans Raporu"},
                new SelectListItem{ Value="4",Text="Birim Süreç İstatistikleri "},
                new SelectListItem{ Value="5",Text="Kurul Genel İstatistikleri "},
                new SelectListItem{ Value="6",Text="İade İstatistikleri"},
                new SelectListItem{ Value="7",Text="Süresi İçerisinde Kapanmayan Başvurular"},
               new SelectListItem{ Value="8",Text="Birim Bazında Süresi İçerisinde Kapanmayan Başvurular"},
               new SelectListItem{ Value="9",Text="KİD Bilgi Edinme Ortalama İşlem Süreleri"},
                new SelectListItem{ Value="10",Text="BEB Genel Rapor"},
            new SelectListItem{ Value="11",Text="KİD Performans Raporu"}};
                rapor.Raporlama = 11;

                if (yapilanislerreservation == null)
                {

                    return View("Raporlama", rapor);
                }


                var YapilanIslerSelect = rapor.YapilanIslerRapor;
                string[] tarih = yapilanislerreservation.Split('-');
                rapor.reservationStart = tarih[0];
                rapor.reservationEnd = tarih[1];
                string[] tarih0 = tarih[0].Split('/');
                string[] tarih1 = tarih[1].Split('/');

                string baslangictarihi = tarih0[0].Trim() + "-" + tarih0[1].Trim() + "-" + tarih0[2].Trim();
                string bitistarihi = tarih1[0].Trim() + "-" + tarih1[1].Trim() + "-" + tarih1[2].Trim();


                var bastar = DateTime.ParseExact(DateTime.Parse(baslangictarihi).ToString("yyyy-MM-dd"), "yyyy-MM-dd", System.Globalization.CultureInfo.InvariantCulture, System.Globalization.DateTimeStyles.None);
                var bittar = DateTime.ParseExact(DateTime.Parse(bitistarihi).ToString("yyyy-MM-dd"), "yyyy-MM-dd", System.Globalization.CultureInfo.InvariantCulture, System.Globalization.DateTimeStyles.None);

                var bastar2 = bastar.ToString("yyyy-MM-dd");
                var bittar2 = bittar.ToString("yyyy-MM-dd");

                ViewBag.bastar = bastar;
                ViewBag.bittar = bittar;
                ViewBag.tarih = yapilanislerreservation;


                BEBDb db = new BEBDb();
                var results = db.Database.SqlQuery<YapilanIslerRapor>("KidPerformansSP @BASTAR, @BITTAR", new SqlParameter("BASTAR", bastar2), new SqlParameter("BITTAR", bittar2)).ToList();

                rapor.YapilanIslerRapor = results != null && results.Any() ? results : new List<YapilanIslerRapor>() { };
                rapor.Raporlama = 11;

                return View("Raporlama", rapor);
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                throw;
            }
        }


        //09-03-2022 Sunay
        [HttpGet]
        public ActionResult SirketDegistir(string SirId, decimal? basvuruId)
        {
            Basvuru basvuru = _uow.basvuruRepo.Find(x => x.BASVURUID == basvuruId);
            string Tur = basvuru.BebListesi[0].BASVURUTIPI;

            basvuru.SIRKETID = SirId;
            _uow.basvuruRepo.Update(basvuru);
            ViewBag.SirketAdi = MersisApiService.Instance.SirketAdiBySirketID(SirId);
            Message("Şirket değiştirilmiştir.");


            return RedirectToAction("BasvuruDetay", new { id = basvuruId, tur = Tur });
        }

        //SUNAY

        public void MessageSuccess(string message, string code, bool dismissable = false)
        {

            AddAlert(AlertStyles.Success, message, code, dismissable);
        }

        public void MessageInformation(string message, string code, bool dismissable = false)
        {
            AddAlert(AlertStyles.Information, message, code, dismissable);
        }

        public void MessageWarning(string message, string code, bool dismissable = false)
        {
            AddAlert(AlertStyles.Warning, message, code, dismissable);
        }

        public void MessageDanger(string message, string code, bool dismissable = false)
        {
            AddAlert(AlertStyles.Danger, message, code, dismissable);
        }

        private void AddAlert(string alertStyle, string message, string code, bool dismissable)
        {
            var alert = new AlertMessage
            {
                AlertStyle = alertStyle,
                Message = message,
                Dismissable = dismissable
            };

            TempData[AlertMessage.TempDataKey] = alert;
        }
        public string GetControllerName()
        {
            return ControllerContext.RouteData.Values["controller"].ToString();
        }

        public string GetActionName()
        {
            return ControllerContext.RouteData.Values["action"].ToString();
        }

        public string GetUrlPath()
        {
            return System.Web.HttpContext.Current.Request.RawUrl;
        }

        public string GetIpAddress()
        {
            return System.Web.HttpContext.Current.Request.UserHostAddress;
        }
    }
}