﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Beb.Controllers
{
    public class UyariController : Controller
    {
        // GET: Uyari
        public ActionResult Index()
        {
            return View();
        }
        public ActionResult InvalidBrowser()
        {
            return View();
        }
    }
}