﻿using Beb.Filter;
using Beb.Mail;
using Beb.Models;
using Beb.Services;
using Beb.ViewModels;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.Entity;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Runtime.Serialization.Json;
using System.Text;
using System.Threading.Tasks;
using System.Web.Mvc;
using System.Web.UI.WebControls;

namespace Beb.Controllers
{
    [AuthFilter(Roles = "BEB")]
    [ActFilter]
    public class HomeController : BaseController
    {
        //private BEBDb database = new BEBDb();
        //private MersisApiService apiservice;
        public ActionResult Index()
        {

            //ViewBag.BasvuruTipleri = db.Beb.GroupBy(i => i.BasvuruTipiBilgisi).Select(g => new BasvuruSecenek { BasvuruBilgisi = g.Key.explanation, BasvuruCount = g.Count() }).ToList();
            //ViewBag.BasvuruTurleri = db.Beb.GroupBy(i => i.Sozluk).Select(g => new BasvuruSecenek { BasvuruBilgisi = g.Key.explanation, BasvuruCount = g.Count() }).ToList();
            return View();
        }
        [HttpGet]
        public ActionResult BasvuruGiris()
        {
            
            BasvuruViewBag();
            return View();
        }
        [HttpPost]
        public ActionResult BasvuruGiris(Basvuru model)
        {
            if (ModelState.IsValid)
            {
                if (model.TCKIMLIK.StartsWith("0"))
                {
                    model.TCKIMLIK = "0";
                }
                if (model.BebListesi[0].BASVURUTIPI.Equals("BTIP00") || model.BebListesi[0].BASVURUTURU.Equals("BTUR00") || model.KONU.Equals("id") || model.KONU.Equals("KON000000") || model.KONU.Equals("ONR000"))
                {
                    Message("Lütfen Başvuru Tipi , Türü , Konusu bilgilerini giriniz.");
                    BasvuruViewBag();
                    return View();
                }
                model.LOGKULLANICI = kullanici.username;
                model.BEBKAYITTARIHI = DateTime.Now;
                model.BebListesi[0].DURUM = OrtakSabitler.YENI_BASVURU_KOD;
                model.BebListesi[0].KURULICIDISI = OrtakSabitler.KURULICI_KOD;
                Basvuru basvuru = _uow.basvuruRepo.InsertObj(model);
                logManager.Log(OrtakSabitler.LOG_BASVURU_EKLE, "", basvuru);
                ViewBag.SirketAdi = ""; // MersisApiService.Instance.SirketAdiBySirketID(model.SIRKETID);
                Message("Kayıt Başarıyla Eklenmiştir.");
                BasvuruViewBag(model);
                return View(model);

            }
            else
            {
                Message("Kayıt Eklenememiştir.");
                if (model.SIRKETID != null)
                {
                    ViewBag.SirketAdi = ""; // MersisApiService.Instance.SirketAdiBySirketID(model.SIRKETID);
                }

                BasvuruViewBag();
                return View();
            }


        }

        public ActionResult BasvuruYonetimi()
        {
            ViewBag.CurrentPage = 0;
            BEBDb db = _uow.basvuruRepo.GetContext();
            var list = db.Basvuru.Join(db.Beb, b => b.BASVURUID, e => e.BASVURUID, (bas, beb) => new { bas = bas, beb = beb }).Where(basbeb => basbeb.beb.DURUM == OrtakSabitler.YENI_BASVURU_KOD).Select(i => i.bas);

            logManager.Log(OrtakSabitler.LOG_BEBYONETIM_GORUNTULE, "");
            ViewBag.Liste = OrtakSabitler.YENI_BASVURU_KOD;
            return View(list);
        }
        [HttpGet]
        public ActionResult BasvuruDetay(int id, string Tur, int? currentPage)
        {
            //ViewBag.DaireList = _uow.sozlukRepo.List(d => d.id.StartsWith("BRM"));
            ViewBag.DaireAdiList = _uow.sozlukRepo.List(d => d.id.StartsWith("BRM")).Select(i => new SelectListItem { Value = i.id, Text = i.explanation }).ToList();

            var listdaire = _uow.sozlukRepo.List(d => d.id.StartsWith("BRM"));
            ViewBag.Tur = Tur;
            ViewBag.CurrentPage = currentPage ?? 0;
            if (id == null) { return new HttpStatusCodeResult(HttpStatusCode.BadRequest); }
            Basvuru bs = _uow.basvuruRepo.Find(i => i.BASVURUID == id);
            if (bs == null) { return HttpNotFound(); }
            if (bs.BebListesi[0].DURUM == "BDUR01" || bs.BebListesi[0].DURUM == "BDUR05" && bs.BASVURUCEVAP != 1) //ONAYLANMIŞ BAŞVURU
            {
                if (bs.BebListesi[0].BASVURUCEVAPMAILI == null)
                {
                    StringBuilder basvuruBilgileri = new StringBuilder();
                    basvuruBilgileri.Append("<b>Sayın " + bs.ADSOYAD.ToUpper() + "<br> İlgi:" + String.Format("{0:dd.MM.yyyy}", bs.TARIH) + " Tarihli Başvurunuz" + " </b><br> ");



                    if (bs.BASVURUCEVAP != 1)
                        basvuruBilgileri.Append(System.Web.HttpUtility.HtmlDecode(System.Web.HttpUtility.HtmlDecode(bs.BebListesi[0].KAPANISMETNI ?? "".Replace("<p>", string.Empty)).Replace("</p>", string.Empty)) + "<br>" +
                        "Bilgilerinize sunulur.");


                    basvuruBilgileri.Append("<br>-----------------------------------------------------------------<br>");
                    basvuruBilgileri.Append("<b> Başvuru Sahibi:</b> " + bs.ADSOYAD + "<br>");
                    basvuruBilgileri.Append("<b> Başvuru Tipi:</b> " + (bs.BebListesi[0].BASVURUTIPI == "BTIP02" ? "Bilgi Edinme" : "Görüş, öneri ve şikayet") + "<br>");
                    basvuruBilgileri.Append("<b> Başvuru Tarihi:</b> " + String.Format("{0:dd.MM.yyyy hh:mm:ss}", bs.TARIH) + "<br>");
                    basvuruBilgileri.Append("<b>Başvuru Konusu:</b> " + bs.KonuSozluk.aciklama + "<br>");
                    basvuruBilgileri.Append("<b>Başvuru Sahibi E-Posta Adresi:</b> " + bs.EMAIL + "<br>");
                    basvuruBilgileri.Append("<b>Başvuru Sahibi Adresi:</b> " + bs.ADRES + "<br>");
                    if (bs.BebListesi[0].BASVURUTIPI == "BTIP02")
                        basvuruBilgileri.Append("<b>Başvuru İçeriği:</b> " + bs.BASVURUICERIK + "<br>" + OrtakSabitler.bebKanunu);
                    else
                        basvuruBilgileri.Append("<b>Başvuru İçeriği:</b> " + bs.BASVURUICERIK + "<br>");

                    bs.BebListesi[0].BASVURUCEVAPMAILI = basvuruBilgileri.ToString();

                }

            }

            var basvuruId = Convert.ToDecimal(bs.BASVURUID);
            var logbilgisi = _uow.LogRepo.Find(x => x.BasvuruId == basvuruId && x.DbsId != null && x.Aciklama == "Dbs tatafından beb onaylama");
            ViewBag.DbsAdSoyad = logbilgisi?.IslemYapan;
            ViewBag.SirketAdi = ""; // MersisApiService.Instance.SirketAdiBySirketID(model.SIRKETID);
            logManager.Log(OrtakSabitler.LOG_BASVURUDETAY_GORUNTULE, "", bs);

            BasvuruViewBag(bs);


            return View(bs);
        }
        [HttpPost]
        [ActFilter]
        public ActionResult BasvuruDetay(Basvuru model, string tagsDaireler, string daireKod)
        {
            ViewBag.DaireAdiList = _uow.sozlukRepo.List(d => d.id.StartsWith("BRM")).Select(i => new SelectListItem { Value = i.id, Text = i.explanation }).ToList();

            Basvuru basvuru = _uow.basvuruRepo.Find(x => x.BASVURUID == model.BASVURUID);

            //List<Tag> daireler = JsonConvert.DeserializeObject<List<Tag>>(tagsDaireler);//sunay kapattı 03-03-2022
            decimal bebid = basvuru.BebListesi[0].BEBID;




            if (basvuru != null)
            { //daire yönlendirme  
                //yeni eklenen basvuru ilk kez yönlendiriliyor. ddur==0
                List<Dbs> dbsListYeni = _uow.dbsRepo.List(d => d.BEBID == bebid && d.SONDURUM == "DDUR00");
                var dbsListMevcut = basvuru.BebListesi[0].DbsListesi.Where(x => x.SONDURUM != "DDUR00");

                List<Dbs> eklenecekList = new List<Dbs>();

                // Dbs
                var yenidbs = _uow.dbsRepo.Find(x => x.BEBID == bebid);

                //bir daire seçilmişse bir daire için dairedurum olustur.
                //iki daire için iki tane dairedurum olustur yapmam gerekiyor.
                string strSubject = "", strMessageBody = "";
                string aciklamaDaire = "";
                string mailmesaj = "";
                foreach (var ddurum in dbsListYeni)
                {
                    DaireDurumOlustur(OrtakSabitler.DAIRE_DURUM_DAIREYE_YONLENDIRILMIS, ddurum.DBSID, ddurum.BIRIMKAPATMETIN, ddurum.IADE);

                    

                    mailService.DbsMailIcerik(basvuru, "", OrtakSabitler.DBS_LINK, ddurum.DBSID, ref strSubject, ref strMessageBody);

                    bool mailGonderme = mailService.SendMail(yenidbs.YONEPOSTA, strSubject, strMessageBody);
                    if (mailGonderme)
                    {
                        mailmesaj = "Mail Gönderme işlemi başarıyla gerçekleşti.";
                    }
                    else
                    {
                        mailmesaj = "Mail Gönderilemedi.";
                    }

                }

               
                string code = "";
                foreach (var daire in dbsListYeni) //daireler >> yenyon yaptım.03-03-2022
                {
                    daire.SONDURUM = "DDUR03"; //durumları yönlendirilmişe çek.
                    var daireAdi = _uow.sozlukRepo.Find(x => x.id == daire.YONBIRIM).explanation;
                    aciklamaDaire += daireAdi + " ";
                    code = _uow.sozlukRepo.Find(x => x.explanation == daireAdi).id;
                    //mailService.DbsMailIcerik(basvuru, "", OrtakSabitler.DBS_LINK, daire.DBSID, ref strSubject, ref strMessageBody);

                    if (dbsListYeni.Any(d => d.YONBIRIM == code))
                    {
                        Dbs eski = dbsListYeni.Where(d => d.YONBIRIM == code && d.IADE == false).FirstOrDefault();
                        eklenecekList.Add(eski);

                        continue;
                    }
                                     

                    else
                    {
                        //Dbs yenidbs = new Dbs
                        //{
                        //    BEBID = basvuru.BebListesi[0].BEBID,
                        //    YONBIRIM = code,
                        //    YONTARIHI = DateTime.Now,
                        //    YONEPOSTA = (code == "BRM16" ? "beb@spk.gov.tr" : code == "BRM12" ? "beb_kob@spk.gov.tr" : "beb_" + daire.DAIREADI.ToLower() + "@spk.gov.tr")

                        //};
                        //Dbs yenidbs = _uow.dbsRepo.Find(x => x.BEBID == basvuru.BebListesi[0].BEBID);
                        eklenecekList.Add(yenidbs);
                        Dbs donendbs = yenidbs;//_uow.dbsRepo.InsertObj(yenidbs);

                        //DaireDurumOlustur(OrtakSabitler.DAIRE_DURUM_DAIREYE_YONLENDIRILMIS, yenidbs.DBSID, yenidbs.BIRIMKAPATMETIN, yenidbs.IADE);
                        //string strSubject = "", strMessageBody = "";
                        //mailService.DbsMailIcerik(basvuru, "", OrtakSabitler.DBS_LINK, donendbs.DBSID, ref strSubject, ref strMessageBody);

                        bool mailGonderme = mailService.SendMail(yenidbs.YONEPOSTA, strSubject, strMessageBody);
                        if (mailGonderme)
                        {
                            mailmesaj = "Mail Gönderme işlemi başarıyla gerçekleşti.";
                        }
                        else
                        {
                            mailmesaj = "Mail Gönderilemedi.";
                        }
                    }


                }

                //DaireDurumOlustur(OrtakSabitler.DAIRE_DURUM_DAIREYE_YONLENDIRILMIS, yenidbs.DBSID, yenidbs.BIRIMKAPATMETIN, yenidbs.IADE);
                basvuru.BebListesi[0].DURUM = OrtakSabitler.YONLENDIRILMIS_BASVURU_KOD;
                _uow.bebRepo.Update(basvuru.BebListesi[0]);

                var basvuruId = Convert.ToDecimal(basvuru.BASVURUID);
                var logbilgisi = _uow.LogRepo.Find(x => x.BasvuruId == basvuruId && x.DbsId != null && x.Aciklama == "Dbs tatafından beb onaylama");
                ViewBag.DbsAdSoyad = logbilgisi?.IslemYapan;
                ViewBag.SirketAdi = ""; // MersisApiService.Instance.SirketAdiBySirketID(model.SIRKETID);
                List<Dbs> silinecekdbs = dbsListYeni.Except(eklenecekList).ToList();
                _uow.dbsRepo.DeleteRange(silinecekdbs);


                Message("Basvuru Yönlendirme işlemi yapılmıştır." + mailmesaj + "");

                logManager.Log(OrtakSabitler.LOG_BASVURU_YONLENDIR, aciklamaDaire + " dairelerine yönlendirme yapıldı", basvuru);

                


            }
            else
            {
                ViewBag.SirketAdi = ""; // MersisApiService.Instance.SirketAdiBySirketID(model.SIRKETID);
                Message("Başvuru Yönlendirme yapılamadı.");
            }

            BasvuruViewBag(basvuru);
            return View(basvuru);


        }

        //02-03-2022 Sunay
        [HttpPost]
        public ActionResult YenidenYonlendirDaireEkle(Basvuru model, string id, decimal? basvuruId)
        {

            //daire eklendiğinde yeni tabloya kayıt at.
            //her eklemede dbs tablosuna da kayıt at.
            Basvuru basvuru = _uow.basvuruRepo.Find(x => x.BASVURUID == model.BASVURUID);

            ViewBag.SirketAdi = ""; // MersisApiService.Instance.SirketAdiBySirketID(model.SIRKETID);

            //yeni tabloya ekle
            decimal bebid = basvuru.BebListesi[0].BEBID;
            var daireCode = model.BebListesi.Select(x => x.Sozluk.id).FirstOrDefault();
            var daireAdi = _uow.sozlukRepo.List(x => x.id == daireCode).FirstOrDefault().explanation.ToString();
            //var basvuruId = Convert.ToInt32(basvuru.BASVURUID);
            string Tur = basvuru.BebListesi[0].BASVURUTIPI;
            Dbs dbs = _uow.dbsRepo.Find(x => x.BEBID == bebid && x.YONBIRIM == daireCode);

            ViewBag.DaireAdiList = _uow.sozlukRepo.List(d => d.id.StartsWith("BRM")).Select(i => new SelectListItem { Value = i.id, Text = i.explanation }).ToList();


            if (daireCode == null)
            {
                Message("Yönlendirilecek daireyi seçiniz.");

                BasvuruViewBag(basvuru);
                return View(basvuru);
            }

            if (dbs != null)
            {
                Message("Bu daire daha önce eklenmiştir. Kontrol ediniz.");

                BasvuruViewBag(basvuru);

                return RedirectToAction("BasvuruDetay", new { id = basvuruId, tur = Tur });

            }
            //dbsde kayıt yoksa kayıt ekle
            else
            {
                Dbs yenidbs = new Dbs
                {
                    BEBID = basvuru.BebListesi[0].BEBID,
                    YONBIRIM = daireCode,
                    YONTARIHI = DateTime.Now,
                    YONEPOSTA = (daireCode == "BRM16" ? "beb@spk.gov.tr" : daireCode == "BRM12" ? "beb_kob@spk.gov.tr" : "beb_" + daireAdi.ToLower() + "@spk.gov.tr"),
                    //YONEPOSTA= "sunay.ickilli@spk.gov.tr",
                    SONDURUM = "DDUR00" //SUNAY EKLEDİ 03-03-2022

                };
                Dbs donendbs = _uow.dbsRepo.InsertObj(yenidbs);
                

            }
            BasvuruViewBag(basvuru);
            logManager.Log("DaireEkle", "sonrası", basvuru, null, null);
            return RedirectToAction("BasvuruDetay", new { id = basvuruId, tur = Tur });
        }
        //03-03-2022 Sunay
        [HttpGet]
        public ActionResult YenidenYonlendir(Basvuru model, string id, decimal? basvuruId)
        {
            Basvuru basvuru = _uow.basvuruRepo.Find(x => x.BASVURUID == model.BASVURUID);
            decimal bebid = basvuru.BebListesi[0].BEBID;
            var daireCode = id;
            var dbsid = _uow.dbsRepo.Find(x => x.YONBIRIM == daireCode && x.BEBID == bebid).DBSID;
            string Tur = basvuru.BebListesi[0].BASVURUTIPI;


            logManager.Log("Yeniden Yönlendirmeden önce", "kapanışmetni: " + basvuru.BebListesi[0].KAPANISMETNI + "durum: " + basvuru.BebListesi[0].DURUM, basvuru, null, null);

            //dbstabloguncellenecek
            var dbstabloguncellenecek = _uow.dbsRepo.Find(x => x.BEBID == bebid && x.DBSID == dbsid);
            dbstabloguncellenecek.YONTARIHI = DateTime.Now;
            dbstabloguncellenecek.SONDURUM = OrtakSabitler.DAIRE_DURUM_DAIREYE_YONLENDIRILMIS; //yönlendirilmiş ddur03
            dbstabloguncellenecek.BIRIMKAPATMETIN = null;
            dbstabloguncellenecek.BASVURUCEVAPTARIHI = null;
            dbstabloguncellenecek.IADE = false;
            dbstabloguncellenecek.TOPLUCEVAPMI = null;
            _uow.dbsRepo.Update(dbstabloguncellenecek);

            DaireDurumOlustur(OrtakSabitler.DAIRE_DURUM_DAIREYE_YONLENDIRILMIS, dbstabloguncellenecek.DBSID, dbstabloguncellenecek.BIRIMKAPATMETIN, dbstabloguncellenecek.IADE);

            //bebguncellenecek
            var bebguncellenecek = _uow.bebRepo.Find(x => x.BEBID == bebid);
            bebguncellenecek.DURUM = OrtakSabitler.YONLENDIRILMIS_BASVURU_KOD; //yönlendirilmiş başvuru kod bdur03
            bebguncellenecek.KAPANISMETNI = null;

            _uow.bebRepo.Update(bebguncellenecek);

            logManager.Log("Yeniden Yönlendirmeden sonra", "işlem tamamlandı", basvuru, null, dbstabloguncellenecek);
            Message("Beb daireye yeniden yönlendirilmiştir.");

            string strSubject = "Cevaplanan Beb yeniden yönlendirilmiştir", strMessageBody = "";
            mailService.DbsMailIcerik(basvuru, "", OrtakSabitler.DBS_LINK, dbsid, ref strSubject, ref strMessageBody);

            return RedirectToAction("BasvuruDetay", new { id = basvuruId, tur = Tur });
        }
        [HttpPost]
        public ActionResult YenidenYonlendirSil(Basvuru model, string daireAdi)
        {
            Basvuru basvuru = _uow.basvuruRepo.Find(x => x.BASVURUID == model.BASVURUID);
            decimal bebid = basvuru.BebListesi[0].BEBID;
            var daireCode = _uow.sozlukRepo.Find(x => x.explanation == daireAdi).id;
            var basvuruId = Convert.ToInt32(basvuru.BASVURUID);
            var dbsid = _uow.dbsRepo.Find(x => x.YONBIRIM == daireCode && x.BEBID == bebid).DBSID;
            string Tur = basvuru.BebListesi[0].BASVURUTIPI;


            var dbstablodakisilinecek = _uow.dbsRepo.Find(x => x.BEBID == bebid && x.DBSID == dbsid);
            var dbsgorevtablodakisilinecek = _uow.dbsgorevliRepo.Find(x => x.DBSID == dbsid);

            logManager.Log("YenidenYönlendirmeSil-dbsgorevli kayit silindi",
                "silinmeden önce: " + "dbsId: " + dbsgorevtablodakisilinecek?.DBSID + "dbsgorevliId: " + dbsgorevtablodakisilinecek?.DBSGOREVLIID +
                "atayan: " + dbsgorevtablodakisilinecek?.ATAYAN + "atanmatar: " + dbsgorevtablodakisilinecek?.ATANMATARIHI +
                "adsoyad: " + dbsgorevtablodakisilinecek?.ADSOYAD + "islemtar: " + dbsgorevtablodakisilinecek?.ISLEMTARIHI +
                "kullaniciad: " + dbsgorevtablodakisilinecek?.KULLANICIADI + "metinonceki: " + dbsgorevtablodakisilinecek?.METINONCEKI +
                "metinsonraki: " + dbsgorevtablodakisilinecek?.METINSONRAKI, basvuru, null);

            logManager.Log("YenidenYönlendirmeSil-dbs kayit silindi",
                "silinmeden önce: " + "dbsId: " + dbstablodakisilinecek.DBSID + "bebId: " + dbstablodakisilinecek.BEBID +
                "BIRIMKAPATMETIN: " + dbstablodakisilinecek.BIRIMKAPATMETIN + "BASVURUCEVAPTARIHI: " + dbstablodakisilinecek.BASVURUCEVAPTARIHI +
                "SONDURUM: " + dbstablodakisilinecek.SONDURUM + "TOPLUCEVAPMI: " + dbstablodakisilinecek.TOPLUCEVAPMI +
                "YONBIRIM: " + dbstablodakisilinecek.YONBIRIM + "YONTARIHI: " + dbstablodakisilinecek.YONTARIHI +
                "IADE: " + dbstablodakisilinecek.IADE, basvuru, null, null);


            if (dbstablodakisilinecek != null)
            {
                _uow.dbsRepo.Delete(dbstablodakisilinecek);
            }
            if (dbsgorevtablodakisilinecek != null)
            {
                _uow.dbsgorevliRepo.Delete(dbsgorevtablodakisilinecek);
            }


            Message("Kayıt silinmiştir.");


            return RedirectToAction("BasvuruDetay", new { id = basvuruId, tur = Tur });
        }
        [HttpGet]
        public ActionResult YenidenYonlendirSilGet(string id, decimal? dbsId)
        {

            decimal basvuruId = Convert.ToDecimal(_uow.dbsRepo.Find(x => x.DBSID == dbsId).Beb.BASVURUID);

            Basvuru basvuru = _uow.basvuruRepo.Find(x => x.BASVURUID == basvuruId);
            decimal bebid = basvuru.BebListesi[0].BEBID;
            var daireCode = id; // _uow.sozlukRepo.Find(x => x.explanation == daireAdi).id;
            string Tur = basvuru.BebListesi[0].BASVURUTIPI;


            var dbstablodakisilinecek = _uow.dbsRepo.Find(x => x.BEBID == bebid && x.DBSID == dbsId);
            var dbsgorevtablodakisilinecek = _uow.dbsgorevliRepo.Find(x => x.DBSID == dbsId);

            logManager.Log("YenidenYönlendirmeSil-dbsgorevli kayit silindi",
                "silinmeden önce: " + "dbsId: " + dbsgorevtablodakisilinecek?.DBSID + "dbsgorevliId: " + dbsgorevtablodakisilinecek?.DBSGOREVLIID +
                "atayan: " + dbsgorevtablodakisilinecek?.ATAYAN + "atanmatar: " + dbsgorevtablodakisilinecek?.ATANMATARIHI +
                "adsoyad: " + dbsgorevtablodakisilinecek?.ADSOYAD + "islemtar: " + dbsgorevtablodakisilinecek?.ISLEMTARIHI +
                "kullaniciad: " + dbsgorevtablodakisilinecek?.KULLANICIADI + "metinonceki: " + dbsgorevtablodakisilinecek?.METINONCEKI +
                "metinsonraki: " + dbsgorevtablodakisilinecek?.METINSONRAKI, basvuru, null);

            logManager.Log("YenidenYönlendirmeSil-dbs kayit silindi",
                "silinmeden önce: " + "dbsId: " + dbstablodakisilinecek.DBSID + "bebId: " + dbstablodakisilinecek.BEBID +
                "BIRIMKAPATMETIN: " + dbstablodakisilinecek.BIRIMKAPATMETIN + "BASVURUCEVAPTARIHI: " + dbstablodakisilinecek.BASVURUCEVAPTARIHI +
                "SONDURUM: " + dbstablodakisilinecek.SONDURUM + "TOPLUCEVAPMI: " + dbstablodakisilinecek.TOPLUCEVAPMI +
                "YONBIRIM: " + dbstablodakisilinecek.YONBIRIM + "YONTARIHI: " + dbstablodakisilinecek.YONTARIHI +
                "IADE: " + dbstablodakisilinecek.IADE, basvuru, null, null);


            if (dbstablodakisilinecek != null)
            {
                _uow.dbsRepo.Delete(dbstablodakisilinecek);
            }
            if (dbsgorevtablodakisilinecek != null)
            {
                _uow.dbsgorevliRepo.Delete(dbsgorevtablodakisilinecek);
            }


            Message("Kayıt silinmiştir.");


            return RedirectToAction("BasvuruDetay", new { id = basvuruId, tur = Tur });
        }
        //04-03-2022 Sunay
        [HttpPost]
        public ActionResult YenidenYonlendirTarihce(decimal? dbsId, string yonbirimId)
        {
            var dbsList = _uow.dbsRepo.List(x => x.DBSID == dbsId && x.YONBIRIM == yonbirimId);
            var dairedurumList = _uow.dairedurumRepo.List(x => x.DBSID == dbsId && x.Dbs.YONBIRIM == yonbirimId)
                .Select(x => new
                {
                    x.Dbs.DBSID,
                    x.Dbs.YONBIRIM,
                    x.Dbs.YonBirimBilgisi.explanation,
                    x.Dbs.IADE,
                    x.Dbs.SONDURUM,
                    x.Dbs.TOPLUCEVAPMI,
                    x.Dbs.YONTARIHI,
                    x.Dbs.BIRIMKAPATMETIN,
                    x.Dbs.BEBID,
                    x.Dbs.BASVURUCEVAPTARIHI,
                    x.DAIREDURUM,
                    x.BIRIMKAPATMAMETNI,
                    x.IADE.Value,
                    x.KAYITTARIH
                });
            //return PartialView("_PartialDaireDurumGecmisi", dbsList);


            var result = JsonConvert.SerializeObject(dairedurumList);
            return Json(result, JsonRequestBehavior.AllowGet);
        }
        
        [HttpPost]
        public ActionResult BebGuncelle(string id, Basvuru model, string tagsDaireler)
        {
            if (id == null) { return new HttpStatusCodeResult(HttpStatusCode.BadRequest); }
            Basvuru bs = _uow.basvuruRepo.Find(i => i.BASVURUID == model.BASVURUID);
            ViewBag.DaireAdiList = _uow.sozlukRepo.List(d => d.id.StartsWith("BRM")).Select(i => new SelectListItem { Value = i.id, Text = i.explanation }).ToList();

            if (bs == null) { return HttpNotFound(); }
            string ViewName;
            if (id.Equals("basvurudetay"))
            {
                ViewName = "BasvuruDetay";
            }
            else
            {
                ViewName = "BasvuruGiris";
            }
            if (ModelState.IsValid)
            {
                if (model.TCKIMLIK.StartsWith("0"))
                {
                    model.TCKIMLIK = "0";
                }
                if (model.BebListesi[0].BASVURUTIPI.Equals("BTIP00") || model.BebListesi[0].BASVURUTURU.Equals("BTUR00") || model.KONU.Equals("id") || model.KONU.Equals("KON000000") || model.KONU.Equals("ONR000"))
                {
                    Message("Lütfen Başvuru Tipi , Türü , Konusu bilgilerini giriniz.");
                    BasvuruViewBag(bs);
                    return View(ViewName, bs);
                }
                bs.ADSOYAD = model.ADSOYAD;
                bs.TCKIMLIK = model.TCKIMLIK;
                bs.TARIH = model.TARIH;
                bs.LOGISLEMTARIH = model.LOGISLEMTARIH;
                bs.TEL = model.TEL;
                bs.CIMERBASVURUNO = model.CIMERBASVURUNO;
                bs.ADRES = model.ADRES;
                bs.BASVURUICERIK = model.BASVURUICERIK;
                bs.EMAIL = model.EMAIL;
                bs.IL = model.IL;
                bs.KONU = model.KONU;
                bs.ALTKONU = model.ALTKONU;
                bs.ALTALTKONU = model.ALTALTKONU;
                bs.BASVURUCEVAP = model.BASVURUCEVAP;
                bs.BASVURUICERIK = model.BASVURUICERIK;
                bs.BebListesi[0].BASVURUTURU = model.BebListesi[0].BASVURUTURU;
                bs.BebListesi[0].BASVURUTIPI = model.BebListesi[0].BASVURUTIPI;
                if (model.SIRKETID != null)
                {

                    ViewBag.SirketAdi = ""; // MersisApiService.Instance.SirketAdiBySirketID(model.SIRKETID);
                }
                bs.SIRKETID = model.SIRKETID;
                _uow.basvuruRepo.Update(bs);


                logManager.Log(OrtakSabitler.LOG_BEB_GUNCELLEME, "", model);
                Message("Basvuru Güncelleme işlemi yapılmıştır.");
            }
            else
            {
                ViewBag.SirketAdi = ""; // MersisApiService.Instance.SirketAdiBySirketID(model.SIRKETID);
                Message("Basvuru Güncelleme işlemi başarısızdır.");
            }
            BasvuruViewBag(bs);
            return View(ViewName, bs);


        }
        [HttpPost]
        [ValidateInput(false)]
        public ActionResult BebKapatma(Basvuru model)
        {
            if (model == null) { return new HttpStatusCodeResult(HttpStatusCode.BadRequest); }

            //Cevaplanmış başvuru kapatma  
            Models.Beb beb = _uow.bebRepo.Find(w => w.BASVURUID == model.BASVURUID);
            beb.DURUM = OrtakSabitler.KAPATILMIS_BASVURU_KOD;
            beb.KAPATMAACIKLAMASI = model.BebListesi[0].KAPATMAACIKLAMASI;
            beb.KAPANISTARIHI = model.BebListesi[0].KAPANISTARIHI;
            beb.BASVURUSONUC = model.BebListesi[0].BASVURUSONUC;
            beb.BASVURUSONUCACIKLAMA = model.BebListesi[0].BASVURUSONUCACIKLAMA;
            beb.KAPATANKULLANICI = kullanici.username;
            model.BebListesi[0].DURUM = OrtakSabitler.KAPATILMIS_BASVURU_KOD;
            _uow.bebRepo.Update(beb);
            Message("Basvuru Kapatılmıştır.");

            Basvuru basvuru = _uow.basvuruRepo.Find(w => w.BASVURUID == model.BASVURUID);
            logManager.Log(OrtakSabitler.LOG_BASVURU_KAPATMA, "", model);
            BasvuruViewBag(basvuru);
            return View("BasvuruDetay", basvuru);

        }
        public ActionResult BasvuruAra(string id, int? CurrentPage, string reservation)
        {
            ViewBag.CurrentPage = CurrentPage ?? 0;
            BEBDb db = _uow.basvuruRepo.GetContext();
            db = _uow.basvuruRepo.GetContext();
            List<Basvuru> list = null;

            if (id == OrtakSabitler.KAPATILMIS_BASVURU_KOD)
            {
                if (reservation == null)
                {
                    DateTime OneMonthsBeforeNow = DateTime.Now.AddMonths(-1);
                    var liste = db.Basvuru.Join(db.Beb, b => b.BASVURUID, e => e.BASVURUID, (bas, beb) => new { bas = bas, beb = beb }).Where(basbeb => basbeb.beb.DURUM == id && basbeb.beb.KAPANISTARIHI >= OneMonthsBeforeNow).Select(i => i.bas).ToList();
                    list = (List<Basvuru>)liste;
                    ViewBag.BasTarih = DateTime.Now.AddMonths(-1);
                    ViewBag.SonTarih = DateTime.Now;
                }
                else
                {
                    string[] tarih = reservation.Split('-');
                    string tarih1 = tarih[0]; DateTime ilktarih = DateTime.Parse(tarih1);
                    string tarih2 = tarih[1]; DateTime sontarih = DateTime.Parse(tarih2);
                    if (sontarih.Subtract(ilktarih).TotalDays <= 366)
                    {
                        var liste = db.Basvuru.Join(db.Beb, b => b.BASVURUID, e => e.BASVURUID, (bas, beb) => new { bas = bas, beb = beb }).Where(basbeb => basbeb.beb.DURUM == id && basbeb.beb.KAPANISTARIHI >= ilktarih && basbeb.beb.KAPANISTARIHI <= sontarih).Select(i => i.bas).ToList();
                        list = (List<Basvuru>)liste;

                    }
                    else
                    {
                        Message("Kapanış Tarih Aralığı en fazla 1 yıl olabilir.");
                        var liste = new List<Basvuru>();
                        list = (List<Basvuru>)liste;
                    }
                    ViewBag.BasTarih = tarih1;
                    ViewBag.SonTarih = tarih2;
                }
                ViewBag.Liste = id;
            }
            else if (id == "iadeEdilmisBasvuru")
            {
                // 1- durumu BDUR01, 04 olan başvurulardan yönlendirildiği dairelerden 
                // 2- en az birinde iade edildi durumu varsa (son tarihli duruma bakıyoruz) ve dbs tablosunda IADE=1 ve SOndurum=ddur06 ise ve
                // 3- yönlendirildiği dairelerden hiçbirinde cevaplandı yoksa bu listede gelsin. dbs tablosunda IADE=0 ve sondurum=ddur05 olmayacak

                // 2- dbs tablosunda bebidyi çek. basvuru cevap tarihine göre order et. son tarihliyi al ve durumuna bak. IADE==1 ve SONDURUM==DDUR06 ise
                // 3- Dbs tablosuna tekrar git ve IADE==0 ve sondurum==ddur05 olan bir durumu var mı ona bak.

                var bebList = db.Basvuru.Join(db.Beb, b => b.BASVURUID, e => e.BASVURUID, (bas, beb) => new { bas = bas, beb = beb })
                                                  .Where(basbeb => (basbeb.beb.DURUM == "BDUR01" || basbeb.beb.DURUM == "BDUR04"))
                                                  .Select(i => i.beb.BEBID).ToList(); //cevaplanmış ve yönlendirilmiş/daire cevabı bekliyor

                var dbsList = db.Dbs.Where(x => bebList.Contains(x.BEBID)).OrderByDescending(x => x.BASVURUCEVAPTARIHI).ToList();
                var dbsList2 = db.Dbs.Where(x => bebList.Contains(x.BEBID)).OrderByDescending(x => x.BASVURUCEVAPTARIHI).ToList();
                var returnBebList = new List<Dbs>();
                //iadesivar ve iadesiyok için
                //ikisinde de kayıt varsa cevaplandı.
                //iadesivarda kayıt var iadesiyokda kayıt yoksa iade edildi. bana bu lazım.
                //iadesivarda kayıt yok iadesiyokda kayıt varsa cevaplandı.
                //ikisinde de kayıt yoksa ne cevaplandı ne de iade edildi. hareket yok.
                var iadesivar = new List<Dbs>().FirstOrDefault();
                var iadesiyok = new List<Dbs>().FirstOrDefault();
                foreach (var item in dbsList)
                {
                    if (item.IADE == true && item.SONDURUM == "DDUR06")
                    {
                        var bebIdAl = item.BEBID;
                        var iadeEdilenBeb = dbsList.Where(x => x.BEBID == bebIdAl).ToList();
                        iadesivar = null;
                        iadesiyok = null;
                        foreach (var item2 in iadeEdilenBeb)
                        {

                            if (item2.IADE == true && item2.SONDURUM == "DDUR06")
                            {
                                iadesivar = item2;
                                //returnBebIdList.Add(item2.BEBID);
                            }
                            else if (item2.IADE == false && item2.SONDURUM == "DDUR05")
                            {
                                iadesiyok = item2;
                            }
                        }
                        if (iadesivar != null && iadesiyok == null)
                        {
                            returnBebList.Add(iadesivar);
                        }

                    }

                }
                var returnBebIds = returnBebList.Select(x => x.BEBID).ToList();
                var liste = db.Basvuru.Join(db.Beb, b => b.BASVURUID, e => e.BASVURUID, (bas, beb) => new { bas = bas, beb = beb }).Where(basbeb => returnBebIds.Contains(basbeb.beb.BEBID)).Select(i => i.bas).ToList();
                list = (List<Basvuru>)liste;
                //basvuruya gidip onu döndürücem list olarak.



                ViewBag.Liste = id;
            }

            else
            {

                var liste = db.Basvuru.Join(db.Beb, b => b.BASVURUID, e => e.BASVURUID, (bas, beb) => new { bas = bas, beb = beb }).Where(basbeb => basbeb.beb.DURUM == id).Select(i => i.bas).ToList();
                list = (List<Basvuru>)liste;
                ViewBag.Liste = id;
            }

            return View("BasvuruYonetimi", list);
        }
        [HttpPost]
        [ValidateInput(false)]
        public ActionResult BebOnayla(Basvuru basvuru)
        {
            if (basvuru == null) { return new HttpStatusCodeResult(HttpStatusCode.BadRequest); }
            ViewBag.DaireAdiList = _uow.sozlukRepo.List(d => d.id.StartsWith("BRM")).Select(i => new SelectListItem { Value = i.id, Text = i.explanation }).ToList();
            Basvuru bs = _uow.basvuruRepo.Find(x => x.BASVURUID == basvuru.BASVURUID);
            if (bs == null) { return HttpNotFound(); }
            string strSubject = "", strMessageBody = "";
            //mailService.DbsMailIcerik(basvuru, "", ref strSubject, ref strMessageBody); 
            List<UploadedFile> files = new List<UploadedFile>();
            if (bs.UploadedFiles != null)
            {
                foreach (var file in bs.UploadedFiles)
                {
                    files.Add(file);
                }
            }
            if (bs.EMAIL == null)
            {
                Message("basvuran kişinin mail adresini kontrol ediniz.");
            }
            else
            {
                bool mailGonderme = mailService.DisariSendMail(bs.EMAIL, "bilgi edinme", basvuru.BebListesi[0].BASVURUCEVAPMAILI, files);
                if (mailGonderme)
                {
                    Message("Mail Gönderme işlemi başarıyla gerçekleşti.");
                    bs.BebListesi[0].BASVURUCEVAPMAILI = basvuru.BebListesi[0].BASVURUCEVAPMAILI;
                    bs.BebListesi[0].ILGI = String.Format("{0:dd.MM.yyyy}", bs.TARIH) + " Tarihli Başvurunuz";
                    bs.BebListesi[0].MAILGONDERME = true;
                    _uow.basvuruRepo.Update(bs);
                }
                else
                {
                    Message("Mail Gönderilemedi.");
                }
            }

            BasvuruViewBag(bs);
            return View("BasvuruDetay", bs);
        }
        [HttpPost]
        [ValidateInput(false)]
        public ActionResult OnaylaMailGonderAktif(Basvuru basvuru)
        {
            if (basvuru == null) { return new HttpStatusCodeResult(HttpStatusCode.BadRequest); }
            Basvuru bs = _uow.basvuruRepo.Find(x => x.BASVURUID == basvuru.BASVURUID);
            if (bs == null) { return HttpNotFound(); }
            bs.BebListesi[0].MAILGONDERME = null;
            _uow.basvuruRepo.Update(bs);
            BasvuruViewBag(bs);
            return View("BasvuruDetay", bs);
        }
        public ActionResult IcerikAra(string id, string icerik)
        {

            ViewBag.CurrentPage = 0;
            BEBDb db = _uow.basvuruRepo.GetContext();
            var list = db.Basvuru.Join(db.Beb, b => b.BASVURUID, e => e.BASVURUID, (bas, beb) => new { bas = bas, beb = beb }).Where(basbeb => basbeb.beb.DURUM == id && basbeb.bas.BASVURUICERIK.Contains(icerik)).Select(i => i.bas);
            ViewBag.Icerik = icerik;
            ViewBag.Liste = id;
            logManager.Log(OrtakSabitler.LOG_ICERIK_ARA, icerik + " kelimesi basvuru içerik arama");
            return View("BasvuruYonetimi", list);
        }
        public ActionResult CevapAra(string icerik)
        {
            //LogOlustur(OrtakSabitler.LOG_BASVURU_KAPATMA, icerik +"kelimesinde arama yapılmıştır.");
            //List<Basvuru> basvurular = _uow.basvuruRepo.List(m => m.BASVURUICERIK.Contains(icerik));
            List<Models.Beb> Beblist = _uow.bebRepo.List(m => m.KAPANISMETNI.Contains(icerik));
            List<Basvuru> basvurular = new List<Basvuru>();
            foreach (Models.Beb beb in Beblist)
            {
                Basvuru bs = _uow.basvuruRepo.Find(m => m.BASVURUID == beb.BASVURUID);
                basvurular.Add(bs);
            }
            ViewBag.Cevap = icerik;
            logManager.Log(OrtakSabitler.LOG_ICERIK_ARA, icerik + " kelimesi basvuru cevap arama");
            return View("BasvuruYonetimi", basvurular);
        }
        public void BasvuruViewBag(Basvuru bs = null)
        {

            ViewBag.Kisi = _uow.sozlukRepo.List(i => i.id.StartsWith("TG") && i.Durum == 1).Select(i => new SelectListItem { Value = i.id, Text = i.explanation, Selected = i.id == "TG02" ? true : false }).ToList();
            ViewBag.DaireList = _uow.sozlukRepo.List(d => d.id.StartsWith("BRM"));
            ViewBag.BasvuruSonuc = _uow.bilgiedinmesozlukRepo.List(w => w.id.StartsWith("BSNC")).Select(i => new SelectListItem { Value = i.id, Text = i.aciklama });
            decimal bebid = (bs != null ? bs.BebListesi[0].BEBID : 0);
            string basvuruTuru = (bs != null ? bs.BebListesi[0].BASVURUTURU : "");
            string basvuruTipi = (bs != null ? bs.BebListesi[0].BASVURUTIPI : "");
            string konu = (bs != null ? bs.KONU : "");
            string altkonu = ((bs != null && bs.ALTKONU != "0") ? bs.ALTKONU : "");
            string altaltkonu = ((bs != null && bs.ALTALTKONU != "0") ? bs.ALTALTKONU : "");
            string il = (bs != null ? bs.IL : "");
            ViewBag.Gizli = (bs != null && bs.ADSOYAD == "Gizli" ? "Gizli" : "");
            ViewBag.Il = _uow.sozlukRepo.List(i => i.id.StartsWith("IL")).Select(i => new SelectListItem { Value = i.id, Text = i.explanation, Selected = i.id == il ? true : false });
            ViewBag.BasvuruTuru = _uow.sozlukRepo.List(i => i.id.StartsWith("BTUR") && i.Durum == 1).Select(i => new SelectListItem { Value = i.id, Text = i.explanation, Selected = i.id == basvuruTuru ? true : false });
            ViewBag.BasvuruTipi = _uow.sozlukRepo.List(i => i.id.StartsWith("BTIP") && i.Durum == 1).Select(i => new SelectListItem { Value = i.id, Text = i.explanation, Selected = i.id == basvuruTipi ? true : false });
            //sunay ekledi 24-02-2022
            var dbsdekiDurum = _uow.dbsRepo.List(b => b.BEBID == bebid && b.IADE == false); //iade edilmemiş
            if (dbsdekiDurum.Count() > 0)
            {
                ViewBag.SeciliDaireler = _uow.dbsRepo.List(b => b.BEBID == bebid && b.IADE == false).Select(n => new SelectListItem { Text = n.YonBirimBilgisi.explanation, Value = n.YONBIRIM });

            }
            else
            {

                ViewBag.SeciliDaireler = _uow.dbsRepo.List(b => b.BEBID == bebid && b.IADE == true).Select(n => new SelectListItem { Text = n.YonBirimBilgisi.explanation, Value = n.YONBIRIM });
            }
            //sunay ekledi bitti 24-02-2022 
            //sunay kapattı 24-02-2022
            //ViewBag.SeciliDaireler = _uow.dbsRepo.List(b => b.BEBID == bebid && b.IADE == false).Select(n => new SelectListItem { Text = n.YonBirimBilgisi.explanation, Value = n.YONBIRIM });
            //sunay kapattı bitti 24-02-2022
            ViewBag.Daire = kullanici.daire;
            if (bs?.SIRKETID != null)
            {
                ViewBag.SirketAdi = ""; // MersisApiService.Instance.SirketAdiBySirketID(model.SIRKETID);
            }


            //ViewBag.SirketAdi = apiservice.SirketAdi(bs.SIRKETID);
            if (basvuruTipi != null && !basvuruTipi.Equals("") && !basvuruTipi.Equals("BTIP00"))
            {
                var basKonu = GetKonu(basvuruTipi);
                if (basKonu.Data != null)
                {
                    List<SelectListItem> Konular = new List<SelectListItem>();
                    foreach (BilgiEdinmeSozluk t in (List<BilgiEdinmeSozluk>)basKonu.Data)
                    {
                        Konular.Add(new SelectListItem()
                        {
                            Text = t.aciklama,
                            Value = t.id,
                            Selected = t.id == konu ? true : false
                        });

                    }
                    ViewBag.Konu = Konular.Select(i => new SelectListItem { Value = i.Value, Text = i.Text, Selected = i.Value == konu ? true : false });
                }
                else
                {
                    ViewBag.Konu = null;
                }

            }
            else
            {
                ViewBag.Konu = null;
            }


            if (konu != null && !konu.Equals("") && !konu.Equals("id"))
            {
                var altkonular = GetAltKonu(konu);
                if (altkonular.Data != null)
                {
                    List<SelectListItem> AltKonular = new List<SelectListItem>();
                    foreach (BilgiEdinmeSozluk t in (List<BilgiEdinmeSozluk>)altkonular.Data)
                    {
                        AltKonular.Add(new SelectListItem()
                        {
                            Text = t.aciklama,
                            Value = t.id,
                            Selected = t.id == altkonu ? true : false
                        });

                    }
                    ViewBag.AltKonu = AltKonular.Select(i => new SelectListItem { Value = i.Value, Text = i.Text, Selected = i.Value == konu ? true : false });
                }

            }
            else
            {
                ViewBag.AltKonu = _uow.bilgiedinmesozlukRepo.List().Select(i => new SelectListItem { Value = i.id, Text = i.aciklama });
            }
            if (altkonu != null && !altkonu.Equals(""))
            {
                var altaltkonular = GetAltAltKonu(altkonu);
                if (altaltkonular.Data != null)
                {
                    List<SelectListItem> AltAltKonular = new List<SelectListItem>();
                    foreach (BilgiEdinmeSozluk t in (List<BilgiEdinmeSozluk>)altaltkonular.Data)
                    {
                        AltAltKonular.Add(new SelectListItem()
                        {
                            Text = t.aciklama,
                            Value = t.id,
                            Selected = t.id == altkonu ? true : false
                        });

                    }
                    ViewBag.AltAltKonu = AltAltKonular.Select(i => new SelectListItem { Value = i.Value, Text = i.Text, Selected = i.Value == konu ? true : false });
                }

            }
            else
            {
                ViewBag.AltAltKonu = _uow.bilgiedinmesozlukRepo.List().Select(i => new SelectListItem { Value = i.id, Text = i.aciklama });
            }


            //ViewBag.AltAltKonu = _uow.bilgiedinmesozlukRepo.List().Select(i => new SelectListItem { Value = i.id, Text = i.aciklama, Selected = i.id == altaltkonu ? true : false });
            //YeniBasvuruViewModel vm = new YeniBasvuruViewModel(parametres); 
            int? sonuc = (bs != null ? bs.BebListesi[0].BASVURUSONUC : 0);
            ViewBag.BasvuruSonuc = new List<SelectListItem>
                                        {
                                        new SelectListItem{ Text="Olumlu", Value = "1", Selected = sonuc == 1 ? true : false},
                                        new SelectListItem{ Text="Kısmen Olumlu", Value = "2" ,Selected = sonuc == 2 ? true : false},
                                        new SelectListItem{ Text="Red", Value = "3",Selected = sonuc == 3 ? true : false }

                                    };

            if (bs != null && bs.BebListesi[0].MAILGONDERME.HasValue == true)
            {

                ViewBag.CevapMaili = "";

            }
            else
            {
                ViewBag.CevapMaili = "MAILBOS";
            }

            //RedirectToAction("Görüntüle", vm);
        }
        public ActionResult YapilanIslerRaporDetails(string id, int? CurrentPage, string tarih)
        {
            Rapor rapor = new Rapor();
            rapor.Raporlama = 11;
            ViewBag.CurrentPage = CurrentPage ?? 0;
            ViewBag.PerformansTur = new[]
           {
             new SelectListItem{ Value="KaynakDag",Text="Kaynak Dağılımı"},
              new SelectListItem{ Value="BirimBaz",Text="Birim Bazlı Dağılım"},
               new SelectListItem{ Value="BebSonuclari",Text="Beb işlem Sonuçları"},
                new SelectListItem{ Value="BebKonu",Text="Beb Konu Dağılımı"},
                 new SelectListItem{ Value="SGOKonu",Text="SGÖ Konu Dağılımı "}

           };
            ViewBag.Tur = new[]
          {
             new SelectListItem{ Value="BTIP02",Text="Bilgi Edinme Başvurusu"},
              new SelectListItem{ Value="BTIP01",Text="Şikayet ve İhbar Başvurusu"},
               new SelectListItem{ Value="BTIP03",Text="Diğer Başvurular"}
            };
            rapor.RaporTuruList = new[]{
                 //new SelectListItem{ Value="1",Text="Standart Rapor"},
                 new SelectListItem{ Value="2",Text="Gecikme Raporu"},
                 new SelectListItem{ Value="3",Text="Performans Raporu"},
                new SelectListItem{ Value="4",Text="Birim Süreç İstatistikleri "},
                new SelectListItem{ Value="5",Text="Kurul Genel İstatistikleri "},
                new SelectListItem{ Value="6",Text="İade İstatistikleri"},
                new SelectListItem{ Value="7",Text="Süresi İçerisinde Kapanmayan Başvurular"},
               new SelectListItem{ Value="8",Text="Birim Bazında Süresi İçerisinde Kapanmayan Başvurular"},
               new SelectListItem{ Value="9",Text="KİD Bilgi Edinme Ortalama İşlem Süreleri"},
                new SelectListItem{ Value="10",Text="BEB Genel Rapor"},
                new SelectListItem{ Value="11",Text="KİD Performans Raporu"}};
            rapor.Raporlama = 11;
            ViewBag.BasvuruTipi = _uow.sozlukRepo.List(i => i.id.StartsWith("BTIP") && i.Durum == 1).Select(i => new SelectListItem { Value = i.id, Text = i.explanation });
            ViewBag.Birim = _uow.sozlukRepo.List(d => d.id.StartsWith("BRM")).Select(i => new SelectListItem { Value = i.id, Text = i.explanation });
            ViewBag.tarih = tarih;


            string[] raporLink = id.Split(' ');
            string raporAdi = raporLink[0];
            string personelAd = raporLink[1];

            string[] tarihparcalari = tarih.Split('-');
            string tarih1 = tarihparcalari[0].Trim();
            string tarih2 = tarihparcalari[1].Trim();

            var bastar = DateTime.ParseExact(DateTime.Parse(tarih1).ToString("yyyy-MM-dd"), "yyyy-MM-dd", System.Globalization.CultureInfo.InvariantCulture, System.Globalization.DateTimeStyles.None);
            var bittar = DateTime.ParseExact(DateTime.Parse(tarih2).ToString("yyyy-MM-dd"), "yyyy-MM-dd", System.Globalization.CultureInfo.InvariantCulture, System.Globalization.DateTimeStyles.None);

            var bastar2 = bastar.ToString("yyyy-MM-dd");
            var bittar2 = bittar.ToString("yyyy-MM-dd");


            BEBDb db = new BEBDb();
            var results = db.Database.SqlQuery<YapilanIslerRaporDetails>("KidPerformansDetailsSP @BASTAR, @BITTAR, @id, @USERADI", new SqlParameter("BASTAR", bastar2), new SqlParameter("BITTAR", bittar2), new SqlParameter("id", id), new SqlParameter("USERADI", personelAd)).ToList();



            List<YapilanIslerRaporDetails> detailsList = new List<YapilanIslerRaporDetails>();
            foreach (var item in results)
            {
                YapilanIslerRaporDetails details = new YapilanIslerRaporDetails();
                details.ADSOYAD = item.ADSOYAD;
                details.BASVURUID = item.BASVURUID;
                details.BASVURUTIPI = item.BASVURUTIPI;
                details.BASVURUTURU = item.BASVURUTURU;
                details.BEBKAYITTARIHI = item.BEBKAYITTARIHI;
                details.CIMERBASVURUNO = item.CIMERBASVURUNO;
                details.DURUM = item.DURUM;
                details.ID = item.ID;
                details.KAPANISTARIHI = item.KAPANISTARIHI;
                details.KONU = item.KONU;
                details.TARIH = item.TARIH;
                details.TCKIMLIK = item.TCKIMLIK;
                detailsList.Add(details);

            }


            return View(detailsList);

        }
        public ActionResult YapilanIsler(string id, int? CurrentPage, string tarih)
        {
            Rapor rapor = new Rapor();
            rapor.Raporlama = 11;
            ViewBag.CurrentPage = CurrentPage ?? 0;
            ViewBag.PerformansTur = new[]
           {
             new SelectListItem{ Value="KaynakDag",Text="Kaynak Dağılımı"},
              new SelectListItem{ Value="BirimBaz",Text="Birim Bazlı Dağılım"},
               new SelectListItem{ Value="BebSonuclari",Text="Beb işlem Sonuçları"},
                new SelectListItem{ Value="BebKonu",Text="Beb Konu Dağılımı"},
                 new SelectListItem{ Value="SGOKonu",Text="SGÖ Konu Dağılımı "}

           };
            ViewBag.Tur = new[]
          {
             new SelectListItem{ Value="BTIP02",Text="Bilgi Edinme Başvurusu"},
              new SelectListItem{ Value="BTIP01",Text="Şikayet ve İhbar Başvurusu"},
               new SelectListItem{ Value="BTIP03",Text="Diğer Başvurular"}
            };
            rapor.RaporTuruList = new[]{
                 //new SelectListItem{ Value="1",Text="Standart Rapor"},
                 new SelectListItem{ Value="2",Text="Gecikme Raporu"},
                 new SelectListItem{ Value="3",Text="Performans Raporu"},
                new SelectListItem{ Value="4",Text="Birim Süreç İstatistikleri "},
                new SelectListItem{ Value="5",Text="Kurul Genel İstatistikleri "},
                new SelectListItem{ Value="6",Text="İade İstatistikleri"},
                new SelectListItem{ Value="7",Text="Süresi İçerisinde Kapanmayan Başvurular"},
               new SelectListItem{ Value="8",Text="Birim Bazında Süresi İçerisinde Kapanmayan Başvurular"},
               new SelectListItem{ Value="9",Text="KİD Bilgi Edinme Ortalama İşlem Süreleri"},
                new SelectListItem{ Value="10",Text="BEB Genel Rapor"},
                new SelectListItem{ Value="11",Text="KİD Performans Raporu"}};
            ViewBag.BasvuruTipi = _uow.sozlukRepo.List(i => i.id.StartsWith("BTIP") && i.Durum == 1).Select(i => new SelectListItem { Value = i.id, Text = i.explanation });
            ViewBag.Birim = _uow.sozlukRepo.List(d => d.id.StartsWith("BRM")).Select(i => new SelectListItem { Value = i.id, Text = i.explanation });
            ViewBag.tarih = tarih;

            //BEBDb db = _uow.basvuruRepo.GetContext();
            //db = _uow.basvuruRepo.GetContext();
            //List<Basvuru> listbas = null;
            //List<Beb.Models.Beb> listbeb = null;

            YapilanIsler model = new YapilanIsler();

            string[] raporLink = id.Split(' ');
            string raporAdi = raporLink[0];
            string personelAd = raporLink[1];

            string[] tarihparcalari = tarih.Split('-');
            string tarih1 = tarihparcalari[0].Trim();
            string tarih2 = tarihparcalari[1].Trim();

            var bastar = DateTime.ParseExact(DateTime.Parse(tarih1).ToString("yyyy-MM-dd"), "yyyy-MM-dd", System.Globalization.CultureInfo.InvariantCulture, System.Globalization.DateTimeStyles.None);
            var bittar = DateTime.ParseExact(DateTime.Parse(tarih2).ToString("yyyy-MM-dd"), "yyyy-MM-dd", System.Globalization.CultureInfo.InvariantCulture, System.Globalization.DateTimeStyles.None);


            //sunay

            var kidPersonel = _uow.KullaniciRolRepo.List(x => x.BIRIMID == "BRM15").Select(x => new { x.BIRIMID, x.USERADID }).ToList();

            var kapatanKullanici = string.Empty;
            var cimerGiden = _uow.bebRepo.List(x => x.DURUM == "BDUR05").ToList();
            var cimerGelen = _uow.basvuruRepo.List(x => x.CIMERBASVURUNO != null && x.LOGKULLANICI != "internet").ToList();
            var edevletGelen = _uow.basvuruRepo.List(x => x.CIMERBASVURUNO == null && x.LOGKULLANICI == "internet").ToList();
            var edevletGiden = _uow.bebRepo.List(x => x.DURUM == "BDUR05").ToList();

            var dairenincevapYazdigiBebler = _uow.dbsRepo.List(y => y.IADE == false).Select(x => x.BEBID).Distinct().ToList();

            List<YapilanIslerRapor> listeson = new List<YapilanIslerRapor>();

            YapilanIslerRapor yir = new YapilanIslerRapor();
            cimerGiden = _uow.bebRepo.List(x => x.DURUM == "BDUR05" && x.KAPATANKULLANICI == personelAd).ToList();
            cimerGelen = _uow.basvuruRepo.List(x => x.CIMERBASVURUNO != null && x.LOGKULLANICI != "internet" && x.LOGKULLANICI == personelAd && x.TARIH >= bastar && x.TARIH <= bittar).ToList();
            edevletGelen = _uow.basvuruRepo.List(x => x.CIMERBASVURUNO == null && x.LOGKULLANICI == personelAd && x.TARIH >= bastar && x.TARIH <= bittar).ToList();
            edevletGiden = _uow.bebRepo.List(x => x.Basvuru.CIMERBASVURUNO == null && x.DURUM == "BDUR05" && x.KAPATANKULLANICI == personelAd && x.Basvuru.TARIH >= bastar && x.Basvuru.TARIH <= bittar).ToList();

            listeson.Add(yir);

            if (raporAdi == "CimerGelen")
            {
                model.listbas = cimerGelen;

                return View(model);

            }
            if (raporAdi == "CimerGiden")
            {
                model.listbeb = cimerGiden;
                return View(model);
            }
            if (raporAdi == "BebGelen")
            {
                model.listbas = edevletGelen;

                return View(model);
            }
            if (raporAdi == "BebGiden")
            {
                model.listbeb = edevletGiden;

                return View(model);
            }

            logManager.Log(OrtakSabitler.LOG_KID_PERFORMANS_RAPORU_YAPILANISLER_SHOW, "");

            //bitti sunay
            return View(model);
        }
        public ActionResult YapilanIslerToplam(string id, int? CurrentPage, string tarih)
        {

            Rapor rapor = new Rapor();
            rapor.Raporlama = 11;
            ViewBag.CurrentPage = CurrentPage ?? 0;
            ViewBag.PerformansTur = new[]
           {
             new SelectListItem{ Value="KaynakDag",Text="Kaynak Dağılımı"},
              new SelectListItem{ Value="BirimBaz",Text="Birim Bazlı Dağılım"},
               new SelectListItem{ Value="BebSonuclari",Text="Beb işlem Sonuçları"},
                new SelectListItem{ Value="BebKonu",Text="Beb Konu Dağılımı"},
                 new SelectListItem{ Value="SGOKonu",Text="SGÖ Konu Dağılımı "}

           };
            ViewBag.Tur = new[]
          {
             new SelectListItem{ Value="BTIP02",Text="Bilgi Edinme Başvurusu"},
              new SelectListItem{ Value="BTIP01",Text="Şikayet ve İhbar Başvurusu"},
               new SelectListItem{ Value="BTIP03",Text="Diğer Başvurular"}
            };
            rapor.RaporTuruList = new[]{
                 //new SelectListItem{ Value="1",Text="Standart Rapor"},
                 new SelectListItem{ Value="2",Text="Gecikme Raporu"},
                 new SelectListItem{ Value="3",Text="Performans Raporu"},
                new SelectListItem{ Value="4",Text="Birim Süreç İstatistikleri "},
                new SelectListItem{ Value="5",Text="Kurul Genel İstatistikleri "},
                new SelectListItem{ Value="6",Text="İade İstatistikleri"},
                new SelectListItem{ Value="7",Text="Süresi İçerisinde Kapanmayan Başvurular"},
               new SelectListItem{ Value="8",Text="Birim Bazında Süresi İçerisinde Kapanmayan Başvurular"},
               new SelectListItem{ Value="9",Text="KİD Bilgi Edinme Ortalama İşlem Süreleri"},
                new SelectListItem{ Value="10",Text="BEB Genel Rapor"},
                new SelectListItem{ Value="11",Text="KİD Performans Raporu"}};
            ViewBag.BasvuruTipi = _uow.sozlukRepo.List(i => i.id.StartsWith("BTIP") && i.Durum == 1).Select(i => new SelectListItem { Value = i.id, Text = i.explanation });
            ViewBag.Birim = _uow.sozlukRepo.List(d => d.id.StartsWith("BRM")).Select(i => new SelectListItem { Value = i.id, Text = i.explanation });
            ViewBag.tarih = tarih;

            ViewBag.CurrentPage = CurrentPage ?? 0;
            //BEBDb db = _uow.basvuruRepo.GetContext();
            //db = _uow.basvuruRepo.GetContext();
            List<Basvuru> listbas = new List<Basvuru>();
            List<Beb.Models.Beb> listbeb = new List<Models.Beb>();

            YapilanIsler model = new YapilanIsler();


            string[] raporLink = id.Split(' ');
            string raporAdi = raporLink[0];
            string personelAd = raporLink[1];
            string personelSoyad = string.Empty;
            var raporlinkcount = raporLink.Count();
            if (raporLink.Count() > 2)
            {
                personelSoyad = raporLink[2];
            }

            ViewBag.raporAdi = raporAdi;
            ViewBag.AdSoyad = " KİD'e direkt gelen (yönlendirilmemiş)";
            string[] tarihparcalari = tarih.Split('-');
            string tarih1 = tarihparcalari[0];
            string tarih2 = tarihparcalari[1];

            var bastar = DateTime.ParseExact(DateTime.Parse(tarih1).ToString("yyyy-MM-dd"), "yyyy-MM-dd", System.Globalization.CultureInfo.InvariantCulture, System.Globalization.DateTimeStyles.None);
            var bittar = DateTime.ParseExact(DateTime.Parse(tarih2).ToString("yyyy-MM-dd"), "yyyy-MM-dd", System.Globalization.CultureInfo.InvariantCulture, System.Globalization.DateTimeStyles.None);

            var kidPersonel = _uow.KullaniciRolRepo.List(x => x.BIRIMID == "BRM15").Select(x => new { x.BIRIMID, x.USERADID }).ToList();
            var kapatanKullanici = string.Empty;
            var cimerGiden = _uow.bebRepo.List(x => x.DURUM == "BDUR05").ToList();
            var cimerGelen = _uow.basvuruRepo.List(x => x.CIMERBASVURUNO != null && x.LOGKULLANICI != "internet").ToList();
            var edevletGelen = _uow.basvuruRepo.List(x => x.CIMERBASVURUNO == null && x.LOGKULLANICI == "internet").ToList();
            var edevletGiden = _uow.bebRepo.List(x => x.DURUM == "BDUR05").ToList();


            var dairenincevapYazdigiBebler = _uow.dbsRepo.List(y => y.IADE == false).Select(x => x.BEBID).Distinct().ToList();

            List<YapilanIslerRapor> listeson = new List<YapilanIslerRapor>();

            cimerGiden = _uow.bebRepo.List(x => x.DURUM == "BDUR05" && x.KAPATANKULLANICI == personelAd).ToList();
            cimerGelen = _uow.basvuruRepo.List(x => x.CIMERBASVURUNO != null && x.LOGKULLANICI != "internet" && x.LOGKULLANICI == personelAd && x.TARIH >= bastar && x.TARIH <= bittar).ToList();
            edevletGelen = _uow.basvuruRepo.List(x => x.CIMERBASVURUNO == null && x.LOGKULLANICI == personelAd && x.TARIH >= bastar && x.TARIH <= bittar).ToList();
            edevletGiden = _uow.bebRepo.List(x => x.Basvuru.CIMERBASVURUNO == null && x.DURUM == "BDUR05" && x.KAPATANKULLANICI == personelAd && x.Basvuru.TARIH >= bastar && x.Basvuru.TARIH <= bittar).ToList();


            if (raporAdi == "Toplam")
            {
                listbas.AddRange((List<Basvuru>)cimerGelen);
                listbas.AddRange((List<Basvuru>)edevletGelen);
                listbeb.AddRange((List<Beb.Models.Beb>)cimerGiden);
                listbeb.AddRange((List<Beb.Models.Beb>)edevletGiden);
                model.listbas = listbas;
                model.listbeb = listbeb;
                ViewBag.Liste = "BDUR02";
            }
            logManager.Log(OrtakSabitler.LOG_KID_PERFORMANS_RAPORU_YAPILANISLER_TOPLAM_SHOW, id + " ");

            return View("YapilanIsler", model);

        }
        public ActionResult YapilanIslerDetay(int id)
        {
            Rapor rapor = new Rapor();
            BEBDb db = _uow.basvuruRepo.GetContext();

            ViewBag.PerformansTur = new[]
           {
             new SelectListItem{ Value="KaynakDag",Text="Kaynak Dağılımı"},
              new SelectListItem{ Value="BirimBaz",Text="Birim Bazlı Dağılım"},
               new SelectListItem{ Value="BebSonuclari",Text="Beb işlem Sonuçları"},
                new SelectListItem{ Value="BebKonu",Text="Beb Konu Dağılımı"},
                 new SelectListItem{ Value="SGOKonu",Text="SGÖ Konu Dağılımı "}

           };
            ViewBag.Tur = new[]
          {
             new SelectListItem{ Value="BTIP02",Text="Bilgi Edinme Başvurusu"},
              new SelectListItem{ Value="BTIP01",Text="Şikayet ve İhbar Başvurusu"},
               new SelectListItem{ Value="BTIP03",Text="Diğer Başvurular"}
            };
            rapor.RaporTuruList = new[]{
                 //new SelectListItem{ Value="1",Text="Standart Rapor"},
                 new SelectListItem{ Value="2",Text="Gecikme Raporu"},
                 new SelectListItem{ Value="3",Text="Performans Raporu"},
                new SelectListItem{ Value="4",Text="Birim Süreç İstatistikleri "},
                new SelectListItem{ Value="5",Text="Kurul Genel İstatistikleri "},
                new SelectListItem{ Value="6",Text="İade İstatistikleri"},
                new SelectListItem{ Value="7",Text="Süresi İçerisinde Kapanmayan Başvurular"},
               new SelectListItem{ Value="8",Text="Birim Bazında Süresi İçerisinde Kapanmayan Başvurular"},
               new SelectListItem{ Value="9",Text="KİD Bilgi Edinme Ortalama İşlem Süreleri"},
                new SelectListItem{ Value="10",Text="BEB Genel Rapor"},
                new SelectListItem{ Value="11",Text="KİD Performans Raporu"}};
            ViewBag.BasvuruTipi = _uow.sozlukRepo.List(i => i.id.StartsWith("BTIP") && i.Durum == 1).Select(i => new SelectListItem { Value = i.id, Text = i.explanation });
            ViewBag.Birim = _uow.sozlukRepo.List(d => d.id.StartsWith("BRM")).Select(i => new SelectListItem { Value = i.id, Text = i.explanation });

            List<Basvuru> listbas = null;
            List<Beb.Models.Beb> listbeb = null;
            YapilanIsler model = new YapilanIsler();


            //var basbeb = database.Basvuru.Join(database.Beb, b => b.BASVURUID, e => e.BASVURUID, (bas, beb) => new { bas = bas, beb = beb });
            var basbeb = db.Basvuru.Join(db.Beb, b => b.BASVURUID, e => e.BASVURUID, (bas, beb) => new { bas = bas, beb = beb });

            var kayitlistbeb = basbeb.Where(x => x.beb.BASVURUID == id).Select(x => x.beb).ToList();
            var kayitlistbas = basbeb.Where(x => x.bas.BASVURUID == id).Select(x => x.bas).ToList();
            if (kayitlistbeb.FirstOrDefault().KAPANISTARIHI != null)
            {
                model.listbeb = kayitlistbeb;
            }
            else
            {
                model.listbas = kayitlistbas;
            }
            logManager.Log(OrtakSabitler.LOG_KID_PERFORMANS_RAPORU_YAPILANISLER_DETAY_SHOW, id + " ");

            return View(model);
        }




    }
}