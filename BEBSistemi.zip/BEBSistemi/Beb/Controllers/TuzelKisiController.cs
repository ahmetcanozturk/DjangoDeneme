﻿using Beb.IServices;
using Beb.Models;
using Beb.Utilities;
using Beb.ViewModels;
using Beb.ViewModels.TuzelKisi;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Net.Http;
using System.Text;
using System.Web;
using System.Web.Mvc;
using Beb.Services;

namespace Beb.Controllers
{

    public class TuzelKisiController : BaseController
    {
        public TuzelKisiController()
        {
        }


        [HttpGet]
        public ActionResult TuzelKisiListesi()
        {
            ViewBag.TuzelKisiler = null;
            return View();
        }

        [HttpGet]
        public JsonResult _AdinaGoreSirketAra(string id)
        {
            var tkm = MersisApiService.Instance;
            var items = tkm.AdinaGoreSirketAra(id);
            var diItems = new Dictionary<string, string>();
            if (items != null)
            {
                foreach (var item in items)
                    if (!diItems.ContainsKey(item.SirketId.ToString()))
                        diItems.Add(item.SirketId.ToString(), item.Unvani);
            }
            return items != null ? Json(diItems, JsonRequestBehavior.AllowGet) : Json(new Dictionary<string, string>() { }, JsonRequestBehavior.AllowGet);
        }
    }
}