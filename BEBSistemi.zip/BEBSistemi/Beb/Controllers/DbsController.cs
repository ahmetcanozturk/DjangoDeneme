﻿using Beb.Filter;
using Beb.Interfaces;
using Beb.Models;
using Beb.Repository;
using Beb.Services;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using System.Web.Routing;

namespace Beb.Controllers
{

    [AuthFilter(Roles = "DBS")]
    [ActFilter]
    public class DbsController : BaseController
    {


        // GET: Dbs
        public ActionResult Index()
        {
            return View();
        }
        public DbsController()
        {


        }
        public ActionResult DBSYonetim()
         {

            ViewBag.CurrentPage = 0;
            string daire = kullanici.daire;
            Sozluk s = _uow.sozlukRepo.Find(i => i.explanation == daire);
            List<Dbs> dbsList = _uow.dbsRepo.List(i => i.YONBIRIM == s.id && i.SONDURUM == OrtakSabitler.DAIRE_DURUM_DAIREYE_YONLENDIRILMIS && i.Beb.KAPANISTARIHI == null).OrderByDescending(m => m.YONTARIHI).ToList();

            ViewBag.Liste = OrtakSabitler.DAIRE_DURUM_DAIREYE_YONLENDIRILMIS;
            logManager.Log(OrtakSabitler.LOG_DBSYONETIM_GORUNTULE, "");
            return View(dbsList);
        }
        public ActionResult DBSDetay(int id, string Tur, int? currentPage)
        {
            ViewBag.Tur = Tur;
            ViewBag.CurrentPage = currentPage ?? 0;
            
            if (id == null) { return new HttpStatusCodeResult(HttpStatusCode.BadRequest); }
            Dbs dbs = _uow.dbsRepo.Find(i => i.DBSID == id);
            if (dbs == null) { return HttpNotFound(); }
            DbsViewBag(dbs);
            ViewBag.SirketAdi = MersisApiService.Instance.SirketAdiBySirketID(dbs.Beb.Basvuru.SIRKETID);
            var basvuruId = Convert.ToDecimal(dbs.Beb.BASVURUID);
            var logbilgisi = _uow.LogRepo.Find(x => x.BasvuruId == basvuruId && x.DbsId != null && x.Aciklama == "Dbs tatafından beb onaylama");
            ViewBag.DbsAdSoyad = logbilgisi?.IslemYapan;

            logManager.Log(OrtakSabitler.LOG_DBSDETAY_GORUNTULE, "");
            return View(dbs);

        }
        [HttpPost]
        public ActionResult DBSDetay(Dbs model, string tagsUzmanlar, string Tur, int? currentPage, string SirketID)
        {
            ViewBag.Tur = Tur;
            ViewBag.CurrentPage = currentPage ?? 0;
            Dbs dbs = _uow.dbsRepo.Find(x => x.DBSID == model.DBSID);
            List<Tag> Uzmanlar = JsonConvert.DeserializeObject<List<Tag>>(tagsUzmanlar);

            if (Uzmanlar != null)
            {
                string aciklamaDaireUzman = "";
                Dbs yenidbs = _uow.dbsRepo.Find(i => i.DBSID == dbs.DBSID);
                yenidbs.BIRIMKAPATMETIN = dbs.BIRIMKAPATMETIN;
                //yenidbs.BASVURUCEVAPTARIHI = DateTime.Now;

                //db.Entry(Beb).State = EntityState.Detached; 
                _uow.dbsRepo.Update(yenidbs);


                List<DbsGorevli> dbsGorevlist = _uow.dbsgorevliRepo.List(i => i.DBSID == dbs.DBSID);
                List<DbsGorevli> eklenecekList = new List<DbsGorevli>();
                foreach (Tag uzman in Uzmanlar)
                {
                    aciklamaDaireUzman += uzman.value + " ";
                    SYN_DomainUsers uzmanKullanici = _uow.userRepo.Find(i => i.username == uzman.code);
                    if (dbsGorevlist.Any(d => d.KULLANICIADI == uzman.code))
                    {
                        DbsGorevli eski = dbsGorevlist.Where(d => d.KULLANICIADI == uzman.code).FirstOrDefault();
                        eklenecekList.Add(eski);
                        continue;
                    }
                    else
                    {
                        DbsGorevli yeniDbsGorevli = new DbsGorevli
                        {
                            DBSID = dbs.DBSID,
                            KULLANICIADI = uzman.code,
                            ATANMATARIHI = DateTime.Now,
                            ISLEMTARIHI = DateTime.Now,
                            ADSOYAD = uzmanKullanici.adsoyad,
                            ATAYAN = kullanici.username

                        };
                        eklenecekList.Add(yeniDbsGorevli);
                        DbsGorevli gorevli = _uow.dbsgorevliRepo.InsertObj(yeniDbsGorevli);
                        string strSubject = "", strMessageBody = "";
                        DaireDurumOlustur(OrtakSabitler.DAIRE_DURUM_GOREVLIYE_YONLENDIRILMIS, yenidbs.DBSID,dbs.BIRIMKAPATMETIN,dbs.IADE);
                        mailService.DbsMailIcerik(dbs.Beb.Basvuru, "", OrtakSabitler.UZMAN_LINK, gorevli.DBSGOREVLIID, ref strSubject, ref strMessageBody);
                        SYN_DomainUsers gorevlibilgi = _uow.userRepo.Find(x => x.username == yeniDbsGorevli.KULLANICIADI);
                        string mailmesaj = "";
                        if (gorevlibilgi.mail == null)
                        {
                            Message("Yönlendirilen personel bilgisinde eksiklik vardır.");
                        }
                        else
                        {
                            bool mailGonderme = mailService.SendMail(gorevlibilgi.mail, strSubject, strMessageBody);
                            if (mailGonderme)
                            {
                                mailmesaj = "Mail Gönderme işlemi başarıyla gerçekleşti.";
                            }
                            else
                            {
                                mailmesaj = "Mail Gönderilemedi.";
                            }
                        }



                    }
                }
                List<DbsGorevli> silinecekdbs = dbsGorevlist.Except(eklenecekList).ToList();
                _uow.dbsgorevliRepo.DeleteRange(silinecekdbs);
                Message("Uzmana Yönlendirme Yapılmıştır.");
                DbsViewBag(yenidbs);
                ViewBag.SirketAdi = MersisApiService.Instance.SirketAdiBySirketID(dbs.Beb.Basvuru.SIRKETID);
                var basvuruId = Convert.ToDecimal(dbs.Beb.BASVURUID);
                var logbilgisi = _uow.LogRepo.Find(x => x.BasvuruId == basvuruId && x.DbsId != null && x.Aciklama == "Dbs tatafından beb onaylama");
                ViewBag.DbsAdSoyad = logbilgisi?.IslemYapan;

                if (SirketID != null)
                {
                    ViewBag.SirketAdi = MersisApiService.Instance.SirketAdiBySirketID(SirketID);

                    Basvuru basvuru = _uow.basvuruRepo.Find(x => x.BASVURUID == dbs.Beb.BASVURUID);
                    basvuru.SIRKETID = SirketID;
                    _uow.SaveChanges();
                }
                

                logManager.Log(OrtakSabitler.LOG_BEB_UZMAN_YONLENDIRME, aciklamaDaireUzman + " uzmanlarına yönlendirme", null, null, yenidbs);
                return View(yenidbs);
            }
            else
            {
                Message("Uzman Yönlendirmesi için Uzman Seçiniz.");
                Dbs gelendbs = _uow.dbsRepo.Find(i => i.DBSID == model.DBSID);
                DbsViewBag(gelendbs);
                ViewBag.SirketAdi = MersisApiService.Instance.SirketAdiBySirketID(SirketID);

                return View(gelendbs);
            }



        }
        [HttpPost]
        [ValidateInput(false)]
        public ActionResult DbsTopluOnayla(List<decimal> secilidbs, string CevapMetni)
        {
            foreach (decimal dbsid in secilidbs)
            {
                Dbs dbs = _uow.dbsRepo.Find(m => m.DBSID == dbsid);
                dbs.BIRIMKAPATMETIN = CevapMetni;
                dbs.BASVURUCEVAPTARIHI = DateTime.Now;
                dbs.TOPLUCEVAPMI = true;
                DbsOnay(dbs);
            }

            List<decimal> topluOnaylananlariAyir = new List<decimal>();
            topluOnaylananlariAyir = secilidbs;
            foreach (var item in topluOnaylananlariAyir)
            {
                Dbs dbs = _uow.dbsRepo.Find(m => m.DBSID == item);
                

            }



            return RedirectToAction("DbsYonetim");
        }
        [HttpPost]
        [ValidateInput(false)]
        public ActionResult DbsTopluOnay(List<decimal> secilidbs)
        {
            foreach (decimal dbsid in secilidbs)
            {
                Dbs dbs = _uow.dbsRepo.Find(m => m.DBSID == dbsid);
                string onaymetni = dbs.BIRIMKAPATMETIN;
                dbs.TOPLUCEVAPMI=true;
                dbs.BIRIMKAPATMETIN = onaymetni;
                dbs.BASVURUCEVAPTARIHI = DateTime.Now;
                DbsOnay(dbs);
            }
            return RedirectToAction("DbsYonetim");
        }
        [ValidateInput(false)]
        public string GetCevapMetni(List<decimal> listkey)
        {

            return "";
        }
        public Dbs DbsOnay(Dbs model)
        {
            Dbs dbs = _uow.dbsRepo.Find(i => i.DBSID == model.DBSID && i.SONDURUM!="DDUR06"); //false sunay ekledi 25-02-2022
            if (model.BIRIMKAPATMETIN == null || model.BIRIMKAPATMETIN == "")
            {
                Message("Lütfen Cevap Metni Giriniz.");
                return dbs;
            }
            else
            {
                dbs.BIRIMKAPATMETIN = model.BIRIMKAPATMETIN;
                dbs.BASVURUCEVAPTARIHI = DateTime.Now;
                dbs.TOPLUCEVAPMI = false;
                dbs.Beb.KAPANISMETNI += model.BIRIMKAPATMETIN;
                _uow.dbsRepo.Update(dbs);

                DaireDurumOlustur(OrtakSabitler.DAIRE_DURUM_DAIRE_YETKILISI_ONAYLADI, dbs.DBSID, dbs.BIRIMKAPATMETIN, dbs.IADE);

                Models.Beb beb = _uow.bebRepo.Find(i => i.BEBID == dbs.BEBID);

                //Beb teki dbs listesinde dolaşır en son giren durum daire yetkilisi onayladı olmayan varsa BEBdurumunu ona göre değiştiriyor

                foreach (var item in beb.DbsListesi)
                {
                    if (dbs != item && item.DaireDurumListesi != null && item.DaireDurumListesi.Count() > 0)
                    {
                        var ddurumlistesi = item.DaireDurumListesi.OrderByDescending(i => i.KAYITTARIH).ToList();

                        if (!ddurumlistesi[0].DAIREDURUM.ToString().Equals(OrtakSabitler.DAIRE_DURUM_DAIRE_YETKILISI_ONAYLADI) && !ddurumlistesi[0].DAIREDURUM.ToString().Equals(OrtakSabitler.DAIRE_DURUM_DAIRE_YETKILISI_IADE_ETTI))
                        {

                            beb.DURUM = OrtakSabitler.DAIREONAY_KOD;//bdur04
                            break;
                        }
                        else
                        {
                            beb.DURUM = OrtakSabitler.ONAYLANMIS_BASVURU_KOD;//bdur01 Cevaplanmış başvuru
                        }


                    }
                    else
                    {
                        beb.DURUM = OrtakSabitler.ONAYLANMIS_BASVURU_KOD;//bdur01 Cevaplanmış başvuru
                    }

                }
                _uow.bebRepo.Update(beb);

                var birim = dbs.YONBIRIM;
                var daireAdi = _uow.sozlukRepo.Find(x => x.id == birim).explanation;

                    
                
                

                Message("Beb Onaylanmıştır.");
                logManager.Log(OrtakSabitler.LOG_BEB_ONAYLAMA, "Dbs tatafından beb onaylama", beb.Basvuru, null, dbs);
            }
            return dbs;
        }
        [HttpPost]
        [ValidateInput(false)]
        public ActionResult DbsOnayla(Dbs model)
        {
            //DBS onayladıktan sonra beb değişiyor diğer daire ile metinler birleşiyor.
            Dbs dbs = DbsOnay(model);
            DbsViewBag(dbs);
            return View("DBSDetay", dbs);

        }
        [HttpPost]
        [ValidateInput(false)]
        public ActionResult DbsYeniOnay(Dbs model, string CevapMetni, string Tur, int? currentPage)
        {
            Dbs dbs = _uow.dbsRepo.Find(i => i.DBSID == model.DBSID);
            if (model.BIRIMKAPATMETIN == null || model.BIRIMKAPATMETIN == "")
            {
                Message("Lütfen Cevap Metni Giriniz.");
                return View("DBSDetay", dbs);
            }
            else
            {
                dbs.BIRIMKAPATMETIN = CevapMetni;
                dbs.BASVURUCEVAPTARIHI = DateTime.Now;
                //Eski cevap metninin silinmesi gerekiyor.

                dbs.Beb.KAPANISMETNI = null;
                if (dbs.IADE)
                {
                    dbs.IADE = false;
                }
                //dbs birimkapatma metinleri içinde dolaşıp tekrar oluşturulması gerekiyor  
                //aynı bebid ye sahip dbsler içerisinde dolaşıp kapanısmetni oluşturulması gerekiyor  
                _uow.dbsRepo.Update(dbs);
                DaireDurumOlustur(OrtakSabitler.DAIRE_DURUM_DAIRE_YETKILISI_ONAYLADI, dbs.DBSID, dbs.BIRIMKAPATMETIN, dbs.IADE);

                List<Dbs> dbslist = _uow.dbsRepo.List(w => w.BEBID == dbs.BEBID);
                foreach (Dbs d in dbslist)
                {
                    if (d.SONDURUM.Equals(OrtakSabitler.DAIRE_DURUM_DAIRE_YETKILISI_ONAYLADI))
                        dbs.Beb.KAPANISMETNI += d.BIRIMKAPATMETIN;
                }

                _uow.dbsRepo.Update(dbs);

                Models.Beb beb = _uow.bebRepo.Find(i => i.BEBID == dbs.BEBID);

                //Beb teki dbs listesinde dolaşır en son giren durum daire yetkilisi onayladı olmayan varsa BEBdurumunu ona göre değiştiriyor

                foreach (var item in beb.DbsListesi)
                {
                    if (dbs != item && item.DaireDurumListesi != null && item.DaireDurumListesi.Count() > 0)
                    {
                        var ddurumlistesi = item.DaireDurumListesi.OrderByDescending(i => i.KAYITTARIH).ToList();

                        if (!ddurumlistesi[0].DAIREDURUM.ToString().Equals(OrtakSabitler.DAIRE_DURUM_DAIRE_YETKILISI_ONAYLADI) && !ddurumlistesi[0].DAIREDURUM.ToString().Equals(OrtakSabitler.DAIRE_DURUM_DAIRE_YETKILISI_IADE_ETTI))
                        {

                            beb.DURUM = OrtakSabitler.DAIREONAY_KOD;//bdur04
                            break;
                        }
                        else
                        {
                            beb.DURUM = OrtakSabitler.ONAYLANMIS_BASVURU_KOD;//bdur01 Cevaplanmış başvuru
                        }


                    }
                    else
                    {
                        beb.DURUM = OrtakSabitler.ONAYLANMIS_BASVURU_KOD;//bdur01 Cevaplanmış başvuru
                    }

                }
                _uow.bebRepo.Update(beb);
                dbs = _uow.dbsRepo.Find(i => i.DBSID == model.DBSID);


                Message("Beb Onaylanmıştır.");
                logManager.Log(OrtakSabitler.LOG_BEB_YENIDENONAYLAMA, "Dbs tarafından beb yeniden onaylama", beb.Basvuru, null, dbs);
            }
           
            ViewBag.Tur = Tur;
            ViewBag.CurrentPage = currentPage ?? 0;
            var parameters = new RouteValueDictionary {
                    { "Tur", Tur },
                    {"CurrentPage",currentPage },
                    { "id", dbs.DBSID }
};
            return RedirectToAction("DbsDetay", parameters);
        }
        [HttpPost]
        [ValidateInput(false)]
        public ActionResult DbsYeniIade(Dbs model, string CevapMetni, string Tur, int? currentPage)
        {
            Dbs dbs = _uow.dbsRepo.Find(i => i.DBSID == model.DBSID);
            if (model.BIRIMKAPATMETIN == null || model.BIRIMKAPATMETIN == "")
            {
                Message("Lütfen Cevap Metni Giriniz.");
                return View("DBSDetay", dbs);
            }
            else
            {
                dbs.BIRIMKAPATMETIN = CevapMetni;
                dbs.BASVURUCEVAPTARIHI = DateTime.Now;
                //Eski cevap metninin silinmesi gerekiyor.
                
                dbs.Beb.KAPANISMETNI = null;
                if (!dbs.IADE)
                {
                    dbs.IADE = true;
                }
                //dbs birimkapatma metinleri içinde dolaşıp tekrar oluşturulması gerekiyor  
                //aynı bebid ye sahip dbsler içerisinde dolaşıp kapanısmetni oluşturulması gerekiyor 
                _uow.dbsRepo.Update(dbs);
                DaireDurumOlustur(OrtakSabitler.DAIRE_DURUM_DAIRE_YETKILISI_IADE_ETTI, dbs.DBSID, dbs.BIRIMKAPATMETIN, dbs.IADE);
                List<Dbs> dbslist = _uow.dbsRepo.List(w => w.BEBID == dbs.BEBID);
                foreach (Dbs d in dbslist)
                {
                    if (d.SONDURUM.Equals(OrtakSabitler.DAIRE_DURUM_DAIRE_YETKILISI_ONAYLADI))
                        dbs.Beb.KAPANISMETNI += d.BIRIMKAPATMETIN;
                }

                _uow.dbsRepo.Update(dbs);
                Models.Beb beb = _uow.bebRepo.Find(i => i.BEBID == dbs.BEBID);

                //Beb teki dbs listesinde dolaşır en son giren durum daire yetkilisi onayladı olmayan varsa BEBdurumunu ona göre değiştiriyor

                foreach (var item in beb.DbsListesi)
                {
                    if (dbs != item && item.DaireDurumListesi != null && item.DaireDurumListesi.Count() > 0)
                    {
                        var ddurumlistesi = item.DaireDurumListesi.OrderByDescending(i => i.KAYITTARIH).ToList();

                        if (!ddurumlistesi[0].DAIREDURUM.ToString().Equals(OrtakSabitler.DAIRE_DURUM_DAIRE_YETKILISI_ONAYLADI) && !ddurumlistesi[0].DAIREDURUM.ToString().Equals(OrtakSabitler.DAIRE_DURUM_DAIRE_YETKILISI_IADE_ETTI))
                        {

                            beb.DURUM = OrtakSabitler.DAIREONAY_KOD;//bdur04
                            break;
                        }
                        else
                        {
                            beb.DURUM = OrtakSabitler.ONAYLANMIS_BASVURU_KOD;//bdur01 Cevaplanmış başvuru
                        }


                    }
                    else
                    {
                        beb.DURUM = OrtakSabitler.ONAYLANMIS_BASVURU_KOD;//bdur01 Cevaplanmış başvuru
                    }

                }
                _uow.bebRepo.Update(beb);
                dbs = _uow.dbsRepo.Find(i => i.DBSID == model.DBSID);


                Message("Beb İade Edilmiştir.");
                logManager.Log(OrtakSabitler.LOG_BEB_YENIDENIADE, "Dbs tarafından beb yeniden iade", beb.Basvuru, null, dbs);
            }
          
            ViewBag.Tur = Tur;
            ViewBag.CurrentPage = currentPage ?? 0;
            var parameters = new RouteValueDictionary {
                    { "Tur", Tur },
                    {"CurrentPage",currentPage },
                    { "id", dbs.DBSID }
};
            return RedirectToAction("DbsDetay", parameters);

        }
        [HttpPost]
        [ValidateInput(false)]
        public ActionResult BebOnayla(Basvuru model)
        {

            //Cevaplanmış başvuru kapatma 
            //model.Beb.DURUM = OrtakSabitler.KAPATILMIS_BASVURU_KOD; 

            return RedirectToAction("Index");
        }
        [HttpPost]
        [ValidateInput(false)]
        public ActionResult DbsTopluIade(List<decimal> secilidbs, string CevapMetni)
        {
            foreach (decimal dbsid in secilidbs)
            {
                Dbs dbs = _uow.dbsRepo.Find(m => m.DBSID == dbsid);
                dbs.BIRIMKAPATMETIN = CevapMetni;
                DbsIade(dbs);
            }
            return RedirectToAction("DbsYonetim");
        }
        public Dbs DbsIade(Dbs model)
        {
            //DBS onayladıktan sonra beb değişiyor diğer daire ile metinler birleşiyor.
            Dbs dbs = _uow.dbsRepo.Find(m => m.DBSID == model.DBSID);
            dbs.BIRIMKAPATMETIN = model.BIRIMKAPATMETIN;
            dbs.BASVURUCEVAPTARIHI = DateTime.Now;
            dbs.IADE = true;
            
            //dbs.Beb.KAPANISMETNI += "<p><span class=marker>" + KullaniciBilgileri().daire + " Cevabı&nbsp;</span></p>\r\n" + model.BIRIMKAPATMETIN;
            _uow.dbsRepo.Update(dbs);

            DaireDurumOlustur(OrtakSabitler.DAIRE_DURUM_DAIRE_YETKILISI_IADE_ETTI, dbs.DBSID, dbs.BIRIMKAPATMETIN,dbs.IADE);

            Models.Beb beb = _uow.bebRepo.Find(i => i.BEBID == dbs.BEBID);

            //Beb teki dbs listesinde dolaşır en son giren durum daire yetkilisi onayladı olmayan varsa BEBdurumunu ona göre değiştiriyor

            foreach (var item in beb.DbsListesi)
            {
                if (dbs != item && item.DaireDurumListesi != null && item.DaireDurumListesi.Count() > 0)
                {
                    var ddurumlistesi = item.DaireDurumListesi.OrderByDescending(i => i.KAYITTARIH).ToList();

                    if (!ddurumlistesi[0].DAIREDURUM.ToString().Equals(OrtakSabitler.DAIRE_DURUM_DAIRE_YETKILISI_ONAYLADI) && !ddurumlistesi[0].DAIREDURUM.ToString().Equals(OrtakSabitler.DAIRE_DURUM_DAIRE_YETKILISI_IADE_ETTI))
                    {

                        beb.DURUM = OrtakSabitler.DAIREONAY_KOD;//bdur04
                        break;
                    }
                    else
                    {
                        beb.DURUM = OrtakSabitler.ONAYLANMIS_BASVURU_KOD;//bdur01 Cevaplanmış başvuru
                    }


                }
                else
                {
                    beb.DURUM = OrtakSabitler.ONAYLANMIS_BASVURU_KOD;//bdur01 Cevaplanmış başvuru
                }

            }
            _uow.bebRepo.Update(beb);

            var birim = dbs.YONBIRIM;
            var daireAdi = _uow.sozlukRepo.Find(x => x.id == birim).explanation;

            Message("Beb İade Edilmiştir.");
            logManager.Log(OrtakSabitler.LOG_BEB_IADE, "Dbs tarafından beb iade", beb.Basvuru, null, dbs);
            return dbs;
        }
        [HttpPost]
        [ValidateInput(false)]
        public ActionResult DbsIadeEt(Dbs model)
        {
            Dbs dbs = DbsIade(model);
            DbsViewBag(dbs);
            return View("DBSDetay", dbs);

        }
        public ActionResult BasvuruAra(string id, int? CurrentPage)
        {
            ViewBag.CurrentPage = CurrentPage ?? 0;
            Sozluk s = _uow.sozlukRepo.Find(i => i.explanation == kullanici.daire);
            List<Dbs> dbsList = null;

            if (id != OrtakSabitler.DAIRE_DURUM_DAIRE_YETKILISI_IADE_ETTI && id != OrtakSabitler.DAIRE_DURUM_DAIRE_YETKILISI_ONAYLADI)
            {
                dbsList = _uow.dbsRepo.List(i => i.YONBIRIM == s.id && i.SONDURUM == id && i.Beb.KAPANISTARIHI == null).OrderByDescending(m => m.YONTARIHI).ToList();
            }
            else
            {
                dbsList = _uow.dbsRepo.List(i => i.YONBIRIM == s.id && i.SONDURUM == id).OrderByDescending(m => m.YONTARIHI).ToList();
            }

            ViewBag.Liste = id;

            return View("DBSYonetim", dbsList);

        }
        public ActionResult IcerikAra(string id, string icerik)
        { //id View ile gelen liste bilgisidir. 
            ViewBag.CurrentPage = 0;
            ViewBag.Liste = id;
            string daire = kullanici.daire;
            Sozluk s = _uow.sozlukRepo.Find(i => i.explanation == daire);
            List<Dbs> dbsList = _uow.dbsRepo.List(i => i.YONBIRIM == s.id && i.SONDURUM == id && i.Beb.KAPANISTARIHI == null && i.Beb.Basvuru.BASVURUICERIK.Contains(icerik)).OrderByDescending(m => m.YONTARIHI).ToList();
            ViewBag.Icerik = icerik;
            logManager.Log(OrtakSabitler.LOG_ICERIK_ARA, icerik + " kelimesi basvuru içerik arama");
            return View("DBSYonetim", dbsList);
        }
        public void DbsViewBag(Dbs dbs = null)
        {
            if (kullanici.daire.Equals("LSG"))
            {
                ViewBag.UzmanListesi = _uow.userRepo.List(i => i.daire == "MSD");
            }
            else
            {
                ViewBag.UzmanListesi = _uow.userRepo.List(i => i.daire == kullanici.daire);
            }
            //Select bakılacak???
            ViewBag.SeciliUzmanlar = _uow.dbsgorevliRepo.List(b => b.DBSID == dbs.DBSID).Select(n => new SelectListItem { Text = n.ADSOYAD, Value = n.KULLANICIADI }).ToList();
            ViewBag.Daire = kullanici.daire;
            ViewBag.SirketAdi = MersisApiService.Instance.SirketAdiBySirketID(dbs.Beb.Basvuru.SIRKETID);
        }

    }
}