﻿using Beb.Filter;
using Beb.Interfaces;
using Beb.Mail;
using Beb.Models;
using Beb.UOW;
using Beb.Users;
using Beb.Utilities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Beb.Controllers
{
    [AuthFilter(Roles = "BEB,DBS")]
    [ActFilter]
    public class YetkilendirmeController : BaseController
    {
        BEBDb db = new BEBDb();
        protected IUnitOfWork _uow;

        // GET: Yetkilendirme
        public ActionResult Index()
        {
            return View();
        }
        //SUNAY
        public ActionResult Yetkilendirme()
        {
            string commandText = "";
            string islemYapanUser = kullanici.username.ToString(); //giriş yapan kişi, kendi birimindekileri görecek
            string islemYapanUserDaire = kullanici.daire.ToString();
            var islemYapanUserBirim = db.KullaniciRol.Where(x => x.USERADID == islemYapanUser).Select(x => x.BIRIMID).FirstOrDefault().ToString();
            var BebMiDBSmi = db.KullaniciRol.Where(x => x.USERADID == islemYapanUser).Select(x => x.RolBilgisi).FirstOrDefault().ROLADI;
            ViewBag.BebMiDBSmi = BebMiDBSmi;
            if (BebMiDBSmi == OrtakSabitler.ROLES_DBS) //rol dbs ise kendi dairesinde yetkisi olanlar
            {
                using (var context = new BEBDb())
                {
                    commandText = "select dom.tckimlikno,dom.sicilno,dom.adsoyad,dom.daire, dom.unvan,dom.username, r.ROLADI as rol from BSB_KULLANICIROL kr, BSB_ROL r, [public].[dbo].[DomainUsers] dom where kr.ROL=r.ROLID and dom.username=kr.USERADID and dom.daire='" + islemYapanUserDaire + "'";

                    context.Database.ExecuteSqlCommand(commandText);
                }
            }
            else if (BebMiDBSmi == OrtakSabitler.ROLES_BEB) //rolü beb ise yetkisi olan herkesi görsün
            {
                using (var context = new BEBDb())
                {
                    //commandText = "select dom.tckimlikno,dom.adsoyad,dom.unvan,dom.daire,dom.username from  [public].[dbo].[DomainUsers] dom where dom.username not in  (select USERADID from [BEB].[dbo].[BSB_KULLANICIROL] rol )";
                    commandText = "select dom.tckimlikno,dom.sicilno,dom.adsoyad,dom.daire, dom.unvan,dom.username, r.ROLADI as rol from BSB_KULLANICIROL kr, BSB_ROL r, [public].[dbo].[DomainUsers] dom where kr.ROL=r.ROLID and dom.username=kr.USERADID ";

                    context.Database.ExecuteSqlCommand(commandText);
                }
            }
            List<Yetkilendirme> list = db.Database.SqlQuery<Yetkilendirme>(commandText).ToList();
            logManager.Log(OrtakSabitler.LOG_YETKI_SHOW, "");


            return View(list);
        }
        public ActionResult YetkilendirmeCreate()
        {

            string commandText = "";
            string daire = kullanici.daire.ToUpper();
            string islemYapanUser = kullanici.username.ToString(); //giriş yapan kişi, kendi birimindekileri görecek
            var BebMiDBSmi = db.KullaniciRol.Where(x => x.USERADID == islemYapanUser).Select(x => x.RolBilgisi).FirstOrDefault().ROLADI;
            ViewBag.BebMiDBSmi = BebMiDBSmi;


            if (BebMiDBSmi == OrtakSabitler.ROLES_DBS) //sadece kendi dairesinde yetkisi olmayanları görsün
            {
                using (var context = new BEBDb())
                {
                    commandText = "select dom.tckimlikno,dom.adsoyad,dom.unvan,dom.daire,dom.username from  [public].[dbo].[DomainUsers] dom where dom.username not in  (select USERADID from [BEB].[dbo].[BSB_KULLANICIROL] rol ) and dom.userstatus=1 and dom.daire like " + "'%" + daire + "%'";

                    context.Database.ExecuteSqlCommand(commandText);
                }
            }
            else if (BebMiDBSmi == OrtakSabitler.ROLES_BEB) //yetkisi olmayan herkes
            {
                using (var context = new BEBDb())
                {
                    commandText = "select dom.tckimlikno,dom.adsoyad,dom.unvan,dom.daire,dom.username from  [public].[dbo].[DomainUsers] dom where dom.userstatus=1 and dom.username not in  (select USERADID from [BEB].[dbo].[BSB_KULLANICIROL] rol )";

                    context.Database.ExecuteSqlCommand(commandText);
                }
            }
            List<Yetkilendirme> list = db.Database.SqlQuery<Yetkilendirme>(commandText).ToList();
            logManager.Log(OrtakSabitler.LOG_YETKI_SHOW, "");

            return View(list);
        }
        public ActionResult YetkilendirmeCreateAdd(long? id)
        {
            string secilenUserName = "";
            string commandText = "";
            using (var context = new BEBDb())
            {
                secilenUserName = "Select dom.username from  [public].[dbo].[DomainUsers] dom where tckimlikno=" + id;

                context.Database.ExecuteSqlCommand(secilenUserName);
            }
            List<String> kullaniciAd = db.Database.SqlQuery<String>(secilenUserName).ToList();

            var kullaniciadi = kullaniciAd.FirstOrDefault();
            //var secilenUserName = db.Database.SqlQuery<String>(commandText).ToString();

            var rolList = db.KullaniciRol.Where(x => x.USERADID == secilenUserName).Select(x => new { x.ROL, x.RolBilgisi }).ToList();
            string islemYapanUser = kullanici.username.ToString(); //giriş yapan kişi, kendi birimindekileri görecek
            var BebMiDBSmi = db.KullaniciRol.Where(x => x.USERADID == islemYapanUser).Select(x => x.RolBilgisi).FirstOrDefault().ROLADI;
            ViewBag.BebMiDBSmi = BebMiDBSmi;
            var rolListFilter = db.Rol.Where(x => x.ROLID != 3).ToList();
            if (BebMiDBSmi == OrtakSabitler.ROLES_DBS)
            {
                rolListFilter = rolListFilter.Where(x => x.ROLADI == OrtakSabitler.ROLES_DBS).ToList();
            }


            //foreach (var item in rolListFilter)
            //{
            //    if (item.ROLADI == OrtakSabitler.ROLES_DBS)
            //    {
            //        item.ROLADI = "Daire BEB Yetkilisi";
            //    }
            //    else if (item.ROLADI == OrtakSabitler.ROLES_BEB)
            //    {
            //        item.ROLADI = "KİD BEB Yetkilisi"; 
            //    }
            //    else if (item.ROLADI == OrtakSabitler.ROLES_DENETCI)
            //    {
            //        item.ROLADI = "İç Denetçi";
            //    }
            //}
            ViewBag.RolList = rolListFilter;//db.Rol.ToList();

            if (rolList.Count == 0)
            {

                using (var context = new BEBDb())
                {
                    commandText = "select dom.tckimlikno,dom.sicilno,dom.adsoyad,dom.daire, dom.unvan, dom.username from [public].[dbo].[DomainUsers] dom where dom.tckimlikno=" + id;

                    context.Database.ExecuteSqlCommand(commandText);
                }
            }
            else
            {
                using (var context = new BEBDb())
                {
                    commandText = "select dom.tckimlikno,dom.sicilno,dom.adsoyad,dom.daire, do.unvan, dom.username from [public].[dbo].[DomainUsers] dom where dom.tckimlikno=" + id;

                    context.Database.ExecuteSqlCommand(commandText);
                }
            }

            Yetkilendirme vm = db.Database.SqlQuery<Yetkilendirme>(commandText).FirstOrDefault();

            vm.username = kullaniciadi;


            if (rolList.Count() != 0)
            {
                vm.rolId = rolList.FirstOrDefault().ROL;
            }

            logManager.Log(OrtakSabitler.LOG_YETKI_SHOW, id + "");
            return View(vm);

        }
        [HttpPost]
        public ActionResult YetkilendirmeCreateAdd(long id, Yetkilendirme kullaniciYetki)
        {
            string commandText = "";
            string secilenUserName = "";
            using (var context = new BEBDb())
            {
                secilenUserName = "Select dom.username from  [public].[dbo].[DomainUsers] dom where tckimlikno=" + id;

                context.Database.ExecuteSqlCommand(secilenUserName);
            }
            List<String> kullaniciAd = db.Database.SqlQuery<String>(secilenUserName).ToList();

            var kullaniciadi = kullaniciAd.FirstOrDefault();



            var rolList = db.KullaniciRol.Where(x => x.USERADID == secilenUserName).Select(x => new { x.ROL, x.RolBilgisi }).ToList();
            var rolListFilter = db.Rol.Where(x => x.ROLID != 3).ToList();
            string islemYapanUser = kullanici.username.ToString(); //giriş yapan kişi, kendi birimindekileri görecek
            var BebMiDBSmi = db.KullaniciRol.Where(x => x.USERADID == islemYapanUser).Select(x => x.RolBilgisi).FirstOrDefault().ROLADI;
            ViewBag.BebMiDBSmi = BebMiDBSmi;
            if (BebMiDBSmi == OrtakSabitler.ROLES_DBS)
            {
                rolListFilter = rolListFilter.Where(x => x.ROLADI == OrtakSabitler.ROLES_DBS).ToList();
            }
            ViewBag.RolList = rolListFilter;//db.Rol.ToList();
            if (rolList.Count == 0)
            {

                using (var context = new BEBDb())
                {
                    commandText = "select dom.tckimlikno,dom.sicilno,dom.adsoyad,dom.daire, dom.unvan, dom.username from [public].[dbo].[DomainUsers] dom where dom.tckimlikno=" + id;

                    context.Database.ExecuteSqlCommand(commandText);
                }
            }
            else
            {
                using (var context = new BEBDb())
                {
                    commandText = "select dom.tckimlikno,dom.sicilno,dom.adsoyad,dom.daire, dom.unvan, dom.username from [public].[dbo].[DomainUsers] dom where dom.tckimlikno=" + id;

                    context.Database.ExecuteSqlCommand(commandText);
                }
            }
            List<Yetkilendirme> list = db.Database.SqlQuery<Yetkilendirme>(commandText).ToList();

            Yetkilendirme vm = db.Database.SqlQuery<Yetkilendirme>(commandText).FirstOrDefault();

            var rolAdi = db.Rol.Select(x => x.ROLADI).FirstOrDefault();

            foreach (var item in list)
            {
                vm.tckimlikno = item.tckimlikno;
                vm.adsoyad = item.adsoyad;
                vm.sicilno = item.sicilno;
                vm.rol = rolAdi;
                vm.rolId = kullaniciYetki.rolId;
                vm.unvan = item.unvan;
                vm.daire = item.daire;
                vm.username = item.username;

            }

            var result = 0;
            var varMi = db.KullaniciRol.Where(x => x.USERADID == secilenUserName).FirstOrDefault();
            var islemYapanUserBirim = db.KullaniciRol.Where(x => x.USERADID == islemYapanUser).Select(x => x.BIRIMID).FirstOrDefault().ToString();
            KullaniciRol kr = new KullaniciRol();

            string rolll = vm.rolId.ToString();

            if (varMi == null) // tabloda yoksa ekle
            {
                //using (var context = new BEBDb())
                //{
                //    commandText = "insert into BSB_KULLANICIROL values (" + "'" + vm.username + "'," + vm.rolId + ",'" + islemYapanUserBirim + "');";

                //    context.Database.ExecuteSqlCommand(commandText);
                //}

                kr.USERADID = vm.username;
                kr.ROL = Convert.ToInt16(vm.rolId);
                kr.BIRIMID = islemYapanUserBirim;
                kr.BirimSozluk = db.Sozluk.Where(x => x.id == islemYapanUserBirim).FirstOrDefault();
                kr.RolBilgisi = db.Rol.Where(x => x.ROLID == vm.rolId).FirstOrDefault();
                kr.RolBilgisi.ROLID = Convert.ToInt16(vm.rolId);



            }


            if (ModelState.IsValid)
            {
                db.KullaniciRol.Add(kr);
                //_uow.KullaniciRolRepo.Insert(kr);
                db.SaveChanges();
                result = 1;
            }
            if (result > 0)
            {
                MessageSuccess("Yetki verme başarılı!", "", false);
                //logManager.Log(OrtakSabitler.LOG_YETKI_CREATE_SUCCESS, id+ "");
                return View("YetkilendirmeCreateAdd", vm);

            }
            else
            {
                MessageDanger("Yetki verme başarısız!", "", false);
                logManager.Log(OrtakSabitler.LOG_YETKI_CREATE_ERROR, id + "");

                return View("YetkilendirmeCreateAdd", vm);

            }

        }
        public ActionResult YetkilendirmeCreateEdit(long? id)
        {
            string secilenUserName = "";
            string commandText = "";
            using (var context = new BEBDb())
            {
                secilenUserName = "Select dom.username from  [public].[dbo].[DomainUsers] dom where tckimlikno=" + id;

                context.Database.ExecuteSqlCommand(secilenUserName);
            }
            List<String> kullaniciAd = db.Database.SqlQuery<String>(secilenUserName).ToList();

            var kullaniciadi = kullaniciAd.FirstOrDefault();
            var rolId = 0;
            var rolbilgisi = "";
            var rolList = db.KullaniciRol.Where(x => x.USERADID == kullaniciAd.FirstOrDefault().ToString()).Select(x => new { x.RolBilgisi }).ToList();
            foreach (var item in rolList)
            {
                rolId = item.RolBilgisi.ROLID;
                rolbilgisi = item.RolBilgisi.ROLADI.ToString();

            }
            string islemYapanUser = kullanici.username.ToString(); //giriş yapan kişi, kendi birimindekileri görecek
            var BebMiDBSmi = db.KullaniciRol.Where(x => x.USERADID == islemYapanUser).Select(x => x.RolBilgisi).FirstOrDefault().ROLADI;
            ViewBag.BebMiDBSmi = BebMiDBSmi;
            var rolListFilter = db.Rol.Where(x => x.ROLID != 3).ToList();
            if (BebMiDBSmi == OrtakSabitler.ROLES_DBS)
            {
                rolListFilter = rolListFilter.Where(x => x.ROLADI == OrtakSabitler.ROLES_DBS).ToList();
            }
            ViewBag.RolList = rolListFilter;//db.Rol.ToList();

            using (var context = new BEBDb())
            {
                commandText = "select dom.tckimlikno,dom.sicilno,dom.adsoyad,dom.daire, dom.unvan,dom.username, r.ROLADI from BSB_KULLANICIROL kr, BSB_ROL r, [public].[dbo].[DomainUsers] dom where kr.ROL=r.ROLID and dom.username=kr.USERADID and dom.tckimlikno='" + id + "'";

                context.Database.ExecuteSqlCommand(commandText);
            }

            Yetkilendirme vm = db.Database.SqlQuery<Yetkilendirme>(commandText).FirstOrDefault();

            vm.username = kullaniciadi;
            vm.rolId = rolId;
            vm.rol = rolbilgisi;

            logManager.Log(OrtakSabitler.LOG_YETKI_SHOW, id + "");

            return View(vm);
        }
        [HttpPost]
        public ActionResult YetkilendirmeCreateEdit(long? id, Yetkilendirme kullaniciYetki)
        {
            string commandText = "";
            string secilenUserName = "";
            string musa = "";

            using (var context = new BEBDb())
            {
                secilenUserName = "Select dom.username from  [public].[dbo].[DomainUsers] dom where tckimlikno=" + id;

                context.Database.ExecuteSqlCommand(secilenUserName);
            }
            List<String> kullaniciAd = db.Database.SqlQuery<String>(secilenUserName).ToList();

            var kullaniciadi = kullaniciAd.FirstOrDefault();


            var rolList = db.KullaniciRol.Where(x => x.USERADID == kullaniciAd.FirstOrDefault().ToString()).Select(x => new { x.RolBilgisi }).ToList();
            string islemYapanUser = kullanici.username.ToString(); //giriş yapan kişi, kendi birimindekileri görecek
            var BebMiDBSmi = db.KullaniciRol.Where(x => x.USERADID == islemYapanUser).Select(x => x.RolBilgisi).FirstOrDefault().ROLADI;
            ViewBag.BebMiDBSmi = BebMiDBSmi;
            var rolListFilter = db.Rol.Where(x => x.ROLID != 3).ToList();
            if (BebMiDBSmi == OrtakSabitler.ROLES_DBS)
            {
                rolListFilter = rolListFilter.Where(x => x.ROLADI == OrtakSabitler.ROLES_DBS).ToList();
            }
            ViewBag.RolList = rolListFilter;

            try
            {

                
                if (rolList.Count == 0)
                {
                    using (var context = new BEBDb())
                    {
                        commandText = "select dom.tckimlikno,dom.sicilno,dom.adsoyad,dom.daire, dom.unvan, dom.username from [public].[dbo].[DomainUsers] dom where dom.tckimlikno=" + id;

                        context.Database.ExecuteSqlCommand(commandText);
                    }
                }
                else
                {
                    using (var context = new BEBDb())
                    {
                        commandText = "select dom.tckimlikno,dom.sicilno,dom.adsoyad,dom.daire, dom.unvan, dom.username from [public].[dbo].[DomainUsers] dom where dom.tckimlikno=" + id;

                        context.Database.ExecuteSqlCommand(commandText);
                    }
                }
                List<Yetkilendirme> list = db.Database.SqlQuery<Yetkilendirme>(commandText).ToList();

                Yetkilendirme vm = db.Database.SqlQuery<Yetkilendirme>(commandText).FirstOrDefault();

                var rolAdi = db.Rol.Select(x => x.ROLADI).FirstOrDefault();

                foreach (var item in list)
                {
                    vm.tckimlikno = item.tckimlikno;
                    vm.adsoyad = item.adsoyad;
                    vm.sicilno = item.sicilno;
                    vm.rolId = kullaniciYetki.rolId;
                    vm.rol = kullaniciYetki.rolId.ToString();
                    vm.unvan = item.unvan;
                    vm.daire = item.daire;
                    vm.username = item.username;
                    kullaniciYetki.tckimlikno = item.tckimlikno;
                    kullaniciYetki.adsoyad = item.adsoyad;
                    kullaniciYetki.sicilno = item.sicilno;
                    kullaniciYetki.rolId = kullaniciYetki.rolId;
                    kullaniciYetki.rol = kullaniciYetki.rolId.ToString();
                    kullaniciYetki.unvan = item.unvan;
                    kullaniciYetki.daire = item.daire;
                    kullaniciYetki.username = item.username;

                }

                var result = 0;
                //using (var context = new BEBDb())
                //{
                //    commandText = "update BSB_KULLANICIROL set rol =" + vm.rol + " where USERADID='" + vm.username + "'";

                //    context.Database.ExecuteSqlCommand(commandText);
                //}

                using (var context = new BEBDb())
                {
                    musa = "Select KULLANICIROLID from  BSB_KULLANICIROL WHERE USERADID = '" + kullaniciAd.FirstOrDefault().ToString() + "'";

                    context.Database.ExecuteSqlCommand(musa);
                }
                List<Decimal> mussaa = db.Database.SqlQuery<Decimal>(musa).ToList();
               

                KullaniciRol krr = db.KullaniciRol.Where(x => x.KULLANICIROLID == mussaa.FirstOrDefault()).FirstOrDefault();
                //KullaniciRol kr = _uow.KullaniciRolRepo.Find(x => x.KULLANICIROLID == MUSSA);

                if (ModelState.IsValid)
                {
                    
                    krr.ROL = Convert.ToInt32(kullaniciYetki.rolId);
                    

                    //_uow.KullaniciRolRepo.Update(krr);
                    db.SaveChanges();
                    result = 1;
                }


                if (result > 0)
                {
                    MessageSuccess("Yetki güncelleme başarılı!", "", false);
                    logManager.Log(OrtakSabitler.LOG_YETKI_UPDATE_SUCCESS, id + "");

                    return View("YetkilendirmeCreateEdit", vm);

                }
                else
                {
                    MessageDanger("Yetki güncelleme başarısız!", "", false);
                    logManager.Log(OrtakSabitler.LOG_YETKI_UPDATE_ERROR, id + "");
                    return View("YetkilendirmeCreateEdit", vm);

                }
            }
            catch (NullReferenceException e)
            {
                
                Console.WriteLine(e.Message);
                throw;
            }


        }
        public ActionResult YetkilendirmeDelete(long id)
        {
            string secilenUserName = "";
            using (var context = new BEBDb())
            {
                secilenUserName = "Select dom.username from  [public].[dbo].[DomainUsers] dom where tckimlikno=" + id;

                context.Database.ExecuteSqlCommand(secilenUserName);
            }
            List<String> kullaniciAd = db.Database.SqlQuery<String>(secilenUserName).ToList();

            var kullaniciadi = kullaniciAd.FirstOrDefault();
            string commandText = "";
            int result = 0;

            //using (var context = new BEBDb())
            //{
            //    commandText = "delete from BSB_KULLANICIROL where USERADID='" + kullaniciadi.ToString() + "'";

            //    context.Database.ExecuteSqlCommand(commandText);
            //}
            string musa = "";
            using (var context = new BEBDb())
            {
                musa = "Select KULLANICIROLID from  BSB_KULLANICIROL WHERE USERADID = '" + kullaniciAd.FirstOrDefault().ToString() + "'";

                context.Database.ExecuteSqlCommand(musa);
            }
            List<Decimal> mussaa = db.Database.SqlQuery<Decimal>(musa).ToList();


            KullaniciRol krr = db.KullaniciRol.Where(x => x.KULLANICIROLID == mussaa.FirstOrDefault()).FirstOrDefault();

            db.KullaniciRol.Remove(krr);

            result=db.SaveChanges();
            if (result>0)
            {
                MessageSuccess("Yetki kaldırma başarılı!", "", false);
                logManager.Log(OrtakSabitler.LOG_YETKI_DELETE_SUCCESS, id + "");
            }
            else
            {
                MessageDanger("Yetki kaldırılamadı!", "", false);
                logManager.Log(OrtakSabitler.LOG_YETKI_DELETE_ERROR, id + "");
            }
            return RedirectToAction("Yetkilendirme");

        }
    }
}