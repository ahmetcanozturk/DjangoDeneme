﻿using Beb.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Beb.IServices
{
    public interface ITuzelKisiService
    {
        List<TuzelKisi> tuzelKisiListesiGetir();
        TuzelKisi idIleTuzelKisiGetir(long id);
        IQueryable<TuzelKisi> Search(List<Guid> sirketIdList);
    }
}