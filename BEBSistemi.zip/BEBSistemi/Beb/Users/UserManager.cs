﻿using Beb.Interfaces;
using Beb.Models;
using Beb.Repository;
using Beb.UOW;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Beb.Users
{
    public class UserManager : IUser
    {
       
        protected IUnitOfWork _uow =new UnitOfWork();
        public void CreateUser()
        {
            string KullaniciAd = HttpContext.Current.User.Identity.Name.Split('\\')[1].ToLowerInvariant();
            //string KullaniciAd = "hkaranfil";

            var rol = _uow.KullaniciRolRepo.Get(x => x.USERADID == KullaniciAd, x => new { x.USERADID, x.RolBilgisi.ROLADI, x.BirimSozluk.explanation });

            if (HttpContext.Current.Session["Kullanici"] == null)
            {
                SYN_DomainUsers duser = _uow.userRepo.Find(i => i.username == KullaniciAd);
                if (duser != null)
                {
                    if(rol != null && rol.Count > 0)
                    {
                        duser.daire = rol[0].explanation;
                    }

                    HttpContext.Current.Session["Kullanici"] = duser;  
                }
            }
            if (HttpContext.Current.Session["Rol"] == null)
            {
                List<string> roller = new List<string>(); 
                
                if (rol != null)
                {
                    foreach (var item in rol)
                    {
                        //string rolad = item.ROLADI;
                        roller.Add(item.ROLADI);
                       
                    }
                    HttpContext.Current.Session["Rol"] = roller;
                }
               
            }

        }

        public SYN_DomainUsers UserInfo()
        {
            if (HttpContext.Current.Session["Kullanici"] != null)
            {
                return HttpContext.Current.Session["Kullanici"] as SYN_DomainUsers;
            }
            else
            {
                CreateUser();
                return UserInfo();
            }

        }
        public List<string>  RolInfo()
        {
            if (HttpContext.Current.Session["Rol"] != null)
            {
                return HttpContext.Current.Session["Rol"] as List<string>;
            }
            else
            {
                return null;
            }

        }
    }
}