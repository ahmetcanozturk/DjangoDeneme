﻿using Beb.Interfaces;
using Beb.Models;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Data.SqlClient;
using System.Linq;
using System.Linq.Expressions;
using System.Web;
using System.Transactions;

namespace Beb.Repository
{
    public class Repository<T> : IRepository<T> where T : class
    {
        //private readonly  Beb.Models.BEBDb db = new Models.BEBDb(); 
        private readonly Models.BEBDb db;
        private DbSet<T> objSet;


        public Repository(Models.BEBDb dbContext)
        {
            if (dbContext == null)
                throw new ArgumentNullException("dbContext can not be null.");

            this.db = dbContext;
            objSet = db.Set<T>();
        }
        public BEBDb GetContext()
        {

            return db;
        }

        public int Insert(T obj)
        {
            objSet.Add(obj);
            return Save();
        }
        public int Update(T obj)
        {
            //objSet.Attach(obj);
            db.Entry(obj).State = EntityState.Modified;
            return Save();
        }
        public List<T> List()
        {
            return objSet.ToList();

        }
        public T Find(Expression<Func<T, bool>> where)
        {
            return objSet.FirstOrDefault(where);
            //return objSet.Where(where).FirstOrDefault();
        }
        public List<T> List(Expression<Func<T, bool>> where)
        {
            return objSet.Where(where).ToList();

        }
        public IQueryable<T> Queryable()
        {
            return objSet.AsQueryable();
        }

        public int Delete(T entity)
        {
            objSet.Remove(entity);
            return Save();
        }
        public IList<TType> Get<TType>(Expression<Func<T, bool>> where, Expression<Func<T, TType>> select) where TType : class
        {
            return objSet.Where(where).Select(select).ToList();
        }
        public int Save()
        {
            return db.SaveChanges();
        }

        public int DeleteRange(ICollection<T> entities)
        {
            objSet.RemoveRange(entities);
            return Save();
        }

        public T InsertObj(T obj)
        {
            T setobj;
            using (TransactionScope tScope = new TransactionScope())
            {
                if (typeof(T).Name.Equals("Basvuru"))
                {
                    Basvuru bs = obj as Basvuru;
                    decimal id = db.Basvuru.Max(i => i.BASVURUID);
                    bs.BASVURUID = id + 1;
                    setobj = db.Basvuru.Add(bs) as T;
                }
                else
                {
                    setobj = objSet.Add(obj);
                }

                db.SaveChanges();
                tScope.Complete();
            }

            return setobj;
        }

        private bool disposed = false;

        protected virtual void Dispose(bool disposing)
        {
            if (!this.disposed)
            {
                if (disposing)
                {
                    db.Dispose();
                }
            }
            this.disposed = true;
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        public List<T> GecikmeRaporList(string basvuruTip, string birim, string tarihler)
        {
            string[] tarih = tarihler.Split('-');
            string tarih1 = tarih[0];
            string tarih2 = tarih[1];


            string Sorgu = "	SELECT /*BASVURU.TCKIMLIK,*/ BASVURU.ADSOYAD, /*BASVURU.TEL, BASVURU.EMAIL, DBS.YONEPOSTA, */ " +
           " (SELECT aciklama FROM BilgiEdinmeSozluk WHERE id = BASVURU.KONU) AS KONU, " +
           " /*BASVURU.ADRES, (SELECT explanation FROM Sozluk WHERE id= BASVURU.IL) AS IL, */ " +
           " /*BASVURU.BASVURUICERIK, */ " +
           " /*(SELECT CASE BASVURU.BASVURUCEVAP WHEN 0 THEN 'Elektronik' WHEN 1 THEN 'Yazılı' END) AS BASVURUCEVAP, */  " +
           " /*BEB.ACIKLAMA, BEB.BASVURUTIPI,*/ (select convert(date,BASVURU.TARIH)) AS BASVURU_TARIH, " +
           "(SELECT explanation FROM Sozluk WHERE id=BEB.BASVURUTIPI) AS TIPI, " +
           "(SELECT explanation FROM Sozluk WHERE id= DBS.YONBIRIM ) AS YONBIRIM,  " +
           "  (select convert(varchar(10),BEB.KAPANISTARIHI, 120)) AS KAPANISTARIHI, (select convert(varchar(10),DBS.BASVURUCEVAPTARIHI, 120)) AS BASVURUCEVAPTARIHI, BASVURU.BASVURUID  " +
           " /*BEB.KAPANISTARIHI, DBS.BASVURUCEVAPTARIHI*/ " +
           "from BSB_BASVURU BASVURU, BSB_BEB BEB, BSB_DBS DBS " +
           "WHERE BASVURU.BASVURUID=BEB.BASVURUID and BEB.BEBID = DBS.BEBID " +
           "AND " +
           "( ";

            //if (cb_bugunIcin.Checked)
            //{
            //    sql += " (BEB.KAPANISTARIHI is null AND ((BEB.BASVURUTIPI = 'BTIP01'  AND (datediff(day, BASVURU.LOGISLEMTARIH, GETDATE()) >30)) or  (BEB.BASVURUTIPI = 'BTIP02' AND  (dbo.getDiffDateWithRestDay(BASVURU.LOGISLEMTARIH, GETDATE()) >15))))) ";
            //}
            //else
            //{
            Sorgu += " ( BEB.BASVURUTIPI = 'BTIP01' AND  ( (BEB.KAPANISTARIHI is null AND (datediff(day, BASVURU.LOGISLEMTARIH, GETDATE()) >30)) or  (BEB.KAPANISTARIHI is not null AND  (datediff(day, BASVURU.LOGISLEMTARIH, BEB.KAPANISTARIHI) > 30) ))) or " +
                            " ( BEB.BASVURUTIPI = 'BTIP02' AND   ( (BEB.KAPANISTARIHI is null AND (dbo.getDiffDateWithRestDay(BASVURU.LOGISLEMTARIH, GETDATE()) >15)) or  (BEB.KAPANISTARIHI is not null AND  (dbo.getDiffDateWithRestDay(BASVURU.LOGISLEMTARIH, BEB.KAPANISTARIHI)  > 15) )))) ";
            //}

            if ((tarih1 != null || tarih2 != null)
                 && (!String.IsNullOrEmpty(tarih1) || !String.IsNullOrEmpty(tarih2))
                )
            {
                Sorgu += " and DBS.BEBID   IN  (SELECT B.BEBID FROM BSB_BEB B WHERE B.BASVURUID IN  (SELECT BASVURUID FROM BSB_BASVURU BASVURU WHERE ";
                if (tarih1 != null && !String.IsNullOrEmpty(tarih1))
                {
                    Sorgu += " BASVURU.TARIH >= '" + (DateTime.Parse(tarih1)).ToString("MM.dd.yyyy") + " 00:00:00.000" + "' ";
                    if (tarih2 != null && !String.IsNullOrEmpty(tarih2))
                        Sorgu += " and ";
                }
                if (tarih2 != null && !String.IsNullOrEmpty(tarih2))
                    Sorgu += "BASVURU.TARIH <= '" + (DateTime.Parse(tarih2)).ToString("MM.dd.yyyy") + " 23:59:59.000" + "' ";
                Sorgu += " ) ) ";
            }

            if (!String.IsNullOrEmpty(birim) && !birim.Equals("BRM00"))
            {
                Sorgu += " and DBS.YONBIRIM= '" + birim + "' ";
            }
            if (!String.IsNullOrEmpty(basvuruTip) && !basvuruTip.Equals("BTIP00"))
            {
                Sorgu += " and BEB.BASVURUTIPI= '" + basvuruTip + "' ";
            }


            Sorgu += " order by  YONBIRIM, BEB.BASVURUTIPI, BASVURU.TARIH ";

            List<T> liste = db.Database.SqlQuery<T>(Sorgu).ToList();


            //    List<Evrak> liste = _dbContext.Evraklar.SqlQuery(Constants.KURUL_DISI_GELEN_SORGU, parameters.ToArray()).ToList<Evrak>();



            //public static string KURUL_DISI_GELEN_SORGU = "SELECT *  FROM Evrak where KurulIciDisi = 'KID002' and GelenGiden = 'EGG001' and NereyeId = 49148 and Tarih >= @Tarih1  and Tarih< @Tarih2 and " +
            //                                             "DURUM NOT IN ('EVD008','EVD002','EVD001','EVD011','EVD003')";





            return liste;
        }

        public List<T> PerfKaynakDagilimi(string tarihler)
        {
            string[] tarih = tarihler.Split('-');
            string tarih1 = tarih[0];
            string tarih2 = tarih[1];
            List<T> liste = null;
            try
            {
                string strSelect = "";
                if (tarih1.Equals("") || tarih2.Equals(""))
                {
                    strSelect = "SELECT S.explanation AS BasvuruTuru, COUNT(CASE BASVURUTIPI WHEN 'BTIP02' THEN 1 END) AS BebSayi, COUNT(CASE BASVURUTIPI WHEN 'BTIP01' THEN 1 END) AS GOSSayi " +
                                        " FROM BSB_BEB BEB RIGHT JOIN Sozluk S ON  S.id = BEB.BASVURUTURU WHERE S.id LIKE '%BTUR%' AND S.id != 'BTUR00' " +
                                        "GROUP BY S.explanation UNION SELECT 'Toplam' , " +
                                        " COUNT(CASE BASVURUTIPI WHEN 'BTIP02' THEN 1 END) AS BebSayi, COUNT(CASE BASVURUTIPI WHEN 'BTIP01' THEN 1 END) AS GOSSayi FROM BSB_BEB BEB RIGHT JOIN Sozluk S ON  S.id = BEB.BASVURUTURU " +
                                        " WHERE S.id LIKE '%BTUR%' AND S.id != 'BTUR00' " +
                                        "order by BEB";
                }
                else
                {
                    strSelect = "SELECT S.explanation AS BasvuruTuru, COUNT(CASE BASVURUTIPI WHEN 'BTIP02' THEN 1 END) AS BebSayi, COUNT(CASE BASVURUTIPI WHEN 'BTIP01' THEN 1 END) AS GOSSayi " +
                                        " FROM BSB_BEB BEB RIGHT JOIN Sozluk S ON  S.id = BEB.BASVURUTURU WHERE S.id LIKE '%BTUR%' AND S.id != 'BTUR00' " +
                                        "AND BEB.BASVURUID IN (SELECT BASVURUID FROM BSB_BASVURU BASVURU WHERE BASVURU.TARIH >= '" + (DateTime.Parse(tarih1)).ToString("MM.dd.yyyy") + " 00:00:00.000" + "' AND BASVURU.TARIH <= '" + (DateTime.Parse(tarih2)).ToString("MM.dd.yyyy") + " 23:59:59.000" + "')" +
                                        "GROUP BY S.explanation UNION SELECT 'Toplam' , " +
                                        " COUNT(CASE BASVURUTIPI WHEN 'BTIP02' THEN 1 END) AS BebSayi, COUNT(CASE BASVURUTIPI WHEN 'BTIP01' THEN 1 END) AS BebSayi FROM BSB_BEB BEB RIGHT JOIN Sozluk S ON  S.id = BEB.BASVURUTURU " +
                                        " WHERE S.id LIKE '%BTUR%' AND S.id != 'BTUR00' " +
                                        "AND BEB.BASVURUID IN (SELECT BASVURUID FROM BSB_BASVURU BASVURU WHERE BASVURU.TARIH >= '" + (DateTime.Parse(tarih1)).ToString("MM.dd.yyyy") + " 00:00:00.000" + "' AND BASVURU.TARIH <= '" + (DateTime.Parse(tarih2)).ToString("MM.dd.yyyy") + " 23:59:59.000" + "')" +
                                        "order by BebSayi";
                }
                liste = db.Database.SqlQuery<T>(strSelect).ToList();
            }

            catch (Exception ex)
            {
                throw ex;
            }
            return liste;
        }

        public List<T> PerfBirimBazliDagilim(string tarihler)
        {
            string[] tarih = tarihler.Split('-');
            string tarih1 = tarih[0];
            string tarih2 = tarih[1];
            List<T> liste = null;
            try
            {
                string strSelect = "";
                if (tarih1.Equals("") || tarih2.Equals(""))
                {
                    strSelect = "SELECT " +
                    "(SELECT CASE WHEN BIRIMADI IS NULL THEN S.explanation ELSE BIRIMADI END) AS BIRIMADI, " +
                    "COUNT( BEBBASVURU) AS BEBBASVURU, " +
                    "CONVERT(NUMERIC(12,2), (SUM(BEBTAR) * 1.0)/(COUNT(BEBBASVURU) * 1.0) ) AS BEBORT, " +
                    "COUNT( SGOBASVURU) AS SGOBASVURU, " +
                    "CONVERT(NUMERIC(12,2), (SUM(SGOTAR) * 1.0)/(COUNT(SGOBASVURU) * 1.0) )AS SGOTARORT, " +
                    "COUNT( KYSBASVURU) AS KYSBASVURU, " +
                    "COUNT( SURESIGECEN) AS SURESIGECEN, " +
                    "COUNT( TOPLAM) AS TOPLAM " +

                    "FROM " +
                    "(SELECT " +
                    "(SELECT id FROM Sozluk WHERE id = DBS.YONBIRIM) AS BIRIM, " +
                    "( " +
                        "SELECT CASE (SELECT id FROM Sozluk WHERE id = DBS.YONBIRIM) WHEN 'BRM16'  " +
                        "THEN " +
                        "	( " +
                        "		SELECT CASE (SELECT BEB.KURULILGI FROM BSB_BEB BEB WHERE BEB.BEBID = DBS.BEBID) " +
                        "		WHEN 2 THEN 'Kurul İlgisiz Olması Sebebiyle Kapatılanlar (Mükerrer vb.)'  " +
                        "		ELSE 'BEB'  " +
                        "		END " +
                        "	) " +
                        "ELSE " +
                        "	(SELECT explanation FROM Sozluk WHERE id = DBS.YONBIRIM)  " +
                        "END " +
                    ")AS BIRIMADI, " +
                    "(SELECT BEB.BEBID  FROM BSB_BEB BEB WHERE BEB.BEBID = DBS.BEBID AND BEB.BASVURUTIPI = 'BTIP02') AS BEBBASVURU, " +
                    "(SELECT BEB.BEBID  FROM BSB_BEB BEB WHERE BEB.BEBID = DBS.BEBID AND BEB.BASVURUTIPI = 'BTIP01') AS SGOBASVURU, " +
                    "(SELECT BEB.BEBID FROM BSB_BEB BEB WHERE BEB.BEBID = DBS.BEBID AND BEB.BASVURUTIPI != 'BTIP01' AND BEB.BASVURUTIPI != 'BTIP02') AS KYSBASVURU, " +
                    "(SELECT BEB.BEBID FROM BSB_BEB BEB WHERE BEB.BEBID = DBS.BEBID) AS TOPLAM, " +

                    "(SELECT dbo.getDiffDateWithRestDay(BASVURU.LOGISLEMTARIH, BEB.KAPANISTARIHI) FROM BSB_BEB BEB, BSB_BASVURU BASVURU   WHERE BASVURU.BASVURUID=BEB.BASVURUID AND BEB.BEBID = DBS.BEBID AND BEB.BASVURUTIPI = 'BTIP02' AND BEB.KAPANISTARIHI is not null) AS BEBTAR, " +
                    "(SELECT datediff(day, BASVURU.LOGISLEMTARIH, BEB.KAPANISTARIHI) FROM BSB_BEB BEB, BSB_BASVURU BASVURU WHERE BASVURU.BASVURUID=BEB.BASVURUID AND BEB.BEBID = DBS.BEBID AND  BEB.BASVURUTIPI = 'BTIP01' AND BEB.KAPANISTARIHI is not null) AS SGOTAR, " +
                    "(SELECT BEB.BEBID FROM BSB_BEB BEB, BSB_BASVURU BASVURU WHERE BASVURU.BASVURUID=BEB.BASVURUID AND BEB.BEBID = DBS.BEBID  AND (( BEB.BASVURUTIPI = 'BTIP01' AND  ( (BEB.KAPANISTARIHI is null AND (datediff(day, BASVURU.LOGISLEMTARIH, GETDATE()) >30)) or  (BEB.KAPANISTARIHI is not null AND  (datediff(day, BASVURU.LOGISLEMTARIH, BEB.KAPANISTARIHI) > 30) ))) or ( BEB.BASVURUTIPI = 'BTIP02' AND  ( (BEB.KAPANISTARIHI is null AND (dbo.getDiffDateWithRestDay(BASVURU.LOGISLEMTARIH, GETDATE()) >15)) or  (BEB.KAPANISTARIHI is not null AND  (dbo.getDiffDateWithRestDay(BASVURU.LOGISLEMTARIH, BEB.KAPANISTARIHI)  > 15) ))))) AS SURESIGECEN " +
                    "FROM BSB_DBS DBS )AS SORGU " +
                    "RIGHT JOIN Sozluk S " +
                    "ON  S.id = BIRIM " +
                    "WHERE S.id LIKE '%BRM%' AND S.id != 'BRM00' " +
                    "GROUP BY BIRIMADI, S.explanation " +
                    "UNION " +
                    "SELECT " +
                    "'SPK Genel', " +
                    "COUNT( BEBBASVURU) AS BEBBASVURU, " +
                    "CONVERT(NUMERIC(12,2), (SUM(BEBTAR) * 1.0)/(COUNT(BEBBASVURU) * 1.0) ) AS BEBORT, " +
                    "COUNT( SGOBASVURU) AS SGOBASVURU, " +
                    "CONVERT(NUMERIC(12,2), (SUM(SGOTAR) * 1.0)/(COUNT(SGOBASVURU) * 1.0) )AS SGOTARORT, " +
                    "COUNT( KYSBASVURU) AS KYSBASVURU, " +
                    "COUNT(SURESIGECEN) AS SURESIGECEN, " +
                    "COUNT( TOPLAM) AS TOPLAM " +

                    "FROM " +
                    "(SELECT " +
                    "(SELECT id FROM Sozluk WHERE id = DBS.YONBIRIM) AS BIRIM, " +
                    "( " +
                    "	SELECT CASE (SELECT id FROM Sozluk WHERE id = DBS.YONBIRIM) WHEN 'BRM16'  " +
                    "	THEN " +
                    "		( " +
                    "			SELECT CASE (SELECT BEB.KURULILGI FROM BSB_BEB BEB WHERE BEB.BEBID = DBS.BEBID) " +
                    "			WHEN 2 THEN 'Kurul İlgisiz Olması Sebebiyle Kapatılanlar (Mükerrer vb.)'  " +
                    "			ELSE 'BEB'  " +
                    "			END " +
                    "		) " +
                    "	ELSE " +
                    "		(SELECT explanation FROM Sozluk WHERE id = DBS.YONBIRIM)  " +
                    "	END " +
                    ")AS BIRIMADI, " +
                    "(SELECT BEB.BEBID FROM BSB_BEB BEB WHERE BEB.BEBID = DBS.BEBID AND BEB.BASVURUTIPI = 'BTIP02') AS BEBBASVURU, " +
                    "(SELECT BEB.BEBID FROM BSB_BEB BEB WHERE BEB.BEBID = DBS.BEBID AND BEB.BASVURUTIPI = 'BTIP01') AS SGOBASVURU, " +
                    "(SELECT BEB.BEBID FROM BSB_BEB BEB WHERE BEB.BEBID = DBS.BEBID AND BEB.BASVURUTIPI != 'BTIP01' AND BEB.BASVURUTIPI != 'BTIP02') AS KYSBASVURU,  " +
                    "(SELECT BEB.BEBID FROM BSB_BEB BEB WHERE BEB.BEBID = DBS.BEBID) AS TOPLAM, " +

                    "(SELECT dbo.getDiffDateWithRestDay(BASVURU.LOGISLEMTARIH, BEB.KAPANISTARIHI) FROM BSB_BEB BEB, BSB_BASVURU BASVURU WHERE BASVURU.BASVURUID=BEB.BASVURUID AND BEB.BEBID = DBS.BEBID AND BEB.BASVURUTIPI = 'BTIP02' AND BEB.KAPANISTARIHI is not null) AS BEBTAR, " +
                    "(SELECT datediff(day, BASVURU.LOGISLEMTARIH, BEB.KAPANISTARIHI) FROM BSB_BEB BEB, BSB_BASVURU BASVURU WHERE BASVURU.BASVURUID=BEB.BASVURUID AND BEB.BEBID = DBS.BEBID AND BEB.BASVURUTIPI = 'BTIP01' AND BEB.KAPANISTARIHI is not null) AS SGOTAR, " +
                    "(SELECT BEB.BEBID FROM BSB_BEB BEB, BSB_BASVURU BASVURU WHERE BASVURU.BASVURUID=BEB.BASVURUID AND BEB.BEBID = DBS.BEBID AND (( BEB.BASVURUTIPI = 'BTIP01' AND  ( (BEB.KAPANISTARIHI is null AND (datediff(day, BASVURU.LOGISLEMTARIH, GETDATE()) >30)) or  (BEB.KAPANISTARIHI is not null AND  (datediff(day, BASVURU.LOGISLEMTARIH, BEB.KAPANISTARIHI) > 30) ))) or ( BEB.BASVURUTIPI = 'BTIP02' AND  ( (BEB.KAPANISTARIHI is null AND (dbo.getDiffDateWithRestDay(BASVURU.LOGISLEMTARIH, GETDATE()) >15)) or  (BEB.KAPANISTARIHI is not null AND  (dbo.getDiffDateWithRestDay(BASVURU.LOGISLEMTARIH, BEB.KAPANISTARIHI)  > 15) ))))) AS SURESIGECEN   " +
                    "FROM BSB_DBS DBS )AS SORGU " +
                    "RIGHT JOIN Sozluk S " +
                    "ON  S.id = BIRIM " +
                    "WHERE S.id LIKE '%BRM%' AND S.id != 'BRM00'";
                }
                else
                {
                    strSelect = "SELECT " +
                    "(SELECT CASE WHEN BIRIMADI IS NULL THEN S.explanation ELSE BIRIMADI END) AS BIRIMADI, " +
                    "COUNT( BEBBASVURU) AS BEBBASVURU, " +
                    "CONVERT(NUMERIC(12,2), (SUM(BEBTAR) * 1.0)/(COUNT(BEBBASVURU) * 1.0) ) AS BEBORT, " +
                    "COUNT( SGOBASVURU) AS SGOBASVURU, " +
                    "CONVERT(NUMERIC(12,2), (SUM(SGOTAR) * 1.0)/(COUNT(SGOBASVURU) * 1.0) )AS SGOTARORT, " +
                    "COUNT( KYSBASVURU) AS KYSBASVURU, " +
                    "COUNT( SURESIGECEN) AS SURESIGECEN, " +
                    "COUNT( TOPLAM) AS TOPLAM " +
                    "FROM " +
                    "(SELECT " +
                    "(SELECT id FROM Sozluk WHERE id = DBS.YONBIRIM) AS BIRIM, " +
                    "( " +
                        "SELECT CASE (SELECT id FROM Sozluk WHERE id = DBS.YONBIRIM) WHEN 'BRM16'  " +
                        "THEN " +
                        "	( " +
                        "		SELECT CASE (SELECT BEB.KURULILGI FROM BSB_BEB BEB WHERE BEB.BEBID = DBS.BEBID) " +
                        "		WHEN 2 THEN 'Kurul İlgisiz Olması Sebebiyle Kapatılanlar (Mükerrer vb.)'  " +
                        "		ELSE 'BEB'  " +
                        "		END " +
                        "	) " +
                        "ELSE " +
                        "	(SELECT explanation FROM Sozluk WHERE id = DBS.YONBIRIM)  " +
                        "END " +
                    ")AS BIRIMADI, " +
                    "(SELECT BEB.BEBID FROM BSB_BEB BEB WHERE BEB.BEBID = DBS.BEBID AND BEB.BASVURUTIPI = 'BTIP02') AS BEBBASVURU, " +
                    "(SELECT BEB.BEBID FROM BSB_BEB BEB WHERE BEB.BEBID = DBS.BEBID AND BEB.BASVURUTIPI = 'BTIP01') AS SGOBASVURU, " +
                    "(SELECT BEB.BEBID FROM BSB_BEB BEB WHERE BEB.BEBID = DBS.BEBID AND BEB.BASVURUTIPI != 'BTIP01' AND BEB.BASVURUTIPI != 'BTIP02') AS KYSBASVURU, " +
                    "(SELECT BEB.BEBID FROM BSB_BEB BEB WHERE BEB.BEBID = DBS.BEBID) AS TOPLAM, " +

                     "(SELECT dbo.getDiffDateWithRestDay(BASVURU.LOGISLEMTARIH, BEB.KAPANISTARIHI) FROM BSB_BEB BEB, BSB_BASVURU BASVURU   WHERE BASVURU.BASVURUID=BEB.BASVURUID AND BEB.BEBID = DBS.BEBID AND BEB.BASVURUTIPI = 'BTIP02' AND BEB.KAPANISTARIHI is not null) AS BEBTAR, " +
                    "(SELECT datediff(day, BASVURU.LOGISLEMTARIH, BEB.KAPANISTARIHI) FROM BSB_BEB BEB, BSB_BASVURU BASVURU WHERE BASVURU.BASVURUID=BEB.BASVURUID AND BEB.BEBID = DBS.BEBID AND  BEB.BASVURUTIPI = 'BTIP01' AND BEB.KAPANISTARIHI is not null) AS SGOTAR, " +
                    "(SELECT BEB.BEBID FROM BSB_BEB BEB, BSB_BASVURU BASVURU WHERE BASVURU.BASVURUID=BEB.BASVURUID AND BEB.BEBID = DBS.BEBID  AND (( BEB.BASVURUTIPI = 'BTIP01' AND  ( (BEB.KAPANISTARIHI is null AND (datediff(day, BASVURU.LOGISLEMTARIH, GETDATE()) >30)) or  (BEB.KAPANISTARIHI is not null AND  (datediff(day, BASVURU.LOGISLEMTARIH, BEB.KAPANISTARIHI) > 30) ))) or ( BEB.BASVURUTIPI = 'BTIP02' AND  ( (BEB.KAPANISTARIHI is null AND (dbo.getDiffDateWithRestDay(BASVURU.LOGISLEMTARIH, GETDATE()) >15)) or  (BEB.KAPANISTARIHI is not null AND  (dbo.getDiffDateWithRestDay(BASVURU.LOGISLEMTARIH, BEB.KAPANISTARIHI)  > 15) ))))) AS SURESIGECEN " +
                    "FROM BSB_DBS DBS " +
                    "WHERE DBS.BEBID IN (SELECT B.BEBID FROM BSB_BEB B WHERE B.BASVURUID IN (SELECT BASVURUID FROM BSB_BASVURU BASVURU WHERE BASVURU.TARIH >= '" + (DateTime.Parse(tarih1)).ToString("MM.dd.yyyy") + " 00:00:00.000" + "' AND BASVURU.TARIH <= '" + (DateTime.Parse(tarih2)).ToString("MM.dd.yyyy") + " 23:59:59.000" + "')))AS SORGU " +
                    "RIGHT JOIN Sozluk S " +
                    "ON  S.id = BIRIM " +
                    "WHERE S.id LIKE '%BRM%' AND S.id != 'BRM00' " +
                    "GROUP BY BIRIMADI, S.explanation " +
                    "UNION " +
                    "SELECT " +
                    "'SPK Genel', " +
                    "COUNT( BEBBASVURU) AS BEBBASVURU, " +
                    "CONVERT(NUMERIC(12,2), (SUM(BEBTAR) * 1.0)/(COUNT(BEBBASVURU) * 1.0) ) AS BEBORT, " +
                    "COUNT( SGOBASVURU) AS SGOBASVURU, " +
                    "CONVERT(NUMERIC(12,2), (SUM(SGOTAR) * 1.0)/(COUNT(SGOBASVURU) * 1.0) )AS SGOTARORT, " +
                    "COUNT( KYSBASVURU) AS KYSBASVURU, " +
                    "COUNT(SURESIGECEN) AS SURESIGECEN, " +
                    "COUNT( TOPLAM) AS TOPLAM " +
                   "FROM " +
                    "(SELECT " +
                    "(SELECT id FROM Sozluk WHERE id = DBS.YONBIRIM) AS BIRIM, " +
                    "( " +
                    "	SELECT CASE (SELECT id FROM Sozluk WHERE id = DBS.YONBIRIM) WHEN 'BRM16'  " +
                    "	THEN " +
                    "		( " +
                    "			SELECT CASE (SELECT BEB.KURULILGI FROM BSB_BEB BEB WHERE BEB.BEBID = DBS.BEBID) " +
                    "			WHEN 2 THEN 'Kurul İlgisiz Olması Sebebiyle Kapatılanlar (Mükerrer vb.)'  " +
                    "			ELSE 'BEB'  " +
                    "			END " +
                    "		) " +
                    "	ELSE " +
                    "		(SELECT explanation FROM Sozluk WHERE id = DBS.YONBIRIM)  " +
                    "	END " +
                    ")AS BIRIMADI, " +
                    "(SELECT BEB.BEBID FROM BSB_BEB BEB WHERE BEB.BEBID = DBS.BEBID AND BEB.BASVURUTIPI = 'BTIP02') AS BEBBASVURU, " +
                    "(SELECT BEB.BEBID FROM BSB_BEB BEB WHERE BEB.BEBID = DBS.BEBID AND BEB.BASVURUTIPI = 'BTIP01') AS SGOBASVURU, " +
                    "(SELECT BEB.BEBID FROM BSB_BEB BEB WHERE BEB.BEBID = DBS.BEBID AND BEB.BASVURUTIPI != 'BTIP01' AND BEB.BASVURUTIPI != 'BTIP02') AS KYSBASVURU,  " +
                    "(SELECT BEB.BEBID FROM BSB_BEB BEB WHERE BEB.BEBID = DBS.BEBID) AS TOPLAM, " +

                    "(SELECT dbo.getDiffDateWithRestDay(BASVURU.LOGISLEMTARIH, BEB.KAPANISTARIHI) FROM BSB_BEB BEB, BSB_BASVURU BASVURU WHERE BASVURU.BASVURUID=BEB.BASVURUID AND BEB.BEBID = DBS.BEBID AND BEB.BASVURUTIPI = 'BTIP02' AND BEB.KAPANISTARIHI is not null) AS BEBTAR, " +
                    "(SELECT datediff(day, BASVURU.LOGISLEMTARIH, BEB.KAPANISTARIHI) FROM BSB_BEB BEB, BSB_BASVURU BASVURU WHERE BASVURU.BASVURUID=BEB.BASVURUID AND BEB.BEBID = DBS.BEBID AND BEB.BASVURUTIPI = 'BTIP01' AND BEB.KAPANISTARIHI is not null) AS SGOTAR, " +
                    "(SELECT BEB.BEBID FROM BSB_BEB BEB, BSB_BASVURU BASVURU WHERE BASVURU.BASVURUID=BEB.BASVURUID AND BEB.BEBID = DBS.BEBID AND (( BEB.BASVURUTIPI = 'BTIP01' AND  ( (BEB.KAPANISTARIHI is null AND (datediff(day, BASVURU.LOGISLEMTARIH, GETDATE()) >30)) or  (BEB.KAPANISTARIHI is not null AND  (datediff(day, BASVURU.LOGISLEMTARIH, BEB.KAPANISTARIHI) > 30) ))) or ( BEB.BASVURUTIPI = 'BTIP02' AND  ( (BEB.KAPANISTARIHI is null AND (dbo.getDiffDateWithRestDay(BASVURU.LOGISLEMTARIH, GETDATE()) >15)) or  (BEB.KAPANISTARIHI is not null AND  (dbo.getDiffDateWithRestDay(BASVURU.LOGISLEMTARIH, BEB.KAPANISTARIHI)  > 15) ))))) AS SURESIGECEN   " +
                    "FROM BSB_DBS DBS " +
                    "WHERE DBS.BEBID IN (SELECT B.BEBID FROM BSB_BEB B WHERE B.BASVURUID IN (SELECT BASVURUID FROM BSB_BASVURU BASVURU WHERE BASVURU.TARIH >= '" + (DateTime.Parse(tarih1)).ToString("MM.dd.yyyy") + " 00:00:00.000" + "' AND BASVURU.TARIH <= '" + (DateTime.Parse(tarih2)).ToString("MM.dd.yyyy") + " 23:59:59.000" + "')))AS SORGU " +
                    "RIGHT JOIN Sozluk S " +
                    "ON  S.id = BIRIM " +
                    "WHERE S.id LIKE '%BRM%' AND S.id != 'BRM00'";
                }
                liste = db.Database.SqlQuery<T>(strSelect).ToList();
            }
            catch (Exception e)
            {
                throw e;
            }


            return liste;
        }

        public List<T> PerfBEIslemlerinSonuclari(string tarihler)
        {
            string[] tarih = tarihler.Split('-');
            string tarih1 = tarih[0];
            string tarih2 = tarih[1];
            List<T> liste = null;
            try
            {
                string strSelectdrBilgiEdinmeBasvSnc = "";
                if (tarih1.Equals("") || tarih2.Equals(""))
                {
                    strSelectdrBilgiEdinmeBasvSnc = "SELECT 'Dönem İçi Toplam Bilgi Edinme Başvurusu' as Baslik, COUNT(BASVURUTIPI) as Deger, '1' as sira FROM BSB_BEB WHERE BASVURUTIPI = 'BTIP02' UNION " +
                                                          "SELECT 'Olumlu' as Baslik, COUNT(BASVURUTIPI) as Deger, '2' as sira FROM BSB_BEB WHERE BASVURUTIPI = 'BTIP02' and BASVURUSONUC = 1 UNION " +
                                                          "SELECT 'Kısmen Olumlu' as Baslik, COUNT(BASVURUTIPI) as Deger, '3' as sira  FROM BSB_BEB WHERE BASVURUTIPI = 'BTIP02' and BASVURUSONUC = 2 UNION " +
                                                          "SELECT 'Red' as Baslik, COUNT(BASVURUTIPI) as Deger, '4' as sira  FROM BSB_BEB WHERE BASVURUTIPI = 'BTIP02' and BASVURUSONUC = 3 UNION " +
                                                          "SELECT 'Diğer Kurumlara İletilenler' as Baslik, COUNT(BASVURUTIPI) as Deger, '5' as sira FROM BSB_BEB WHERE BASVURUTIPI = 'BTIP02' and KURULICIDISI = 'KRL02' and KURULILGI = 1 UNION " +
                                                          "SELECT 'Kurul İlgisiz Kapatılanlar( Mükerrer başvurular vb.)' as  Baslik, COUNT(BASVURUTIPI) as Deger, '6' as sira FROM BSB_BEB WHERE BASVURUTIPI = 'BTIP02' and KURULICIDISI = 'KRL02' and KURULILGI = 2 order by sira";
                }
                else
                {
                    strSelectdrBilgiEdinmeBasvSnc = "SELECT 'Dönem İçi Toplam Bilgi Edinme Başvurusu' as Baslik, COUNT(BASVURUTIPI) as Deger, '1' as sira FROM BSB_BEB BEB WHERE BASVURUTIPI = 'BTIP02' " +
                                                          "AND BEB.BASVURUID IN (SELECT BASVURUID FROM BSB_BASVURU BASVURU WHERE BASVURU.TARIH >= '" + (DateTime.Parse(tarih1)).ToString("MM.dd.yyyy") + " 00:00:00.000" + "' AND BASVURU.TARIH <= '" + (DateTime.Parse(tarih2)).ToString("MM.dd.yyyy") + " 23:59:59.000" + "')" +
                                                          "UNION " +
                                                          "SELECT 'Olumlu' as Baslik, COUNT(BASVURUTIPI) as Deger, '2' as sira FROM BSB_BEB BEB WHERE BASVURUTIPI = 'BTIP02' and BASVURUSONUC = 1 " +
                                                          "AND BEB.BASVURUID IN (SELECT BASVURUID FROM BSB_BASVURU BASVURU WHERE BASVURU.TARIH >= '" + (DateTime.Parse(tarih1)).ToString("MM.dd.yyyy") + "' AND BASVURU.TARIH <= '" + (DateTime.Parse(tarih2)).ToString("MM.dd.yyyy") + " 23:59:59.000" + "')" +
                                                          "UNION " +
                                                          "SELECT 'Kısmen Olumlu' as Baslik, COUNT(BASVURUTIPI) as Deger, '3' as sira  FROM BSB_BEB BEB WHERE BASVURUTIPI = 'BTIP02' and BASVURUSONUC = 2 " +
                                                          "AND BEB.BASVURUID IN (SELECT BASVURUID FROM BSB_BASVURU BASVURU WHERE BASVURU.TARIH >= '" + (DateTime.Parse(tarih1)).ToString("MM.dd.yyyy") + " 00:00:00.000" + "' AND BASVURU.TARIH <= '" + (DateTime.Parse(tarih2)).ToString("MM.dd.yyyy") + " 23:59:59.000" + "')" +
                                                          "UNION " +
                                                          "SELECT 'Red' as Baslik, COUNT(BASVURUTIPI) as Deger, '4' as sira  FROM BSB_BEB BEB WHERE BASVURUTIPI = 'BTIP02' and BASVURUSONUC = 3 " +
                                                          "AND BEB.BASVURUID IN (SELECT BASVURUID FROM BSB_BASVURU BASVURU WHERE BASVURU.TARIH >= '" + (DateTime.Parse(tarih1)).ToString("MM.dd.yyyy") + " 00:00:00.000" + "' AND BASVURU.TARIH <= '" + (DateTime.Parse(tarih2)).ToString("MM.dd.yyyy") + " 23:59:59.000" + "')" +
                                                          "UNION " +
                                                          "SELECT 'Diğer Kurumlara İletilenler' as Baslik, COUNT(BASVURUTIPI) as Deger, '5' as sira FROM BSB_BEB BEB WHERE BASVURUTIPI = 'BTIP02' and KURULICIDISI = 'KRL02' and KURULILGI = 1 " +
                                                          "AND BEB.BASVURUID IN (SELECT BASVURUID FROM BSB_BASVURU BASVURU WHERE BASVURU.TARIH >= '" + (DateTime.Parse(tarih1)).ToString("MM.dd.yyyy") + " 00:00:00.000" + "' AND BASVURU.TARIH <= '" + (DateTime.Parse(tarih2)).ToString("MM.dd.yyyy") + " 23:59:59.000" + "')" +
                                                          "UNION " +
                                                          "SELECT 'Kurul İlgisiz Kapatılanlar( Mükerrer başvurular vb.)' as  Baslik, COUNT(BASVURUTIPI) as Deger, '6' as sira FROM BSB_BEB BEB WHERE BASVURUTIPI = 'BTIP02' and KURULICIDISI = 'KRL02' and KURULILGI = 2 " +
                                                          "AND BEB.BASVURUID IN (SELECT BASVURUID FROM BSB_BASVURU BASVURU WHERE BASVURU.TARIH >= '" + (DateTime.Parse(tarih1)).ToString("MM.dd.yyyy") + " 00:00:00.000" + "' AND BASVURU.TARIH <= '" + (DateTime.Parse(tarih2)).ToString("MM.dd.yyyy") + " 23:59:59.000" + "')" +
                                                          "order by sira";
                }
                liste = db.Database.SqlQuery<T>(strSelectdrBilgiEdinmeBasvSnc).ToList();
            }
            catch (Exception e)
            {
                throw e;
            }


            return liste;
        }
        public List<T> PerfBEKonuDagilimi(string tarihler)
        {
            string[] tarih = tarihler.Split('-');
            string tarih1 = tarih[0];
            string tarih2 = tarih[1];
            List<T> liste = null;
            try
            {
                string strSelectBEBKonuDagilimi = "";
                if (tarih1.Equals("") || tarih2.Equals(""))
                {
                    strSelectBEBKonuDagilimi = "SELECT BES.aciklama AS KONUADI,COUNT (BKONU) AS BKONUSAYISI FROM (SELECT BASVURU.KONU AS BKONU FROM BSB_BASVURU BASVURU WHERE BASVURU.BASVURUID IN (SELECT BASVURUID FROM BSB_BEB BEB WHERE BEB.BASVURUTIPI = 'BTIP02'))SORGU " +
                                                      "RIGHT JOIN BilgiEdinmeSozluk BES ON BES.id = BKONU where BES.id IN ('KON010000','KON020000','KON030000','KON040000','KON050000','KON060000','KON070000','KON080000','KON090000','KON100000','KON110000','KON120000', 'KON130000', 'KON140000') GROUP BY BES.aciklama " +
                                                      "UNION SELECT 'Toplam', COUNT (BKONU) AS BKONUSAYISI FROM (SELECT BASVURU.KONU AS BKONU FROM BSB_BASVURU BASVURU WHERE BASVURU.BASVURUID IN (SELECT BASVURUID FROM BSB_BEB BEB WHERE BEB.BASVURUTIPI = 'BTIP02'))SORGU RIGHT JOIN BilgiEdinmeSozluk BES " +
                                                      "ON BES.id = BKONU where BES.id IN ('KON010000','KON020000','KON030000','KON040000','KON050000','KON060000','KON070000','KON080000','KON090000','KON100000','KON110000','KON120000', 'KON130000', 'KON140000') ORDER BY BKONUSAYISI ";
                }
                else
                {
                    strSelectBEBKonuDagilimi = "SELECT BES.aciklama AS KONUADI,COUNT (BKONU) AS BKONUSAYISI FROM (SELECT BASVURU.KONU AS BKONU FROM BSB_BASVURU BASVURU WHERE BASVURU.BASVURUID IN (SELECT BASVURUID FROM BSB_BEB BEB WHERE BEB.BASVURUTIPI = 'BTIP02') " +
                                                      "AND BASVURU.TARIH >= '" + (DateTime.Parse(tarih1)).ToString("MM.dd.yyyy") + "' AND BASVURU.TARIH <= '" + (DateTime.Parse(tarih2)).ToString("MM.dd.yyyy") + "')SORGU " +
                                                      "RIGHT JOIN BilgiEdinmeSozluk BES ON BES.id = BKONU where BES.id IN ('KON010000','KON020000','KON030000','KON040000','KON050000','KON060000','KON070000','KON080000','KON090000','KON100000','KON110000','KON120000', 'KON130000', 'KON140000') GROUP BY BES.aciklama " +
                                                      "UNION SELECT 'Toplam', COUNT (BKONU) AS BKONUSAYISI FROM (SELECT BASVURU.KONU AS BKONU FROM BSB_BASVURU BASVURU WHERE BASVURU.BASVURUID IN (SELECT BASVURUID FROM BSB_BEB BEB WHERE BEB.BASVURUTIPI = 'BTIP02') " +
                                                      "AND BASVURU.TARIH >= '" + (DateTime.Parse(tarih1)).ToString("MM.dd.yyyy") + " 00:00:00.000" + "' AND BASVURU.TARIH <= '" + (DateTime.Parse(tarih2)).ToString("MM.dd.yyyy") + " 23:59:59.000" + "')SORGU RIGHT JOIN BilgiEdinmeSozluk BES " +
                                                      "ON BES.id = BKONU where BES.id IN ('KON010000','KON020000','KON030000','KON040000','KON050000','KON060000','KON070000','KON080000','KON090000','KON100000','KON110000','KON120000', 'KON130000', 'KON140000') ORDER BY BKONUSAYISI ";
                }
                liste = db.Database.SqlQuery<T>(strSelectBEBKonuDagilimi).ToList();
            }

            catch (Exception ex)
            {
                throw ex;
            }
            return liste;
        }

        public List<T> PerfSGOKonuDagilimi(string tarihler)
        {
            string[] tarih = tarihler.Split('-');
            string tarih1 = tarih[0];
            string tarih2 = tarih[1];
            List<T> liste = null;
            try
            {
                string strSelectGOSKonuDagilimi = "";
                if (tarih1.Equals("") || tarih2.Equals(""))
                {
                    strSelectGOSKonuDagilimi = "SELECT BES.aciklama AS KONUADI, " +
                    "COUNT (BKONU) AS BKONUSAYISI " +
                    "FROM " +
                    "(SELECT BASVURU.KONU AS BKONU FROM BSB_BASVURU BASVURU " +
                    "WHERE BASVURU.BASVURUID IN (SELECT BASVURUID FROM BSB_BEB BEB WHERE BEB.BASVURUTIPI = 'BTIP01'))SORGU " +
                    "RIGHT JOIN BilgiEdinmeSozluk BES " +
                    "ON BES.id = BKONU " +
                    "where BES.id LIKE '%ONR%' AND BES.id <> 'ONR000' " +
                    "GROUP BY BES.aciklama " +
                    "UNION " +
                    "SELECT 'Toplam', " +
                    "COUNT (BKONU) AS BKONUSAYISI " +
                    "FROM " +
                    "(SELECT BASVURU.KONU AS BKONU FROM BSB_BASVURU BASVURU " +
                    "WHERE BASVURU.BASVURUID IN (SELECT BASVURUID FROM BSB_BEB BEB WHERE BEB.BASVURUTIPI = 'BTIP01'))SORGU " +
                    "RIGHT JOIN BilgiEdinmeSozluk BES " +
                    "ON BES.id = BKONU " +
                    "where BES.id LIKE '%ONR%' AND BES.id <> 'ONR000' " +
                    "ORDER BY BKONUSAYISI ";
                }
                else
                {
                    strSelectGOSKonuDagilimi = "SELECT BES.aciklama AS KONUADI, " +
                    "COUNT (BKONU) AS BKONUSAYISI " +
                    "FROM " +
                    "(SELECT BASVURU.KONU AS BKONU FROM BSB_BASVURU BASVURU " +
                    "WHERE BASVURU.BASVURUID IN (SELECT BASVURUID FROM BSB_BEB BEB WHERE BEB.BASVURUTIPI = 'BTIP01') " +
                    "AND BASVURU.TARIH >= '" + (DateTime.Parse(tarih1)).ToString("MM.dd.yyyy") + " 00:00:00.000" + "' AND BASVURU.TARIH <= '" + (DateTime.Parse(tarih2)).ToString("MM.dd.yyyy") + " 23:59:59.000" + "')SORGU " +
                    "RIGHT JOIN BilgiEdinmeSozluk BES " +
                    "ON BES.id = BKONU " +
                    "where BES.id LIKE '%ONR%' AND BES.id <> 'ONR000' " +
                    "GROUP BY BES.aciklama " +
                    "UNION " +
                    "SELECT 'Toplam', " +
                    "COUNT (BKONU) AS BKONUSAYISI " +
                    "FROM " +
                    "(SELECT BASVURU.KONU AS BKONU FROM BSB_BASVURU BASVURU " +
                    "WHERE BASVURU.BASVURUID IN (SELECT BASVURUID FROM BSB_BEB BEB WHERE BEB.BASVURUTIPI = 'BTIP01') " +
                    "AND BASVURU.TARIH >= '" + (DateTime.Parse(tarih1)).ToString("MM.dd.yyyy") + " 00:00:00.000" + "' AND BASVURU.TARIH <= '" + (DateTime.Parse(tarih2)).ToString("MM.dd.yyyy") + " 23:59:59.000" + "')SORGU " +
                    "RIGHT JOIN BilgiEdinmeSozluk BES " +
                    "ON BES.id = BKONU " +
                    "where BES.id LIKE '%ONR%' AND BES.id <> 'ONR000' " +
                    "ORDER BY BKONUSAYISI ";
                }
                liste = db.Database.SqlQuery<T>(strSelectGOSKonuDagilimi).ToList();
            }

            catch (Exception ex)
            {
                throw ex;
            }
            return liste;
        }

        public string kalanZaman(string tur, string sql)
        {
            string sonuc = db.Database.SqlQuery<string>(sql).ToList().FirstOrDefault();
            throw new NotImplementedException();
        }

        public decimal MaxDeger(Expression<Func<T, decimal>> where)
        {
            return objSet.Max(where);

        }

        public List<T> BirimSureHesaplama(string brm, string tur, string tarihler)
        {
            string[] tarih = tarihler.Split('-');
            string tarih1 = tarih[0];
            string tarih2 = tarih[1];
            List<T> liste = null;
            string strSelectBirimSurec = "";
            strSelectBirimSurec = "select bas.BASVURUID as BasvuruId, dbs.YONBIRIM as YonBirim, bas. TARIH as BasvuruTarihi,  bas.LOGISLEMTARIH as LogIslemTarihi, beb.KAPANISTARIHI as KapanisTarihi, dbs.YONTARIHI as YonTarih, gorevli.ATANMATARIHI as AtanmaTarihi, gorevli.ISLEMTARIHI as IslemTarihi, dbs.BASVURUCEVAPTARIHI as BasvuruCevapTarihi " +
              "from BSB_BASVURU bas, BSB_BEB beb, BSB_DBS dbs " +
              "left JOIN BSB_DBS_GOREVLI gorevli ON  gorevli.DBSID = dbs.DBSID " +
              "where bas.BASVURUID = beb.BASVURUID and beb.BEBID = dbs.BEBID " +
              "and beb.BASVURUTIPI = '" + tur + "' " +
              "AND bas.TARIH >= '" + (DateTime.Parse(tarih1)).ToString("MM.dd.yyyy") + " 00:00:00.000" + "' AND bas.TARIH <= '" + (DateTime.Parse(tarih2)).ToString("MM.dd.yyyy") + " 23:59:59.000" + "' and dbs.YONBIRIM='" + brm + "'";

            liste = db.Database.SqlQuery<T>(strSelectBirimSurec).ToList();
            return liste;

        }

        public T KurulGenelHesaplama(string brm, string tur, string tarihler)
        {
            string[] tarih = tarihler.Split('-');
            string tarih1 = tarih[0];
            string tarih2 = tarih[1];

            //string kapaliAdet = "";
            KurulGenel kurulgenel = new KurulGenel();

            kurulgenel.BirimAdi = brm;
            string kapalisayi = " select COUNT(*) " +
             "from BSB_BASVURU bas, BSB_BEB beb, BSB_DBS dbs, Sozluk S " +
             "where bas.BASVURUID = beb.BASVURUID and beb.BEBID = dbs.BEBID and S.id = dbs.YONBIRIM " +
            "AND bas.TARIH >= '" + (DateTime.Parse(tarih1)).ToString("MM.dd.yyyy") + " 00:00:00.000" + "' AND bas.TARIH <= '" + (DateTime.Parse(tarih2)).ToString("MM.dd.yyyy") + " 23:59:59.000" + "'" +
             "and dbs.YONTARIHI = (select MAX(dbs1.YONTARIHI) from BSB_DBS dbs1 where dbs1.BEBID = beb.BEBID and dbs1.YONBIRIM = dbs.YONBIRIM) " +
             "and beb.KAPANISTARIHI is not null " +
             "and S.explanation = '" + brm + "' " +
             "and beb.BASVURUTIPI='" + tur + "' " +
             "group by S.explanation";
            kurulgenel.KapaliAdedi = db.Database.SqlQuery<int>(kapalisayi).FirstOrDefault();

            string kapalicimersuresigecen = " select COUNT(*) " +
           "from BSB_BASVURU bas, BSB_BEB beb, BSB_DBS dbs, Sozluk S " +
           "where bas.BASVURUID = beb.BASVURUID and beb.BEBID = dbs.BEBID and S.id = dbs.YONBIRIM " +
          "AND bas.TARIH >= '" + (DateTime.Parse(tarih1)).ToString("MM.dd.yyyy") + " 00:00:00.000" + "' AND bas.TARIH <= '" + (DateTime.Parse(tarih2)).ToString("MM.dd.yyyy") + " 23:59:59.000" + "'" +
           "and dbs.YONTARIHI = (select MAX(dbs1.YONTARIHI) from BSB_DBS dbs1 where dbs1.BEBID = beb.BEBID and dbs1.YONBIRIM = dbs.YONBIRIM) " +
           "and beb.KAPANISTARIHI is not null "
           + (tur.Equals("BTIP02") ? "and dbo.getDiffDateWithRestDay(bas.LOGISLEMTARIH, beb.KAPANISTARIHI) >= 15 " : "and DATEDIFF(day, bas.LOGISLEMTARIH, beb.KAPANISTARIHI) >=30 ") +
            //"and dbo.getDiffDateWithRestDay(bas.LOGISLEMTARIH, beb.KAPANISTARIHI) >" +( tur.Equals("BTIP02") ? " 15 " : " 30 ") +
           "and S.explanation = '" + brm + "' " +
           "and beb.BASVURUTIPI='" + tur + "' " +
           "group by S.explanation";
            kurulgenel.KapaliCimerSureGecenSayi = db.Database.SqlQuery<int>(kapalicimersuresigecen).FirstOrDefault();

            string birdencok = "select  COUNT(*)  " +
                   "from BSB_BASVURU bas, BSB_BEB beb, BSB_DBS dbs, Sozluk S  " +
                   "where bas.BASVURUID = beb.BASVURUID and beb.BEBID = dbs.BEBID and S.id = dbs.YONBIRIM  " +
                   "AND bas.TARIH >= '" + (DateTime.Parse(tarih1)).ToString("MM.dd.yyyy") + " 00:00:00.000" + "' AND bas.TARIH <= '" + (DateTime.Parse(tarih2)).ToString("MM.dd.yyyy") + " 23:59:59.000" + "'" +
                   "and dbs.YONTARIHI = (select MAX(dbs1.YONTARIHI) from BSB_DBS dbs1 where dbs1.BEBID = beb.BEBID and dbs1.YONBIRIM = dbs.YONBIRIM) " +
                   "and beb.KAPANISTARIHI is not null "
                   + (tur.Equals("BTIP02") ? "and dbo.getDiffDateWithRestDay(bas.LOGISLEMTARIH, beb.KAPANISTARIHI) >= 15 " : "and DATEDIFF(day, bas.LOGISLEMTARIH, beb.KAPANISTARIHI) >=30 ") +
                   //"and dbo.getDiffDateWithRestDay(bas.LOGISLEMTARIH, beb.KAPANISTARIHI) >" + ( tur == "BTIP02" ? "15 " : "30 ") +
                   "and(select COUNT(*) from BSB_DBS dbs2 where dbs2.BEBID = beb.BEBID) > 1 " +
                   "and S.explanation = '" + brm + "' " +
                   "and beb.BASVURUTIPI='" + tur + "' " +
                   "group by S.explanation ";
            kurulgenel.KapaliCimerBirdenFazlaDaire = db.Database.SqlQuery<int>(birdencok).FirstOrDefault();
            string iade = " select COUNT(*) " +
           "from BSB_BASVURU bas, BSB_BEB beb, BSB_DBS dbs, Sozluk S " +
           "where bas.BASVURUID = beb.BASVURUID and beb.BEBID = dbs.BEBID and S.id = dbs.YONBIRIM " +
          "AND bas.TARIH >= '" + (DateTime.Parse(tarih1)).ToString("MM.dd.yyyy") + " 00:00:00.000" + "' AND bas.TARIH <= '" + (DateTime.Parse(tarih2)).ToString("MM.dd.yyyy") + " 23:59:59.000" + "'" +
           "and dbs.YONTARIHI = (select MAX(dbs1.YONTARIHI) from BSB_DBS dbs1 where dbs1.BEBID = beb.BEBID and dbs1.YONBIRIM = dbs.YONBIRIM) "
             + (tur.Equals("BTIP02") ? "and dbo.getDiffDateWithRestDay(bas.LOGISLEMTARIH, beb.KAPANISTARIHI) >= 15 " : "and DATEDIFF(day, bas.LOGISLEMTARIH, beb.KAPANISTARIHI) >=30 ") +
           // "and dbo.getDiffDateWithRestDay(bas.LOGISLEMTARIH, beb.KAPANISTARIHI) > " + (tur == "BTIP02" ? "15 " : "30 " )+
           "and beb.KAPANISTARIHI is not null " +
           "and S.explanation = '" + brm + "' " +
           "and beb.BASVURUTIPI='" + tur + "' " +
           "and dbs.IADE=1 " +
           "group by S.explanation";
            kurulgenel.KapaliCimerIadeEdilen = db.Database.SqlQuery<int>(iade).FirstOrDefault();

            string kapalibastarsuresigecen = " select COUNT(*) " +
        "from BSB_BASVURU bas, BSB_BEB beb, BSB_DBS dbs, Sozluk S " +
        "where bas.BASVURUID = beb.BASVURUID and beb.BEBID = dbs.BEBID and S.id = dbs.YONBIRIM " +
       "AND bas.TARIH >= '" + (DateTime.Parse(tarih1)).ToString("MM.dd.yyyy") + " 00:00:00.000" + "' AND bas.TARIH <= '" + (DateTime.Parse(tarih2)).ToString("MM.dd.yyyy") + " 23:59:59.000" + "'" +
        "and dbs.YONTARIHI = (select MAX(dbs1.YONTARIHI) from BSB_DBS dbs1 where dbs1.BEBID = beb.BEBID and dbs1.YONBIRIM = dbs.YONBIRIM) " +
        "and beb.KAPANISTARIHI is not null "
           + (tur.Equals("BTIP02") ? "and dbo.getDiffDateWithRestDay(bas.TARIH, beb.KAPANISTARIHI) >= 15 " : "and DATEDIFF(day, bas.TARIH, beb.KAPANISTARIHI) >=30 ") +
        // "and dbo.getDiffDateWithRestDay(bas.TARIH, beb.KAPANISTARIHI) >" + (tur == "BTIP02" ? "15 " : "30 " )+
        "and S.explanation = '" + brm + "' " +
        "and beb.BASVURUTIPI='" + tur + "' " +
        "group by S.explanation";
            kurulgenel.KapaliBasTarSureGecenSayi = db.Database.SqlQuery<int>(kapalibastarsuresigecen).FirstOrDefault();

            string bastarbirdencok = "select  COUNT(*)  " +
                  "from BSB_BASVURU bas, BSB_BEB beb, BSB_DBS dbs, Sozluk S  " +
                  "where bas.BASVURUID = beb.BASVURUID and beb.BEBID = dbs.BEBID and S.id = dbs.YONBIRIM  " +
                  "AND bas.TARIH >= '" + (DateTime.Parse(tarih1)).ToString("MM.dd.yyyy") + " 00:00:00.000" + "' AND bas.TARIH <= '" + (DateTime.Parse(tarih2)).ToString("MM.dd.yyyy") + " 23:59:59.000" + "'" +
                  "and dbs.YONTARIHI = (select MAX(dbs1.YONTARIHI) from BSB_DBS dbs1 where dbs1.BEBID = beb.BEBID and dbs1.YONBIRIM = dbs.YONBIRIM) " +
                  "and beb.KAPANISTARIHI is not null "
                     + (tur.Equals("BTIP02") ? "and dbo.getDiffDateWithRestDay(bas.TARIH, beb.KAPANISTARIHI) >= 15 " : "and DATEDIFF(day, bas.TARIH, beb.KAPANISTARIHI) >=30 ") +
                  // "and dbo.getDiffDateWithRestDay(bas.TARIH, beb.KAPANISTARIHI) > " + ( tur== "BTIP02" ? "15 " : "30 ") +
                  "and(select COUNT(*) from BSB_DBS dbs2 where dbs2.BEBID = beb.BEBID) > 1 " +
                  "and S.explanation = '" + brm + "' " +
                  "and beb.BASVURUTIPI='" + tur + "' " +
                  "group by S.explanation ";
            kurulgenel.KapaliBasTarBirdenFazlaDaire = db.Database.SqlQuery<int>(bastarbirdencok).FirstOrDefault();
            string bastariade = " select COUNT(*) " +
           "from BSB_BASVURU bas, BSB_BEB beb, BSB_DBS dbs, Sozluk S " +
           "where bas.BASVURUID = beb.BASVURUID and beb.BEBID = dbs.BEBID and S.id = dbs.YONBIRIM " +
          "AND bas.TARIH >= '" + (DateTime.Parse(tarih1)).ToString("MM.dd.yyyy") + " 00:00:00.000" + "' AND bas.TARIH <= '" + (DateTime.Parse(tarih2)).ToString("MM.dd.yyyy") + " 23:59:59.000" + "'" +
           "and dbs.YONTARIHI = (select MAX(dbs1.YONTARIHI) from BSB_DBS dbs1 where dbs1.BEBID = beb.BEBID and dbs1.YONBIRIM = dbs.YONBIRIM) "
              + (tur.Equals("BTIP02") ? "and dbo.getDiffDateWithRestDay(bas.TARIH, beb.KAPANISTARIHI) >= 15 " : "and DATEDIFF(day, bas.TARIH, beb.KAPANISTARIHI) >=30 ") +
           // "and dbo.getDiffDateWithRestDay(bas.TARIH, beb.KAPANISTARIHI) >" + ( tur == "BTIP02" ? "15 " : "30 ") +
           "and beb.KAPANISTARIHI is not null " +
           "and S.explanation = '" + brm + "' " +
           "and beb.BASVURUTIPI='" + tur + "' " +
           "and dbs.IADE=1 " +
           "group by S.explanation";
            kurulgenel.KapaliBasTarIadeEdilen = db.Database.SqlQuery<int>(bastariade).FirstOrDefault();
            //Açık basvurular 
            string aciksayi = " select COUNT(*) " +
          "from BSB_BASVURU bas, BSB_BEB beb, BSB_DBS dbs, Sozluk S " +
          "where bas.BASVURUID = beb.BASVURUID and beb.BEBID = dbs.BEBID and S.id = dbs.YONBIRIM " +
         "AND bas.TARIH >= '" + (DateTime.Parse(tarih1)).ToString("MM.dd.yyyy") + " 00:00:00.000" + "' AND bas.TARIH <= '" + (DateTime.Parse(tarih2)).ToString("MM.dd.yyyy") + " 23:59:59.000" + "'" +
          "and dbs.YONTARIHI = (select MAX(dbs1.YONTARIHI) from BSB_DBS dbs1 where dbs1.BEBID = beb.BEBID and dbs1.YONBIRIM = dbs.YONBIRIM) " +
          "and beb.KAPANISTARIHI is null " +
          "and S.explanation = '" + brm + "' " +
          "and beb.BASVURUTIPI='" + tur + "' " +
          "group by S.explanation";
            kurulgenel.AcikAdedi = db.Database.SqlQuery<int>(aciksayi).FirstOrDefault();

            string acikcimersuresigecen = " select COUNT(*) " +
           "from BSB_BASVURU bas, BSB_BEB beb, BSB_DBS dbs, Sozluk S " +
           "where bas.BASVURUID = beb.BASVURUID and beb.BEBID = dbs.BEBID and S.id = dbs.YONBIRIM " +
          "AND bas.TARIH >= '" + (DateTime.Parse(tarih1)).ToString("MM.dd.yyyy") + " 00:00:00.000" + "' AND bas.TARIH <= '" + (DateTime.Parse(tarih2)).ToString("MM.dd.yyyy") + " 23:59:59.000" + "'" +
           "and dbs.YONTARIHI = (select MAX(dbs1.YONTARIHI) from BSB_DBS dbs1 where dbs1.BEBID = beb.BEBID and dbs1.YONBIRIM = dbs.YONBIRIM) " +
           "and beb.KAPANISTARIHI is null "
             + (tur.Equals("BTIP02") ? "and dbo.getDiffDateWithRestDay(bas.LOGISLEMTARIH, beb.KAPANISTARIHI) >= 15 " : "and DATEDIFF(day, bas.LOGISLEMTARIH, beb.KAPANISTARIHI) >=30 ") +
           // "and dbo.getDiffDateWithRestDay(bas.LOGISLEMTARIH, beb.KAPANISTARIHI) >" + (tur == "BTIP02" ? "15 " : "30 ") +
           "and S.explanation = '" + brm + "' " +
           "and beb.BASVURUTIPI='" + tur + "' " +
           "group by S.explanation";
            kurulgenel.AcikCimerSureGecenSayi = db.Database.SqlQuery<int>(acikcimersuresigecen).FirstOrDefault();

            string acikbirdencok = "select  COUNT(*)  " +
                   "from BSB_BASVURU bas, BSB_BEB beb, BSB_DBS dbs, Sozluk S  " +
                   "where bas.BASVURUID = beb.BASVURUID and beb.BEBID = dbs.BEBID and S.id = dbs.YONBIRIM  " +
                   "AND bas.TARIH >= '" + (DateTime.Parse(tarih1)).ToString("MM.dd.yyyy") + " 00:00:00.000" + "' AND bas.TARIH <= '" + (DateTime.Parse(tarih2)).ToString("MM.dd.yyyy") + " 23:59:59.000" + "'" +
                   "and dbs.YONTARIHI = (select MAX(dbs1.YONTARIHI) from BSB_DBS dbs1 where dbs1.BEBID = beb.BEBID and dbs1.YONBIRIM = dbs.YONBIRIM) " +
                   "and beb.KAPANISTARIHI is null "
                     + (tur.Equals("BTIP02") ? "and dbo.getDiffDateWithRestDay(bas.LOGISLEMTARIH, beb.KAPANISTARIHI) >= 15 " : "and DATEDIFF(day, bas.LOGISLEMTARIH, beb.KAPANISTARIHI) >=30 ") +
                   // "and dbo.getDiffDateWithRestDay(bas.LOGISLEMTARIH, beb.KAPANISTARIHI) >" + ( tur == "BTIP02" ? "15 " : "30 " )+
                   "and(select COUNT(*) from BSB_DBS dbs2 where dbs2.BEBID = beb.BEBID) > 1 " +
                   "and S.explanation = '" + brm + "' " +
                   "and beb.BASVURUTIPI='" + tur + "' " +
                   "group by S.explanation ";
            kurulgenel.AcikCimerBirdenFazlaDaire = db.Database.SqlQuery<int>(acikbirdencok).FirstOrDefault();
            string acikiade = " select COUNT(*) " +
           "from BSB_BASVURU bas, BSB_BEB beb, BSB_DBS dbs, Sozluk S " +
           "where bas.BASVURUID = beb.BASVURUID and beb.BEBID = dbs.BEBID and S.id = dbs.YONBIRIM " +
          "AND bas.TARIH >= '" + (DateTime.Parse(tarih1)).ToString("MM.dd.yyyy") + " 00:00:00.000" + "' AND bas.TARIH <= '" + (DateTime.Parse(tarih2)).ToString("MM.dd.yyyy") + " 23:59:59.000" + "'" +
           "and dbs.YONTARIHI = (select MAX(dbs1.YONTARIHI) from BSB_DBS dbs1 where dbs1.BEBID = beb.BEBID and dbs1.YONBIRIM = dbs.YONBIRIM) "
             + (tur.Equals("BTIP02") ? "and dbo.getDiffDateWithRestDay(bas.LOGISLEMTARIH, beb.KAPANISTARIHI) >= 15 " : "and DATEDIFF(day, bas.LOGISLEMTARIH, beb.KAPANISTARIHI) >=30 ") +
           //"and dbo.getDiffDateWithRestDay(bas.LOGISLEMTARIH, beb.KAPANISTARIHI) > " + ( tur == "BTIP02" ? "15 " : "30 " )+
           "and beb.KAPANISTARIHI is null " +
           "and S.explanation = '" + brm + "' " +
           "and beb.BASVURUTIPI='" + tur + "' " +
           "and dbs.IADE=1 " +
           "group by S.explanation";
            kurulgenel.AcikCimerIadeEdilen = db.Database.SqlQuery<int>(acikiade).FirstOrDefault();

            string acikbastarsuresigecen = " select COUNT(*) " +
        "from BSB_BASVURU bas, BSB_BEB beb, BSB_DBS dbs, Sozluk S " +
        "where bas.BASVURUID = beb.BASVURUID and beb.BEBID = dbs.BEBID and S.id = dbs.YONBIRIM " +
       "AND bas.TARIH >= '" + (DateTime.Parse(tarih1)).ToString("MM.dd.yyyy") + " 00:00:00.000" + "' AND bas.TARIH <= '" + (DateTime.Parse(tarih2)).ToString("MM.dd.yyyy") + " 23:59:59.000" + "'" +
        "and dbs.YONTARIHI = (select MAX(dbs1.YONTARIHI) from BSB_DBS dbs1 where dbs1.BEBID = beb.BEBID and dbs1.YONBIRIM = dbs.YONBIRIM) " +
        "and beb.KAPANISTARIHI is null "
         + (tur.Equals("BTIP02") ? "and dbo.getDiffDateWithRestDay(bas.TARIH, beb.KAPANISTARIHI) >= 15 " : "and DATEDIFF(day, bas.TARIH, beb.KAPANISTARIHI) >=30 ") +
        // "and dbo.getDiffDateWithRestDay(bas.TARIH, beb.KAPANISTARIHI) >" + (tur == "BTIP02" ? "15 " : "30 ") +
        "and S.explanation = '" + brm + "' " +
        "and beb.BASVURUTIPI='" + tur + "' " +
        "group by S.explanation";
            kurulgenel.AcikBasTarSureGecenSayi = db.Database.SqlQuery<int>(acikbastarsuresigecen).FirstOrDefault();

            string acikbastarbirdencok = "select  COUNT(*)  " +
                  "from BSB_BASVURU bas, BSB_BEB beb, BSB_DBS dbs, Sozluk S  " +
                  "where bas.BASVURUID = beb.BASVURUID and beb.BEBID = dbs.BEBID and S.id = dbs.YONBIRIM  " +
                  "AND bas.TARIH >= '" + (DateTime.Parse(tarih1)).ToString("MM.dd.yyyy") + " 00:00:00.000" + "' AND bas.TARIH <= '" + (DateTime.Parse(tarih2)).ToString("MM.dd.yyyy") + " 23:59:59.000" + "'" +
                  "and dbs.YONTARIHI = (select MAX(dbs1.YONTARIHI) from BSB_DBS dbs1 where dbs1.BEBID = beb.BEBID and dbs1.YONBIRIM = dbs.YONBIRIM) " +
                  "and beb.KAPANISTARIHI is null "
                   + (tur.Equals("BTIP02") ? "and dbo.getDiffDateWithRestDay(bas.TARIH, beb.KAPANISTARIHI) >= 15 " : "and DATEDIFF(day, bas.TARIH, beb.KAPANISTARIHI) >=30 ") +
                  //"and dbo.getDiffDateWithRestDay(bas.TARIH, beb.KAPANISTARIHI) > " + (tur == "BTIP02" ? "15 " : "30 ") +
                  "and(select COUNT(*) from BSB_DBS dbs2 where dbs2.BEBID = beb.BEBID) > 1 " +
                  "and S.explanation = '" + brm + "' " +
                  "and beb.BASVURUTIPI='" + tur + "' " +
                  "group by S.explanation ";
            kurulgenel.AcikBasTarBirdenFazlaDaire = db.Database.SqlQuery<int>(acikbastarbirdencok).FirstOrDefault();
            string acikbastariade = " select COUNT(*) " +
           "from BSB_BASVURU bas, BSB_BEB beb, BSB_DBS dbs, Sozluk S " +
           "where bas.BASVURUID = beb.BASVURUID and beb.BEBID = dbs.BEBID and S.id = dbs.YONBIRIM " +
          "AND bas.TARIH >= '" + (DateTime.Parse(tarih1)).ToString("MM.dd.yyyy") + " 00:00:00.000" + "' AND bas.TARIH <= '" + (DateTime.Parse(tarih2)).ToString("MM.dd.yyyy") + " 23:59:59.000" + "'" +
           "and dbs.YONTARIHI = (select MAX(dbs1.YONTARIHI) from BSB_DBS dbs1 where dbs1.BEBID = beb.BEBID and dbs1.YONBIRIM = dbs.YONBIRIM) "
           + (tur.Equals("BTIP02") ? "and dbo.getDiffDateWithRestDay(bas.TARIH, beb.KAPANISTARIHI) >= 15 " : "and DATEDIFF(day, bas.TARIH, beb.KAPANISTARIHI) >=30 ") +
           // "and dbo.getDiffDateWithRestDay(bas.TARIH, beb.KAPANISTARIHI) >" + (tur == "BTIP02" ? "15 " : "30 " )+
           "and beb.KAPANISTARIHI is null " +
           "and S.explanation = '" + brm + "' " +
           "and beb.BASVURUTIPI='" + tur + "' " +
           "and dbs.IADE=1 " +
           "group by S.explanation";
            kurulgenel.AcikBasTarIadeEdilen = db.Database.SqlQuery<int>(acikbastariade).FirstOrDefault();

            return (T)Convert.ChangeType(kurulgenel, typeof(T));
        }

        public List<T> IadeHesaplama(string tur, string tarihler)
        {
            string[] tarih = tarihler.Split('-');
            string tarih1 = tarih[0];
            string tarih2 = tarih[1];
            List<T> liste = null;
            string striade = "";

            striade = "select S.explanation as BirimAdi, COUNT(*) as Sayisi,  " +
             " CONVERT(NUMERIC(12, 2), ((hes.toplam) * 1.0) / (COUNT(dbs.YONBIRIM) * 1.0)) as OrtIadeSure " +
             " from BSB_BASVURU bas, BSB_BEB beb, BSB_DBS dbs " +
             " , (select dbs.YONBIRIM yon, SUM(dbo.getDiffDateWithRestDay(dbs.YONTARIHI, dbs.BASVURUCEVAPTARIHI) * 1.0) as toplam from BSB_BASVURU bas, BSB_BEB beb, BSB_DBS dbs       where bas.BASVURUID = beb.BASVURUID and beb.BEBID = dbs.BEBID " +
             " and bas.TARIH >= '01.01.2019 00:00:00.000' AND bas.TARIH <= '12.31.2019 23:59:59.000' " +
             " and dbs.IADE = 1" +
             " and beb.BASVURUTIPI = 'BTIP02'  group by dbs.YONBIRIM )  hes" +
             " ,Sozluk S " +
             "  where S.id = dbs.YONBIRIM and S.id LIKE '%BRM%' AND S.id != 'BRM00' " +
             " and bas.BASVURUID = beb.BASVURUID and beb.BEBID = dbs.BEBID" +
             " and hes.yon = dbs.YONBIRIM" +
             " and bas.TARIH >= '" + (DateTime.Parse(tarih1)).ToString("MM.dd.yyyy") + " 00:00:00.000" + "' AND bas.TARIH <= '" + (DateTime.Parse(tarih2)).ToString("MM.dd.yyyy") + " 23:59:59.000" + "'" +
             " and dbs.IADE = 1" +
             " and beb.BASVURUTIPI = '" + tur + "' " +
             " group by S.explanation, hes.toplam";

            liste = db.Database.SqlQuery<T>(striade).ToList();
            return liste;

        }

        public List<T> SuresiGecenBasvurularHesaplama(string tarihler)
        {
            string[] tarih = tarihler.Split('-');
            string tarih1 = tarih[0];
            string tarih2 = tarih[1];
            List<T> liste = null;
            string strsuresigecen = "";

            strsuresigecen = "select basvuru.BASVURUID, basvuru.ADSOYAD,beb.BASVURUTIPI " +
                   " ,soz.aciklama as KONU" +
                   " , DATEDIFF(day, basvuru.LOGISLEMTARIH, beb.KAPANISTARIHI) as CIMERTARIHINEGOREGUN " +
                  " , DATEDIFF(day, basvuru.TARIH, beb.KAPANISTARIHI) as BASVURUTARIHINEGOREGUN " +
                  "  ,(select count(*) as IadeSayisi from BSB_DBS dbs where beb.BEBID = dbs.BEBID and IADE = 1) as IADE, " +
                  " (select count(*) as YonlendirilenBirimSayisi from BSB_DBS dbs where beb.BEBID = dbs.BEBID) as BIRDENCOK, " +
                  " (select count(*) as CevaplayanBirimSayisi from BSB_DBS dbs where beb.BEBID = dbs.BEBID and SONDURUM in ('DDUR05', " +
                  " 'DDUR06')) as CEVAPLAYANBIRIM " +
                  " from BSB_BASVURU basvuru, BSB_BEB beb , BilgiEdinmeSozluk soz " +
                  " where basvuru.BASVURUID = beb.BASVURUID " +
                  "  and soz.id= basvuru.KONU " +
                  " and basvuru.TARIH >= '" + (DateTime.Parse(tarih1)).ToString("MM.dd.yyyy") + " 00:00:00.000" + "' AND basvuru.TARIH <= '" + (DateTime.Parse(tarih2)).ToString("MM.dd.yyyy") + " 23:59:59.000" + "'" +
                  " and(dbo.getDiffDateWithRestDay(basvuru.LOGISLEMTARIH, beb.KAPANISTARIHI) >= " +
                  " CASE beb.BASVURUTIPI  when  'BTIP02' then  15 END" +
                  "   or  DATEDIFF(day, basvuru.LOGISLEMTARIH, beb.KAPANISTARIHI) >= " +
                  " CASE beb.BASVURUTIPI  when 'BTIP01' then 30 END " +
                  " or DATEDIFF(day, basvuru.LOGISLEMTARIH, beb.KAPANISTARIHI) >=  CASE beb.BASVURUTIPI  when 'BTIP03' then 30 END  " +
                  " or DATEDIFF(day, basvuru.LOGISLEMTARIH, beb.KAPANISTARIHI) >= CASE beb.BASVURUTIPI when 'BTIP04' then 30 END)";

            liste = db.Database.SqlQuery<T>(strsuresigecen).ToList();
            return liste;

        }

        public List<T> BirimBazindaSuresiGecenBasvurularHesaplama(string brm, string tarihler)
        {
            string[] tarih = tarihler.Split('-');
            string tarih1 = tarih[0];
            string tarih2 = tarih[1];
            List<T> liste = null;
            string strsuresigecen = "";

            strsuresigecen = "select basvuru.BASVURUID, basvuru.ADSOYAD,beb.BASVURUTIPI  ,soz.aciklama as KONU ,  " +
                             "basvuru.LOGISLEMTARIH cimertarihi, " +
" basvuru.TARIH uygulamayagirentarih,  " +
"  DATEDIFF(day, basvuru.LOGISLEMTARIH, basvuru.TARIH) as CIMERUYGULAMATARIH  ,  " +
"  dbs.YONTARIHI,  " +
"  DATEDIFF(day, basvuru.TARIH, dbs.YONTARIHI) as UYGULAMAYONTARIH  ,    " +
"  dbs.BASVURUCEVAPTARIHI,  " +
"   DATEDIFF(day, dbs.YONTARIHI, dbs.BASVURUCEVAPTARIHI) as YONCEVAPTARIH  , " +
"   beb.KAPANISTARIHI,  " +
"      DATEDIFF(day, dbs.YONTARIHI, beb.KAPANISTARIHI) as CEVAPKAPANISTARIH " +
"  from BSB_BASVURU basvuru, BSB_BEB beb, BilgiEdinmeSozluk soz " +
"   , BSB_DBS dbs " +
" where basvuru.BASVURUID = beb.BASVURUID   and soz.id = basvuru.KONU " +
"  and dbs.BEBID = beb.BEBID " +
"  And(select count(*) as YonlendirilenBirimSayisi from BSB_DBS dbs where beb.BEBID = dbs.BEBID) = 1 " +

"  and dbs.YONBIRIM =  '" + brm + "' " +
"   and basvuru.TARIH >= '" + (DateTime.Parse(tarih1)).ToString("MM.dd.yyyy") + " 00:00:00.000" + "' AND basvuru.TARIH <= '" + (DateTime.Parse(tarih2)).ToString("MM.dd.yyyy") + " 23:59:59.000" + "' " +
"  and(dbo.getDiffDateWithRestDay(basvuru.LOGISLEMTARIH, beb.KAPANISTARIHI) >= CASE beb.BASVURUTIPI  when  'BTIP02' then  15 END   or  DATEDIFF(day, basvuru.LOGISLEMTARIH, beb.KAPANISTARIHI) >= CASE beb.BASVURUTIPI  when 'BTIP01' then 30 END  or DATEDIFF(day, basvuru.LOGISLEMTARIH, beb.KAPANISTARIHI) >= CASE beb.BASVURUTIPI  when 'BTIP03' then 30 END   or DATEDIFF(day, basvuru.LOGISLEMTARIH, beb.KAPANISTARIHI) >= CASE beb.BASVURUTIPI when 'BTIP04' then 30 END)";

            liste = db.Database.SqlQuery<T>(strsuresigecen).ToList();
            return liste;

        }
        public List<T> KIDOrtalamaSureHesaplama(string tarihler)
        {
            string[] tarih = tarihler.Split('-');
            string tarih1 = tarih[0];
            string tarih2 = tarih[1];
            List<T> liste = null;
            string kidortsure = "";

            kidortsure = "select (select explanation from Sozluk where id = beb.BASVURUTIPI) as BasvuruTipi, " +
                             " CONVERT(INT, (SUM(dbo.getDiffDateWithRestDay(bas.LOGISLEMTARIH, bas.TARIH))) / (COUNT(beb.BASVURUTIPI))) as CimerUygulamaOrtSure, " +
                             " CONVERT(INT, (SUM(dbo.getDiffDateWithRestDay([dbo].[findIlkBirimeYonlendirilmeTarihi](beb.BEBID), bas.TARIH))) / (COUNT(beb.BASVURUTIPI))) as UygulamaBirimYonOrtSure, " +
                             " CONVERT(INT, (SUM(dbo.getDiffDateWithRestDay([dbo].[findSonBirimCevapTarihi](beb.BEBID), beb.KAPANISTARIHI))) / (COUNT(beb.BASVURUTIPI))) as BirimCevBasCevOrtSure, " +
                             " CONVERT(INT, (SUM(dbo.getDiffDateWithRestDay(bas.TARIH, beb.KAPANISTARIHI))) / (COUNT(beb.BASVURUTIPI))) as BasCevBasKapOrtSure " +
                             " from BSB_BASVURU bas left " +
                             " join BSB_BEB beb on bas.BASVURUID = beb.BASVURUID " +
                             " where bas.TARIH >= '" + (DateTime.Parse(tarih1)).ToString("MM.dd.yyyy") + " 00:00:00.000" + "' AND bas.TARIH <= '" + (DateTime.Parse(tarih2)).ToString("MM.dd.yyyy") + " 23:59:59.000" + "' and beb.BASVURUTIPI != 'BTIP00' " +
                             " group by beb.BASVURUTIPI ";
            liste = db.Database.SqlQuery<T>(kidortsure).ToList();
            return liste;

        }

        public List<T> BEBGenelRaporHesaplama(string tarihler)
        {
            string[] tarih = tarihler.Split('-');
            string tarih1 = tarih[0];
            string tarih2 = tarih[1];
            List<T> liste = null;
            string bebgenelrapor = "";

            bebgenelrapor = "select bas.BASVURUID as BasvuruNo, " +
                            "bas.ADSOYAD as Basvuran," +
                            "konuSozluk.aciklama as BasvuruKonusu," +
                            "sozluk.explanation as BasvuruTipi ," +
                            "bas.LOGISLEMTARIH as CimereBasvuruTarihi, " +
                            "bas.TARIH as SPKyaIletimTarihi, " +
                            "dbs.YONTARIHI as DaireyeSevkTarihi," +
                            "daire.explanation as SevkEdilenDaire,  " +
                            "gorevli.ADSOYAD as SevkEdilenUzman, " +
                            "gorevli.ISLEMTARIHI as UzmaninDaireyeGonderdiğiTarih," +
                            "dbs.BASVURUCEVAPTARIHI as DaireninCevapladigiTarih, " +
                            "beb.KAPANISTARIHI as KidKapatmaTarihi " +
                            "from BSB_BASVURU bas left join BSB_BEB beb on bas.BASVURUID = beb.BASVURUID " +
                            "left join BSB_DBS dbs on beb.BEBID = dbs.BEBID " +
                            "left join BSB_DBS_GOREVLI gorevli on dbs.DBSID = gorevli.DBSID " +
                            "left join BilgiEdinmeSozluk konuSozluk on konuSozluk.id = bas.KONU " +
                            "left join Sozluk sozluk on sozluk.id = beb.BASVURUTIPI " +
                            "left join Sozluk daire on daire.id = dbs.YONBIRIM " +
                             "where bas.TARIH >= '" + (DateTime.Parse(tarih1)).ToString("MM.dd.yyyy") + " 00:00:00.000" + "' AND bas.TARIH <= '" + (DateTime.Parse(tarih2)).ToString("MM.dd.yyyy") + " 23:59:59.000' " +
                             "order by bas.LOGISLEMTARIH desc";

            liste = db.Database.SqlQuery<T>(bebgenelrapor).ToList();
            return liste;

        }

        public List<YapilanIslerRapor> GetYapilanIslerFromProc()
        {
            var query = "Exec KidPerformansSP";

            object[] parameters = new object[] { };

            var response = db.Database.SqlQuery<YapilanIslerRapor>(query, parameters).ToList();

            return response;
            //public string BirimKapatma(int dbsid)
            //{

            //}

        }
    }
}