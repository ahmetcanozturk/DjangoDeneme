﻿using Beb.Models;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;

namespace Beb.Interfaces
{
   public interface IRepository<T> where T : class
    {
         int Insert(T obj);
         T InsertObj(T obj);

        int Update(T obj);
         List<T> List();
        T Find(Expression<Func<T, bool>> where);
        List<T> List(Expression<Func<T, bool>> where);

        IQueryable<T> Queryable();
        int Delete(T entity);
        int DeleteRange(ICollection<T> entities);
        IList<TType> Get<TType>(Expression<Func<T, bool>> where, Expression<Func<T, TType>> select) where TType : class;
        List<T> GecikmeRaporList(string basvuruTip, string birim, string tarihler);
        List<T> PerfKaynakDagilimi(string tarihler);
        List<T> PerfBirimBazliDagilim(string tarihler);
        List<T> PerfBEIslemlerinSonuclari(string tarihler);
        List<T> PerfBEKonuDagilimi(string tarihler);
        List<T> PerfSGOKonuDagilimi(string tarihler);
        List<T> BirimSureHesaplama(string brm, string tur, string tarihler);

        T KurulGenelHesaplama(string brm, string tur, string tarihler);
        List<T> IadeHesaplama(string tur, string tarihler);
        List<T> SuresiGecenBasvurularHesaplama(string tarihler);
        List<T>  BirimBazindaSuresiGecenBasvurularHesaplama(string brm, string tarihler);
        List<T> KIDOrtalamaSureHesaplama(string tarihler);
        List<T> BEBGenelRaporHesaplama(string tarihler);

        BEBDb GetContext();
        decimal MaxDeger(Expression<Func<T, decimal>> where);

        string kalanZaman(string tur, string sql);
        int Save();

    }
}
