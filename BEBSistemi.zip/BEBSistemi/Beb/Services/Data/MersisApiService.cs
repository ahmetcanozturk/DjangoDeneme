﻿using Beb.IServices;
using Beb.Models;
using Beb.Utilities;
using Beb.ViewModels.TuzelKisi;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Web;

namespace Beb.Services
{
    public class MersisApiService
    {
        private readonly string _baseUrl;

        private static object _myLock = new object();
        private static MersisApiService _mySingleton = null;

        private MersisApiService()
        {
            _baseUrl = ConfigurationManager.AppSettings["baseUrl"];
        }

        public static MersisApiService Instance
        {
            get
            {
                if (_mySingleton is null)
                {
                    lock (_myLock)
                    {
                        if (_mySingleton is null)
                        {
                            _mySingleton = new MersisApiService();
                        }
                    }
                }

                return _mySingleton;
            }
        }

        public IEnumerable<MersisSirket> AdinaGoreSirketAra(string id)
        {
            try
            {
                var httpClient = new HttpClient();

                httpClient.BaseAddress = new Uri(_baseUrl);
                var response = httpClient.GetAsync($"Mersis/AdinaGoreSirketAra/{id}").Result;
                if (response.IsSuccessStatusCode)
                {
                    string result = response.Content.ReadAsStringAsync().Result;
                    var unvanList = JsonConvert.DeserializeObject<List<MersisSirket>>(result);
                    return unvanList != null ? unvanList : new List<MersisSirket>() { };
                }
            }
            catch(System.Exception e)
            {
                Console.WriteLine(e.ToString());
            }
            return new List<MersisSirket>() { };
        }

        public List<MersisSirket> SirketAdlariBySirketIDListesi(List<Guid> list)
        {

            try
            {
                var httpClient = new HttpClient();

                httpClient.BaseAddress = new Uri(_baseUrl);
                var stringContent = new StringContent(JsonConvert.SerializeObject(list), Encoding.UTF8, "application/json");
                var response = httpClient.PostAsync($"Mersis/SirketAdlariBySirketIDListesi", stringContent).Result;
                if (response.IsSuccessStatusCode)
                {
                    string result = response.Content.ReadAsStringAsync().Result;
                    var unvanList = JsonConvert.DeserializeObject<List<MersisSirket>>(result);
                    return unvanList;
                }

            }
            catch (Exception e)
            {

                //exception handling
            }
            return new List<MersisSirket>();

        }

        public string SirketAdiBySirketID(string id)
        {
            try
            {
                var httpClient = new HttpClient { BaseAddress = new Uri(_baseUrl) };
                var response = httpClient.GetAsync($"Mersis/SirketAdiBySirketID/{id}").Result;
                if (response.IsSuccessStatusCode)
                {
                    return response.Content.ReadAsStringAsync().Result;

                }
            }
            catch (Exception e)
            {
                return "Unvan bulunamadı";
            }

            return "Unvan Bulunamadı";
        }

    }

}