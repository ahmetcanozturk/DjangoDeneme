﻿using Beb.Interfaces;
using Beb.Logger;
using Beb.Models;
using Beb.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web; 


namespace Beb.UOW
{
    public class UnitOfWork : IUnitOfWork
    {
        private readonly Models.BEBDb db=new BEBDb();

        IRepository<Sozluk> sozlukRepo;
        private IRepository<Models.Beb> bebRepo;
        private IRepository<Basvuru> basvuruRepo;
        private IRepository<Dbs> dbsRepo;
        private IRepository<SYN_DomainUsers> userRepo;
        private IRepository<DbsGorevli> dbsgorevliRepo;
        private IRepository<UploadedBasvuruGirisFile> basvurugirisfileRepo;
        private IRepository<UploadedFile> uploadedfileRepo;
        private IRepository<DaireDurum> dairedurumRepo;
        private IRepository<BilgiEdinmeSozluk> bilgiedinmesozlukRepo;
        private IRepository<GecikmeRaporu> gecikmeraporRepo;
        private IRepository<KaynakDagilimi> kaynakDagraporRepo;
        private IRepository<BirimBazliDagilim> BirimBazliDagilimRepo;
        private IRepository<BEIslemlerinSonuclari> BEIslemlerinSonuclariRepo;
        private IRepository<BEKonuDagilimi> BEKonuDagilimiRepo;
        private IRepository<SGOKonuDagilimi> SGOKonuDagilimiRepo;
        private IRepository<BirimSurec> BirimSurecRepo;
        private IRepository<MyLogger> AuditLoggerRepo;
        private IRepository<BEBDb> BEBDbRepo;
        private IRepository<HataLog> HataLogRepo;
        private IRepository<Log> LogRepo;
        private IRepository<KullaniciRol> KullaniciRolRepo;
        private IRepository<IstatistikTarihler> IstatistikTarihlerRepo;
        private IRepository<KurulGenel> KurulGenelIstatistikRepo;
        private IRepository<IadeRapor> IadeRaporRepo;
        private IRepository<SuresiGecenBasvurular> SuresiGecenRaporRepo;
        private IRepository<BirimBazindaSuresiGecenBasvurular> BirimBazindaSuresiGecenRaporRepo;
        private IRepository<KIDOrtSure> KIDOrtSureRaporRepo;
        private IRepository<BEBGenelRapor> BEBGenelRaporRepo;
        private IRepository<YapilanIslerRapor> YapilanIslerRaporRepo;
        private IRepository<Yetkilendirme> YetkilendirmeRepo;

        IRepository<Models.Beb> IUnitOfWork.bebRepo => bebRepo = bebRepo ?? new Repository<Models.Beb>(db);

        IRepository<Basvuru> IUnitOfWork.basvuruRepo => basvuruRepo = basvuruRepo ?? new Repository<Basvuru>(db);

        IRepository<Dbs> IUnitOfWork.dbsRepo => dbsRepo = dbsRepo ?? new Repository<Dbs>(db);

        IRepository<SYN_DomainUsers> IUnitOfWork.userRepo => userRepo = userRepo ?? new Repository<SYN_DomainUsers>(db);

        IRepository<DbsGorevli> IUnitOfWork.dbsgorevliRepo => dbsgorevliRepo = dbsgorevliRepo ?? new Repository<DbsGorevli>(db);

        IRepository<Sozluk> IUnitOfWork.sozlukRepo => sozlukRepo = sozlukRepo ?? new Repository<Sozluk>(db);

        IRepository<UploadedBasvuruGirisFile> IUnitOfWork.basvurugirisfileRepo => basvurugirisfileRepo = basvurugirisfileRepo ?? new Repository<UploadedBasvuruGirisFile>(db);

         IRepository<UploadedFile> IUnitOfWork.uploadedfileRepo => uploadedfileRepo = uploadedfileRepo ?? new Repository<UploadedFile>(db);

         IRepository<DaireDurum> IUnitOfWork.dairedurumRepo => dairedurumRepo = dairedurumRepo ?? new Repository<DaireDurum>(db);

         IRepository<BilgiEdinmeSozluk> IUnitOfWork.bilgiedinmesozlukRepo => bilgiedinmesozlukRepo = bilgiedinmesozlukRepo ?? new Repository<BilgiEdinmeSozluk>(db);

         IRepository<GecikmeRaporu> IUnitOfWork.gecikmeraporRepo => gecikmeraporRepo = gecikmeraporRepo ?? new Repository<GecikmeRaporu>(db);

         IRepository<KaynakDagilimi> IUnitOfWork.kaynakDagraporRepo => kaynakDagraporRepo = kaynakDagraporRepo ?? new Repository<KaynakDagilimi>(db);

         IRepository<BirimBazliDagilim> IUnitOfWork.BirimBazliDagilimRepo => BirimBazliDagilimRepo = BirimBazliDagilimRepo ?? new Repository<BirimBazliDagilim>(db);

         IRepository<BEIslemlerinSonuclari> IUnitOfWork.BEIslemlerinSonuclariRepo => BEIslemlerinSonuclariRepo = BEIslemlerinSonuclariRepo ?? new Repository<BEIslemlerinSonuclari>(db);

        IRepository<BEKonuDagilimi> IUnitOfWork.BEKonuDagilimiRepo => BEKonuDagilimiRepo = BEKonuDagilimiRepo ?? new Repository<BEKonuDagilimi>(db);

        IRepository<SGOKonuDagilimi> IUnitOfWork.SGOKonuDagilimiRepo => SGOKonuDagilimiRepo = SGOKonuDagilimiRepo ?? new Repository<SGOKonuDagilimi>(db);
        IRepository<MyLogger> IUnitOfWork.AuditLoggerRepo => AuditLoggerRepo = AuditLoggerRepo ?? new Repository<MyLogger>(db);

         IRepository<BEBDb> IUnitOfWork.BEBDbRepo => BEBDbRepo = BEBDbRepo ?? new Repository<BEBDb>(db);

        IRepository<HataLog> IUnitOfWork.HataLogRepo => HataLogRepo = HataLogRepo ?? new Repository<HataLog>(db);

        IRepository<Log> IUnitOfWork.LogRepo => LogRepo = LogRepo ?? new Repository<Log>(db);
        IRepository<KullaniciRol> IUnitOfWork.KullaniciRolRepo => KullaniciRolRepo = KullaniciRolRepo ?? new Repository<KullaniciRol>(db);
        IRepository<BirimSurec> IUnitOfWork.BirimSurecRepo => BirimSurecRepo = BirimSurecRepo ?? new Repository<BirimSurec>(db);

        IRepository<IstatistikTarihler> IUnitOfWork.IstatistikTarihlerRepo => IstatistikTarihlerRepo = IstatistikTarihlerRepo ?? new Repository<IstatistikTarihler>(db);

        IRepository<KurulGenel> IUnitOfWork.KurulGenelIstatistikRepo => KurulGenelIstatistikRepo = KurulGenelIstatistikRepo ?? new Repository<KurulGenel>(db);
        IRepository<IadeRapor> IUnitOfWork.IadeRaporRepo => IadeRaporRepo = IadeRaporRepo ?? new Repository<IadeRapor>(db);
        IRepository<SuresiGecenBasvurular> IUnitOfWork.SuresiGecenRaporRepo => SuresiGecenRaporRepo = SuresiGecenRaporRepo ?? new Repository<SuresiGecenBasvurular>(db);
        IRepository<BirimBazindaSuresiGecenBasvurular> IUnitOfWork.BirimBazindaSuresiGecenRaporRepo => BirimBazindaSuresiGecenRaporRepo = BirimBazindaSuresiGecenRaporRepo ?? new Repository<BirimBazindaSuresiGecenBasvurular>(db);
        IRepository<KIDOrtSure> IUnitOfWork.KIDOrtSureRaporRepo => KIDOrtSureRaporRepo = KIDOrtSureRaporRepo ?? new Repository<KIDOrtSure>(db);
        IRepository<BEBGenelRapor> IUnitOfWork.BEBGenelRaporRepo => BEBGenelRaporRepo = BEBGenelRaporRepo ?? new Repository<BEBGenelRapor>(db);
        IRepository<YapilanIslerRapor> IUnitOfWork.YapilanIslerRaporRepo => YapilanIslerRaporRepo = YapilanIslerRaporRepo ?? new Repository<YapilanIslerRapor>(db);
        IRepository<Yetkilendirme> IUnitOfWork.YetkilendirmeRepo => YetkilendirmeRepo = YetkilendirmeRepo ?? new Repository<Yetkilendirme>(db);


        public IRepository<T> GetRepository<T>() where T : class
        {
            return new Repository<T>(db);
        } 

        public int SaveChanges()
        {
            try
            {
                // Transaction işlemleri burada ele alınabilir veya Identity Map kurumsal tasarım kalıbı kullanılarak
                // sadece değişen alanları güncellemeyide sağlayabiliriz.
                return db.SaveChanges();
            }
            catch
            {
                // Burada DbEntityValidationException hatalarını handle edebiliriz.
                throw;
            }
        } 

        private bool disposed = false;

      
        public void Dispose(bool disposing)
        {
            if (!this.disposed)
            {
                if (disposing)
                {
                    db.Dispose();
                }
            }

            this.disposed = true;
        }
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

       

       
    }
}