﻿using Beb.Interfaces;
using Beb.Logger;
using Beb.Models;
using Beb.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Beb.UOW
{
    public interface IUnitOfWork : IDisposable
    {
         IRepository<Sozluk> sozlukRepo { get; }
         IRepository<Models.Beb> bebRepo { get; }
        IRepository<Models.BEBDb> BEBDbRepo { get; }
        IRepository<Basvuru> basvuruRepo { get; }
        IRepository<Dbs> dbsRepo { get; }
        IRepository<SYN_DomainUsers> userRepo { get; }
        IRepository<KullaniciRol> KullaniciRolRepo { get; }
        IRepository<DbsGorevli> dbsgorevliRepo { get; }
        IRepository<UploadedBasvuruGirisFile> basvurugirisfileRepo { get; }
        IRepository<UploadedFile> uploadedfileRepo { get; }
        IRepository<DaireDurum> dairedurumRepo { get; }
        IRepository<BilgiEdinmeSozluk> bilgiedinmesozlukRepo { get; }
        IRepository<GecikmeRaporu> gecikmeraporRepo { get; }
        IRepository<KaynakDagilimi> kaynakDagraporRepo { get; }
        IRepository<BirimBazliDagilim> BirimBazliDagilimRepo { get; }
        IRepository<BEIslemlerinSonuclari> BEIslemlerinSonuclariRepo { get; }
        IRepository<BEKonuDagilimi> BEKonuDagilimiRepo { get; }
        IRepository<SGOKonuDagilimi> SGOKonuDagilimiRepo { get; }
        IRepository<BirimSurec> BirimSurecRepo { get; }
        IRepository<IstatistikTarihler> IstatistikTarihlerRepo { get; }
        IRepository<KurulGenel> KurulGenelIstatistikRepo { get; } 
        IRepository<IadeRapor> IadeRaporRepo { get; }
        IRepository<SuresiGecenBasvurular> SuresiGecenRaporRepo { get; }
        IRepository<BirimBazindaSuresiGecenBasvurular> BirimBazindaSuresiGecenRaporRepo { get; }
        IRepository<KIDOrtSure> KIDOrtSureRaporRepo { get; }
        IRepository<BEBGenelRapor> BEBGenelRaporRepo { get; }
        IRepository<YapilanIslerRapor> YapilanIslerRaporRepo { get; }
        IRepository<MyLogger> AuditLoggerRepo { get; }
        IRepository<Log> LogRepo { get; }
        IRepository<HataLog> HataLogRepo { get; }
        IRepository<Yetkilendirme> YetkilendirmeRepo { get; }
        IRepository<T> GetRepository<T>() where T : class;
        int SaveChanges();
    }
}
