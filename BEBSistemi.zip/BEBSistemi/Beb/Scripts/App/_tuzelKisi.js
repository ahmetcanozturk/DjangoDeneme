﻿function onloadFunctionTuzelKisi() {
    if ($("#filterTuzelKisi").val() != null) {
        var item = $("#filterTuzelKisi");
        doFilterTuzelKisi(item);
    }
    enableDisableTuzelKisi();

    /* modal popup methods */
    $("#modalSelectTuzelKisi").on("show.bs.modal", function () {
        setTimeout(function () { $("#filterTuzelKisi").focus(); }, 300);
    });
    $('#modalSelectTuzelKisi').on('click', '#btnSelectTuzelKisi', function () {
        selectSirket();
    });
    $('#listSirket').dblclick(function () {
        selectSirket();
        $("#modalSelectTuzelKisi").modal("toggle");
    });
    function selectSirket() {
        if ($("#listSirket").val() != "") {
            $("#lblSirket").text($("#listSirket").find("option:selected").text());
            var selectedVal = $("#listSirket").val();
            $("#SirketID").val(selectedVal);
            $("#SirId").val(selectedVal);
        }
    }

    /* filter methods */
    $('#filterTuzelKisi').keyup(function () {
        $(this).val($(this).val().replace('i', 'İ').toUpperCase());
        doFilterTuzelKisi(this);
        enableDisableTuzelKisi();
    });

    function doFilterTuzelKisi(item) {
        var valFilter = $(item).val();
        var valFilter2 = null;
        if ($(item).val().length > 2) {
            valFilter2 = $(item).val();
            doSearchTuzelKisi(valFilter2, true); //contains
        }
    }

    function doSearchTuzelKisi(searchText, searchCriteria) {
        var url = appEKN.Urls.baseUrl + "TuzelKisi/_AdinaGoreSirketAra";

        var model = { id: searchText, contains: searchCriteria };

        $.ajax({
            type: 'GET',
            url: url,
            contentType: "application/json; charset=utf-8",
            dataType: "json",
            data: model,
            beforeSend: function () { },
            success: function (result) {
                if (result != null) {
                    $("#listSirket").empty();
                    $.each(result, function (key, val) {
                        $("#listSirket").append("<option value='" + key + "'>" + val + "</option>");
                    });
                }
            },
            error: function (xhr) {
                //"Hata Oluştu"
            }
        });
    }

    // disable if length is less than 2
    function enableDisableTuzelKisi() {
        if ($("#filterTuzelKisi").val().length < 2)
            $("#listSirket").empty();
    }
}

$(document).ready(function () {
    onloadFunctionTuzelKisi();
});