﻿function onloadFunction() {
    if ($("#filterTuzelKisi").val() !== null) {
        var item = $("#filterTuzelKisi");
        doFilter(item);
    }
    enableDisable();

    /* filter methods */
    $('#filterTuzelKisi').keyup(function () {
        $(this).val($(this).val().replace('i', 'İ').toUpperCase());
        doFilter(this);
        enableDisable();
    });

    $('#filterFindMersisNo').keyup(function () {
        $(this).val($(this).val().replace('i', 'İ').toUpperCase());
    });

    function doFilter(item) {
        var valFilter = null;
        if ($(item).val().length > 1) {
            valFilter = $(item).val();
            doSearchTuzelKisi(valFilter, true); //use contains
        }
    }

    function doSearchTuzelKisi(searchText, searchCriteria) {
        var url = appEKN.Urls.baseUrl + "TuzelKisi/_AdinaGoreSirketAra";

        var model = { id: searchText, contains: searchCriteria };

        $.ajax({
            type: 'GET',
            url: url,
            contentType: "application/json; charset=utf-8",
            dataType: "json",
            data: model,
            beforeSend: function () { },
            success: function (result) {
                if (result != null) {
                    $("#listSirket").empty();
                    $.each(result, function (key, val) {
                        $("#listSirket").append("<option value='" + key + "'>" + val + "</option>");
                    });
                }
                else {
                    $("#lblMessageTuzelKisi").text("Kayıt bulunmuyor").show().fadeOut(10000);
                    $("#lblMessageTuzelKisi").addClass("alert-warning").removeClass("alert-danger");
                }
            },
            error: function (xhr) {
                $("#lblMessageTuzelKisi").text("Hata Oluştu").show().fadeOut(10000);
                $("#lblMessageTuzelKisi").addClass("alert-danger").removeClass("alert-warning");
            }
        });
    }

    // disable if length is less than 2
    function enableDisable() {
        if ($("#filterTuzelKisi").val().length < 2)
            $("#listSirket").empty();
    }
}

$(document).ready(function () {
    onloadFunction();
});