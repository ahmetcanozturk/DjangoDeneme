﻿using Beb.Interfaces;
using Beb.Logger;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Data.Entity.Validation;
using System.Diagnostics;
using System.Linq;
using System.Web;
using static Beb.Logger.MyLogger;

namespace Beb.Models
{
    public class BEBDb : DbContext
    {
        public BEBDb() : base("name=BEBDb") {  }
        public DbSet<Basvuru> Basvuru { get; set; }
        public DbSet<Beb> Beb { get; set; }
        public DbSet<Sozluk> Sozluk { get; set; }
        public DbSet<BilgiEdinmeSozluk> BilgiEdinmeSozluk { get; set; }
        public DbSet<Dbs> Dbs { get; set; }
        public DbSet<DbsGorevli> DbsGorevli { get; set; }
        public DbSet<DaireDurum> DaireDurum { get; set; }
        public DbSet<UploadedBasvuruGirisFile> UploadedBasvuruGirisFile { get; set; } 
        public DbSet<UploadedFile> UploadedFile { get; set; }
        public DbSet<KullaniciRol> KullaniciRol { get; set; }
        public DbSet<Rol> Rol { get; set; }
        public DbSet<ResmiTatil> ResmiTatil { get; set; }
        public DbSet<Log> Log { get; set; }
        public DbSet<SYN_DomainUsers> SYN_DomainUsers { get; set; }
        public DbSet<Audit> Audit { get; set; }
        public DbSet<HataLog> HataLog { get; set; }
        public DbSet<YapilanIslerRapor> YapilanIslerRapor { get; set; }
        //public DbSet<YapilanIslerRaporDetails> YapilanIslerRaporDetails { get; set; }
        private List<Audit> auditList = new List<Audit>();
        private List<DbEntityEntry> list = new List<DbEntityEntry>();
        private ILogger auditFactory;
        public override int SaveChanges()
        {
            auditList.Clear();
            list.Clear();
            auditFactory = new MyLogger(this);
            var entityList =
                ChangeTracker.Entries()
                    .Where(
                        p =>
                            p.State == EntityState.Added || p.State == EntityState.Deleted ||
                            p.State == EntityState.Modified);
            foreach (var entity in entityList)
            {
                var audit = auditFactory.GetAudit(entity);
                auditList.Add(audit);
                list.Add(entity);
            }

            var retVal = 0;
            try
            {
                retVal = base.SaveChanges();
            }
            catch (DbEntityValidationException e)
            {
                foreach (var eve in e.EntityValidationErrors)
                {
                    Debug.Write(string.Format("Entity türü \"{0}\" şu hatalara sahip \"{1}\" Geçerlilik hataları:",
                        eve.Entry.Entity.GetType().Name, eve.Entry.State));
                    foreach (var ve in eve.ValidationErrors)
                    {
                        Debug.Write(string.Format("- Özellik: \"{0}\", Hata: \"{1}\"", ve.PropertyName, ve.ErrorMessage));
                    }
                }
            }

            if (auditList.Count > 0)
            {
                var i = 0;
                foreach (Audit audit in auditList)
                {
                    if (audit.Actions == AuditActions.I.ToString())
                        audit.TableIdValue = auditFactory.GetKeyValue(list[i] as DbEntityEntry);
                    this.Audit.Add(audit);
                    i++;
                }
                base.SaveChanges();
            }

            return retVal;
        }

    }
}