﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Beb.Models
{
  
    public class Rapor
    {
        public IList<StandartRapor> standartRaporu { get; set; }
        public IList<GecikmeRaporu> gecikmeRaporu { get; set; }
        public IList<KaynakDagilimi> kaynakDagilim { get; set; }
        public IList<BirimBazliDagilim> BirimBazliDagilim { get; set; }
        public IList<BEIslemlerinSonuclari> BEIslemlerinSonuclari { get; set; }
        public IList<BEKonuDagilimi> BEKonuDagilimi { get; set; }
        public IList<SGOKonuDagilimi> SGOKonuDagilimi { get; set; }
        public IList<BirimSurec> BirimSurec { get; set; }
        public IList<KurulGenel> KurulGenel { get; set; }
        public IList<SuresiGecenBasvurular> SuresiGecenBasvurular { get; set; }
        public IList<BirimBazindaSuresiGecenBasvurular> BirimBazindaSuresiGecenBasvurular { get; set; }
        public IList<KIDOrtSure> KIDOrtSure { get; set; }
        public IList<BEBGenelRapor> BEBGenelRapor { get; set; }

        
        public ToplamIadeRapor ToplamIadeRapor { get; set; }
        public List<YapilanIslerRapor> YapilanIslerRapor { get; set; }
        public List<YapilanIslerRaporDetails> YapilanIslerRaporDetails { get; set; }
        public string yapilanislerreservationStart { get; set; } = DateTime.Now.ToShortDateString();
        public string yapilanislerreservationEnd { get; set; } = DateTime.Now.ToShortDateString();

        public int Raporlama { get; set; }

        public IList<SelectListItem> RaporTuruList { get; set; }
        
        public string bebgenelraporreservationStart { get; set; } = DateTime.Now.ToShortDateString();
        public string bebgenelraporreservationEnd { get; set; } = DateTime.Now.ToShortDateString();

        public string kidortsurereservationStart { get; set; } = DateTime.Now.ToShortDateString();
        public string kidortsurereservationEnd { get; set; } = DateTime.Now.ToShortDateString();

        public string birimbazlisuresigecenbasreservationStart { get; set; } = DateTime.Now.ToShortDateString();
        public string birimbazlisuresigecenbasreservationEnd { get; set; } = DateTime.Now.ToShortDateString();

        public string suresigecenbasreservationStart { get; set; } = DateTime.Now.ToShortDateString();
        public string suresigecenbasreservationEnd { get; set; } = DateTime.Now.ToShortDateString();

        public string iadereservationStart { get; set; } = DateTime.Now.ToShortDateString();
        public string iadereservationEnd { get; set; } = DateTime.Now.ToShortDateString();

        public string kurulgenelreservationStart { get; set; } = DateTime.Now.ToShortDateString();
        public string kurulgenelreservationEnd { get; set; } = DateTime.Now.ToShortDateString();

        public string birimsurecreservationStart { get; set; } = DateTime.Now.ToShortDateString();
        public string birimsurecreservationEnd { get; set; } = DateTime.Now.ToShortDateString();

        public string perfreservationStart { get; set; } = DateTime.Now.ToShortDateString();
        public string perfreservationEnd { get; set; } = DateTime.Now.ToShortDateString();

        public string reservationStart { get; set; } = DateTime.Now.ToShortDateString();
        public string reservationEnd { get; set; } = DateTime.Now.ToShortDateString();

        public string BasvuruTipi { get; set; }
    }

    public class StandartRapor
    {
        public string ADSOYAD { get; set; }
        public string KONU { get; set; }
        public string TUR { get; set; }
        public string TIPI { get; set; }
        public string YONBIRIM { get; set; }
        public string DURUM { get; set; }
        public string BASVURU_TARIHI { get; set; }
        public string KAPANISTARIHI { get; set; }
        public string BASVURUSONUC { get; set; }
      
    }

    public class GecikmeRaporu
    {
        public string ADSOYAD { get; set; }
        public string KONU { get; set; }
        public DateTime? BASVURU_TARIH { get; set; }
        public string TIPI { get; set; }
        public string YONBIRIM { get; set; }
        public string KAPANISTARIHI { get; set; }
        public string BASVURUCEVAPTARIHI { get; set; }
        public decimal? BASVURUID { get; set; }

    }

    public class KaynakDagilimi
    {
        public string BasvuruTuru { get; set; }
        public int BebSayi { get; set; }
        public int GOSSayi { get; set; }

    }

    public class BirimBazliDagilim
    {
        public string BIRIMADI { get; set; }
        public int? BEBBASVURU { get; set; }
        public decimal? BEBORT { get; set; }
        public int? SGOBASVURU { get; set; }
        public decimal? SGOTARORT { get; set; }
        public int? KYSBASVURU { get; set; }
        public int? SURESIGECEN { get; set; }
        public int TOPLAM { get; set; }

    }
    public class BEIslemlerinSonuclari
    {
        public string Baslik { get; set; }
        public int Deger { get; set; }
        public string sira { get; set; }
   

    }
    public class BEKonuDagilimi
    {
        public string KONUADI { get; set; }
        public int BKONUSAYISI { get; set; }
       
    }
    public class SGOKonuDagilimi
    {
        public string KONUADI { get; set; }
        public int BKONUSAYISI { get; set; }

    }
    public class IstatistikTarihler
    {
        public decimal BasvuruId { get; set; }
        public string YonBirim { get; set; }
        public DateTime? BasvuruTarihi { get; set; }
        public DateTime? LogIslemTarihi { get; set; }
        public DateTime? KapanisTarihi { get; set; }
        public DateTime? YonTarih { get; set; }
        public DateTime? AtanmaTarihi { get; set; }
        public DateTime? IslemTarihi { get; set; }
        public DateTime? BasvuruCevapTarihi { get; set; }

    } 

    public class BirimSurec
    {
        public string BirimAdi { get; set; }
        public int KapaliAdedi { get; set; }
        public int KapaliBirimCevapOrtSuresi { get; set; } 
        //Aşağısı süresi içinde cevap verilmeyenler 
        public int KapaliZamanıGecenAdedi { get; set; }
        public int KapaliBirimUzmanOrtSure { get; set; }
        public int KapaliUzmanCevapOrtSure { get; set; }
        public int KapaliUzmanBirimOrtSure { get; set; }

        public int AcikAdedi { get; set; }
        public int AcikBirimCevapOrtSuresi { get; set; }
        //Aşağısı süresi içinde cevap verilmeyenler 
        public int AcikZamanıGecenAdedi { get; set; }
        public int AcikBirimUzmanOrtSure { get; set; }
        public int AcikUzmanCevapOrtSure { get; set; }
        public int AcikUzmanBirimOrtSure { get; set; }
    }

    public class KurulGenel
    {
        public string BirimAdi { get; set; }
        public int KapaliAdedi { get; set; }
        public int KapaliCimerSureGecenSayi { get; set; }
        public int KapaliCimerBirdenFazlaDaire { get; set; }
        public int KapaliCimerIadeEdilen { get; set; }
        public int KapaliBasTarSureGecenSayi { get; set; }
        public int KapaliBasTarBirdenFazlaDaire { get; set; }
        public int KapaliBasTarIadeEdilen { get; set; }
        // Açık olan basvurular 
        public int AcikAdedi { get; set; }
        public int AcikCimerSureGecenSayi { get; set; }
        public int AcikCimerBirdenFazlaDaire { get; set; }
        public int AcikCimerIadeEdilen { get; set; }
        public int AcikBasTarSureGecenSayi { get; set; }
        public int AcikBasTarBirdenFazlaDaire { get; set; }
        public int AcikBasTarIadeEdilen { get; set; }
    }

    public class IadeRapor
    {
        public string BirimAdi { get; set; }
        public int Sayisi { get; set; }

        public decimal OrtIadeSure { get; set; }
      
    } 
    public class ToplamIadeRapor
    {
        public List<IadeRapor> bebiade { get; set; }
        public List<IadeRapor> sikayetiade { get; set; }
        public List<IadeRapor> digeriade { get; set; }
    }

    public class SuresiGecenBasvurular
    {
        public string ADSOYAD { get; set; }
        public string KONU { get; set; }
         public string BASVURUTIPI { get; set; }
        public int? CIMERTARIHINEGOREGUN { get; set; }
        public int? BASVURUTARIHINEGOREGUN { get; set; }
        public int IADE { get; set; }
        public int BIRDENCOK { get; set; }
        public int CEVAPLAYANBIRIM { get; set; }

    }

    public class BirimBazindaSuresiGecenBasvurular
    {
        public decimal BASVURUID { get; set; }
        
        public string ADSOYAD { get; set; }
        public string BASVURUTIPI { get; set; }
        public string KONU { get; set; }
        public DateTime?  cimertarihi { get; set; }
        public DateTime? uygulamayagirentarih { get; set; }
        public int? CIMERUYGULAMATARIH { get; set; }
        public DateTime? YONTARIHI { get; set; }
        public int? UYGULAMAYONTARIH { get; set; }
        public int? CEVAPLAYANBIRIM { get; set; }
        public DateTime? BASVURUCEVAPTARIHI { get; set; }
        public int? YONCEVAPTARIH { get; set; }
        public DateTime? KAPANISTARIHI { get; set; } 

        public int? CEVAPKAPANISTARIH { get; set; }
    }

    public class KIDOrtSure
    {
      
        public string BasvuruTipi { get; set; }
      
        public int? CimerUygulamaOrtSure { get; set; }
        public int? UygulamaBirimYonOrtSure { get; set; }
        public int? BirimCevBasCevOrtSure { get; set; }
        public int? BasCevBasKapOrtSure { get; set; }
       
    }

    public class BEBGenelRapor
    {

        public decimal? BasvuruNo { get; set; }
        public string Basvuran { get; set; }
        public string BasvuruKonusu { get; set; }
        public string BasvuruTipi { get; set; }
        public DateTime? CimereBasvuruTarihi { get; set; }
        public DateTime? SPKyaIletimTarihi { get; set; }
        public DateTime? DaireyeSevkTarihi { get; set; }
        public string SevkEdilenDaire { get; set; }
        public string SevkEdilenUzman { get; set; }
        public DateTime? UzmaninDaireyeGonderdigiTarih { get; set; }
        public DateTime? DaireninCevapladigiTarih { get; set; }
        public DateTime? KidKapatmaTarihi { get; set; }

    }
}