﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Web;

namespace Beb.Models
{
    public class Yetkilendirme
    {
        public string tckimlikno { get; set; }
        public string sicilno { get; set; }
        public string adsoyad { get; set; }
        public string daire { get; set; }
        public string unvan { get; set; }
        public string username { get; set; }
        public string rol { get; set; }
        [Required(ErrorMessage = "Bu alan zorunludur")]
        public long rolId { get; set; }
    }
}