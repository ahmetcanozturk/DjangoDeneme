﻿
using System.ComponentModel.DataAnnotations.Schema;


namespace Beb.Models
{


    [Table("BSB_UPLOADEDFILE")]
    public class UploadedFile :AbstractFileUpload
    {
        public static UploadedFile Instance = new UploadedFile();
        public UploadedFile() { }

        //public override UploadedFile GetObj()
        //{
        //    return new UploadedFile();
        //}
       
    }
}