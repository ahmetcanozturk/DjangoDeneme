﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Web;

namespace Beb.Models
{
    [Table("BilgiEdinmeSozluk")]
    public class BilgiEdinmeSozluk
    {
        [Key]
        //[DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public string id { get; set; }
        public string aciklama { get; set; }

        //   public virtual ICollection<Basvuru> Basvuru { get; set; }

    }
}