﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Beb.Models
{

    public class mailJob
    {
        //Basvuru basvuru { get; set; } 
        //Dbs dbs { get; set; }
        public string TCKIMLIK { get; set; }
        public string ADSOYAD { get; set; }
        public string TEL { get; set; }
        public string EMAIL { get; set; }
        public string YONEPOSTA { get; set; }
        public string KONU { get; set; }
        public string ADRES { get; set; }
        public string IL { get; set; }
        public string BASVURUICERIK { get; set; }
        public string BASVURUCEVAP { get; set; }
        public string ACIKLAMA { get; set; }
        public DateTime TARIH { get; set; }
        public decimal DBSID { get; set; }

}
}