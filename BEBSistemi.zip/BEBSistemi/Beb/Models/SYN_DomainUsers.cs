﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Beb.Models
{
    [Table("SYN_DomainUsers")]
    public class SYN_DomainUsers
    {

        [Key]
        public string sicilno { get; set; }
        public string tckimlikno { get; set; }
        public string username { get; set; }
        public string cn { get; set; }
        public string adsoyad { get; set; }
        public string ad { get; set; }
        public string soyad { get; set; }
        public string sehir { get; set; }
        public string dahilitelefon { get; set; }
        public string evtelefon { get; set; }
        public string mobiltelefon { get; set; }
        public string unvan { get; set; }
        public string birim { get; set; }
        public string daire { get; set; }
        public string homedirectory { get; set; }
        public string mailnick { get; set; }
        public string mail { get; set; }
        public bool userstatus { get; set; }

    }
}