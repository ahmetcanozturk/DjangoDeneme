﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Web;

namespace Beb.Models
{
    //public abstract class AbstractFileUpload<T> where T: AbstractFileUpload<T> 
    public class AbstractFileUpload 
    {
        [Key]
        //[DatabaseGenerated(DatabaseGeneratedOption.Identity)]
         public int id { get; set; }
        public string filename { get; set; }
        public string filetype { get; set; }
        public byte[] filecontent { get; set; }
        [ForeignKey("Basvuru")]
        public decimal? basvuruid { get; set; }
        //public int? kosul { get; set; }


         public virtual Basvuru Basvuru { get; set; }

        //public abstract T GetObj();



      
    }
}