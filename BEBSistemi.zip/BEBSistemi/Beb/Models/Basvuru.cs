﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Beb.Models
{
    [Table("BSB_BASVURU")]
    public class Basvuru
    {
        [Key]
        //[DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public decimal BASVURUID { get; set; }
        [Required(ErrorMessage = "Ad Soyad boş geçilemez.")]
        public string ADSOYAD { get; set; }
        public string ADRES { get; set; }
        [Required(ErrorMessage = "T.C. boş geçilemez.")]
        public string TCKIMLIK { get; set; }
        public string TUZELKISILIK { get; set; }
        [ForeignKey("IlSozluk")]
        public string IL { get; set; }

        public string TEL { get; set; }
        public string FAX { get; set; }
        [Required(ErrorMessage = "E-mail boş geçilemez.")]
        public string EMAIL { get; set; }

        [ForeignKey("KonuSozluk")]
        [Required(ErrorMessage = "Konu boş geçilemez.")]
        public string KONU { get; set; } 

        [ForeignKey("AltKonuSozluk")]
        public string ALTKONU { get; set; } 

        [ForeignKey("AltAltKonuSozluk")]
        public string ALTALTKONU { get; set; }

        [DataType(DataType.Date)]
        [Required(ErrorMessage = "Tarih boş geçilemez.")]
        //[DisplayFormat(DataFormatString = "{0:dd.MM.yyyy}", ApplyFormatInEditMode = true)]
        public DateTime TARIH { get; set; }

       
        public int BASVURUCEVAP { get; set; }
        [AllowHtml]
        [Required(ErrorMessage = "Basvuru içerik boş geçilemez.")]
        public string BASVURUICERIK { get; set; }
        public bool? YATIRIMCIGOSTER { get; set; }
        public string EMAILDUZELTILMIS { get; set; }
        public string EMAILIDUZELTEN { get; set; }
        public DateTime? EMAILDUZELTMETAR { get; set; }
        public string ADSOYADDUZELTILMEDENONCEKI { get; set; }
        public string ADSOYADDUZELTEN { get; set; }
        public DateTime? ADSOYADDUZELTILMETARIH { get; set; }
      
        [Required(ErrorMessage = "Cimer Tarihi boş geçilemez.")]
        public DateTime? LOGISLEMTARIH { get; set; }
        public string LOGKULLANICI { get; set; }
        public DateTime? BEBKAYITTARIHI { get; set; }
        public string CIMERBASVURUNO { get; set; }
        public string SIRKETID { get; set; } //SUNAY

        public virtual IList<Beb> BebListesi { get; set; }

        public virtual BilgiEdinmeSozluk KonuSozluk { get; set; }
        public virtual BilgiEdinmeSozluk AltKonuSozluk { get; set; } 
        public virtual BilgiEdinmeSozluk AltAltKonuSozluk { get; set; }
        public virtual Sozluk IlSozluk { get; set; }
        public virtual IList<UploadedBasvuruGirisFile> BasvuruGirisFiles { get; set; }
        public virtual IList<UploadedFile> UploadedFiles { get; set; }

        public IEnumerable<SelectListItem> KonuList { get; set; }

        //public DateTime SonGun => LOGISLEMTARIH == null ? DateTime.MinValue : AddWorkingDays(((DateTime)LOGISLEMTARIH), BebListesi[0].BASVURUTIPI== "BTIP02" ? 15 : 30, Singleton.GetTatilInstance);
        public DateTime SonGun => LOGISLEMTARIH == null ? DateTime.MinValue : (BebListesi[0].BASVURUTIPI == "BTIP02"? AddWorkingDays(((DateTime)LOGISLEMTARIH),  15, Singleton.GetTatilInstance) : ((DateTime)LOGISLEMTARIH).AddDays(30));


        public int KALANGUN => LOGISLEMTARIH==null ? 0 : (BebListesi[0].BASVURUTIPI == "BTIP02" ? GunHesapla(DateTime.Today, (DateTime)SonGun, Singleton.GetTatilInstance) : ((DateTime)SonGun- DateTime.Today).Days);

       
        public DateTime AddWorkingDays(DateTime date, int daysToAdd, List<DateTime> tatil)
        {
        
            while (daysToAdd > 0)
            {
                date = date.AddDays(1);

                if (date.DayOfWeek != DayOfWeek.Saturday && date.DayOfWeek != DayOfWeek.Sunday && !tatil.Contains(date))
                {
                    daysToAdd -= 1;
                }
            }

            return date;
        }

        public int GunHesapla(DateTime basTarih, DateTime bitTarih, List<DateTime> TatilList)
        {
            Func<int, bool> isWorkingDay = days =>
            {
                var currentDate = basTarih.AddDays(days);
                var isNonWorkingDay =
                    currentDate.DayOfWeek == DayOfWeek.Saturday ||
                    currentDate.DayOfWeek == DayOfWeek.Sunday ||
                    TatilList.Exists(excludedDate => excludedDate.Date.Equals(currentDate.Date));
                return !isNonWorkingDay;
            };
            if (DateTime.Compare(bitTarih, basTarih) >0) { 
             return Enumerable.Range(0, (bitTarih - basTarih).Days).Count(isWorkingDay);
            }
            else
            {
             return (Enumerable.Range(0, Math.Abs((bitTarih - basTarih).Days)).Count(isWorkingDay))*(-1);
            }
        }
      
    } 

    public class BasvuruSecenek
    {
       public string BasvuruBilgisi { get; set; }
        public int BasvuruCount { get; set; }
    }
     
}