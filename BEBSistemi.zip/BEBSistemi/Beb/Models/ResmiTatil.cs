﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Web;

namespace Beb.Models
{
    [Table("BSB_RESMI_TATILLER")]
    public class ResmiTatil
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public string RESMITATILID { get; set; }
        public DateTime TARIH { get; set; }
        public string ACIKLAMA { get; set; }
        public string YIL { get; set; }
       
    }
}