﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Web;

namespace Beb.Models
{
    [Table("BSB_DAIREDURUM")]
    public class DaireDurum
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public decimal DAIREDURUMID { get; set; }
        [ForeignKey("Durum")]
        public string DAIREDURUM { get; set; }
        public DateTime KAYITTARIH { get; set; }
        public decimal DBSID { get; set; }

        public string BIRIMKAPATMAMETNI { get; set; }
        public bool? IADE { get; set; }

        public virtual Sozluk Durum { get; set; }
        public virtual Dbs Dbs { get; set; }
    }
}