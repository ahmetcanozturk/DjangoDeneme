﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Web;

namespace Beb.Models
{
  
    public class FiltreTur
    {
        public IList<Basvuru> Basvurular { get; set; }
        public Dictionary<decimal, decimal> basvuruDbs { get; set; }
       
}
 
}