﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Beb.Models
{
    [Table("BSB_DBS")]
    public class Dbs
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public decimal DBSID { get; set; }
        public decimal BEBID { get; set; }
        public DateTime YONTARIHI { get; set; }
        public string YONEPOSTA { get; set; }
        [ForeignKey("YonBirimBilgisi")]
        public string YONBIRIM { get; set; }
        [AllowHtml]
        public string BIRIMKAPATMETIN { get; set; }
        public bool IADE { get; set; }
        public DateTime? BASVURUCEVAPTARIHI { get; set; }
        public string SONDURUM { get; set; }
        public bool? TOPLUCEVAPMI { get; set; }

        public virtual Beb Beb { get; set; }

        public virtual ICollection<DaireDurum> DaireDurumListesi { get; set; }
        public virtual Sozluk YonBirimBilgisi { get; set; } 
        public virtual ICollection<DbsGorevli> DbsGorevListesi { get; set; }


    }  
   
   public class Tag
    {
        public string value { get; set; }
        public string code { get; set; }

    }
}