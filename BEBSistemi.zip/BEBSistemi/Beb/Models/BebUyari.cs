﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Beb.Models
{
    public class BebUyari
    {
        public string Description { get; set; }
        public int Count { get; set; }
        public string Link { get; set; }
        public string DurumSozlukKod { get; set; }
    }
}