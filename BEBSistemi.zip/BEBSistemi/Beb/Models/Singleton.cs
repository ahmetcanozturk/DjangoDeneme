﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Configuration;

namespace Beb.Models
{
    public class Singleton
    {
           private static List<DateTime> TatilInstance;
        //private static SYN_DomainUsers KullaniciBilgileriInstance;
            private Singleton() { }
     
        public static List<DateTime> GetTatilInstance
            {
                get
                {
                    if (TatilInstance == null)
                    {
                    BEBDb db = new BEBDb();
                    TatilInstance = db.ResmiTatil.Select(s => s.TARIH).ToList();
                }
                    return TatilInstance;
                }
            
        }
        public static string GetConfigSetting(string name, string defaultValue)
        {
            var keyValue = WebConfigurationManager.AppSettings[name];

            if (String.IsNullOrWhiteSpace(keyValue))
            {
                return defaultValue;
            }

            return keyValue;
        }


    }
}

