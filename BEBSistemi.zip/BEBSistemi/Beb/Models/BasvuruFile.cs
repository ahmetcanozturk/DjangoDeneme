﻿namespace Beb.Interfaces
{
    public class BasvuruFile
    {
        //[DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int id { get; set; }
        public string filename { get; set; }
        public string filetype { get; set; }
        public byte[] filecontent { get; set; }
        public decimal? basvuruid { get; set; }
        //public int? kosul { get; set; }

        // 0 Basvurufile
        // 1 Uploaded File
        public int Tip { get; set; }
    }
}