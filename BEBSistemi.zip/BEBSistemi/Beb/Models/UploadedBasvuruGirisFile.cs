﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Net;
using System.Net.Security;
using System.Security.Cryptography.X509Certificates;
using System.Web;

namespace Beb.Models
{

    [Table("BSB_UPLOADEDBASVURUGIRISFILE")]
    public class UploadedBasvuruGirisFile : AbstractFileUpload 
    {
        //[Key]
        ////[DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        //public int id { get; set; }
        //public string filename { get; set; }
        //public string filetype { get; set; }
        //public byte[] filecontent { get; set; }
        //[ForeignKey("Basvuru")]
        //public decimal? basvuruid { get; set; }
        //public int? kosul { get; set; }


        //public virtual Basvuru Basvuru { get; set; }
        public static UploadedBasvuruGirisFile Instance = new UploadedBasvuruGirisFile();
        public UploadedBasvuruGirisFile() { }

        //public override UploadedBasvuruGirisFile GetObj()
        //{
        //    return new UploadedBasvuruGirisFile();
        //}
    }

}