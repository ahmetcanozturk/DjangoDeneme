﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Web;

namespace Beb.Models
{
    [Table("BSB_KULLANICIROL")]
    public class KullaniciRol
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public decimal KULLANICIROLID { get; set; }
        public string USERADID { get; set; }
        [ForeignKey("RolBilgisi")]
        public int ROL { get; set; }
        [ForeignKey("BirimSozluk")]
        public string BIRIMID { get; set; }
        //public string KULLANICIAD { get; set; } 

        //public string TCKIMLIK { get; set; }
        public virtual Sozluk BirimSozluk { get; set; }
        public virtual Rol RolBilgisi { get; set; }
    }
}