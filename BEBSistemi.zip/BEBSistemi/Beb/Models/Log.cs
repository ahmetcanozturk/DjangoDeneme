﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Web;

namespace Beb.Models
{
    [Table("BSB_LOG")]
    public class Log
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public decimal LogId { get; set; }
        [DatabaseGenerated(DatabaseGeneratedOption.Computed)]
        public DateTime Tarih { get; set; }
        public string Islem { get; set; }
        public string IslemYapanId { get; set; }
        public string IslemYapan { get; set; }
        [ForeignKey("Basvuru")]
        public decimal? BasvuruId { get; set; }
        [ForeignKey("Dbs")]
        public decimal? DbsId { get; set; }
        [ForeignKey("DbsGorevli")]
        public decimal? DbsGorevliId { get; set; }
        public string Aciklama { get; set; }

        public virtual Basvuru Basvuru { get; set; }
        public virtual Dbs Dbs { get; set; }
        public virtual DbsGorevli DbsGorevli { get; set; }
    }
}