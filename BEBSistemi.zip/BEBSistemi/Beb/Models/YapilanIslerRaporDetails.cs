﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Beb.Models
{
    public class YapilanIslerRaporDetails
    {
        //public IList<CimerGelenTemp> CimerGelenTemp { get; set; }
        //public IList<CimerGidenTemp> CimerGidenTemp { get; set; }
        //public IList<BebGelenTemp> BebGelenTemp { get; set; }
        //public IList<BebGidenTemp> BebGidenTemp { get; set; }
        //public IList<ToplamBebGidenTemp> ToplamBebGidenTemp { get; set; }
        //public IList<ToplamCimerGidenTemp> ToplamCimerGidenTemp { get; set; }
        public decimal ID { get; set; }
        public decimal BASVURUID { get; set; }
        public string TCKIMLIK { get; set; }
        public string ADSOYAD { get; set; }
        public string KONU { get; set; }
        public DateTime? BEBKAYITTARIHI { get; set; }
        public string CIMERBASVURUNO { get; set; }
        public string BASVURUTURU { get; set; }
        public string BASVURUTIPI { get; set; }
        public string DURUM { get; set; }
        public DateTime? TARIH { get; set; }
        public DateTime? KAPANISTARIHI { get; set; }


        public YapilanIslerRaporDetails(){}

    }
    public class CimerGelenTemp
    {
        public decimal ID { get; set; }
        public decimal BASVURUID { get; set; }
        public string TCKIMLIK { get; set; }
        public string ADSOYAD { get; set; }
        public string KONU { get; set; }
        public DateTime BEBKAYITTARIHI { get; set; }
        public string CIMERBASVURUNO { get; set; }
    }
    public class CimerGidenTemp
    {
        public decimal ID { get; set; }
        public decimal BASVURUID { get; set; }
        public string TCKIMLIK { get; set; }
        public string ADSOYAD { get; set; }
        public string BASVURUTURU { get; set; }
        public string BASVURUTIPI { get; set; }
        public string DURUM { get; set; }
        public DateTime TARIH { get; set; }
        public DateTime KAPANISTARIHI { get; set; }
        public string CIMERBASVURUNO { get; set; }
    }
    public class BebGelenTemp
    {
        public decimal ID { get; set; }
        public decimal BASVURUID { get; set; }
        public string TCKIMLIK { get; set; }
        public string ADSOYAD { get; set; }
        public string KONU { get; set; }
        public DateTime BEBKAYITTARIHI { get; set; }
    }
    public class BebGidenTemp
    {
        public decimal ID { get; set; }
        public decimal BASVURUID { get; set; }
        public string TCKIMLIK { get; set; }
        public string ADSOYAD { get; set; }
        public string BASVURUTURU { get; set; }
        public string BASVURUTIPI { get; set; }
        public string DURUM { get; set; }
        public DateTime TARIH { get; set; }
        public DateTime KAPANISTARIHI { get; set; }
    }
    public class ToplamBebGidenTemp
    {
        public decimal ID { get; set; }
        public decimal BASVURUID { get; set; }
        public string TCKIMLIK { get; set; }
        public string ADSOYAD { get; set; }
        public string BASVURUTURU { get; set; }
        public string BASVURUTIPI { get; set; }
        public string DURUM { get; set; }
        public DateTime TARIH { get; set; }
        public DateTime KAPANISTARIHI { get; set; }
    }
    public class ToplamCimerGidenTemp
    {
        public decimal ID { get; set; }
        public decimal BASVURUID { get; set; }
        public string TCKIMLIK { get; set; }
        public string ADSOYAD { get; set; }
        public string BASVURUTURU { get; set; }
        public string BASVURUTIPI { get; set; }
        public string DURUM { get; set; }
        public DateTime TARIH { get; set; }
        public DateTime KAPANISTARIHI { get; set; }
        public string CIMERBASVURUNO { get; set; }
    }

}