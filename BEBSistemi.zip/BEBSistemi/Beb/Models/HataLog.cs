﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Web;

namespace Beb.Models
{
    [Table("HataLog")]
    public class HataLog
    {
        [Key, DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public long ID { get; set; }

        public string RawURL { get; set; }

       public string HataTipi { get; set; }

       public string HataMesaji { get; set; }
       public string StackTrace { get; set; }

        public string OlusturanKullaniciAdi { get; set; }

        public DateTime OlusturmaTarihi { get; set; }


    }
}