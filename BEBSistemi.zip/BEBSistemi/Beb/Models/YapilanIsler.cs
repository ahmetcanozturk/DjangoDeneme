﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Beb.Models
{
    public class YapilanIsler
    {
        public List<Basvuru> listbas { get; set; }
        public List<Beb> listbeb { get; set; }

    }
}