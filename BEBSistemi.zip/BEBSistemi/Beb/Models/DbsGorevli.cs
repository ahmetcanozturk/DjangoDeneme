﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Beb.Models
{
    [Table("BSB_DBS_GOREVLI")]
    public class DbsGorevli
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public decimal DBSGOREVLIID { get; set; }
        public decimal DBSID { get; set; }
        public string KULLANICIADI { get; set; }
        public DateTime ATANMATARIHI { get; set; }
        public DateTime ISLEMTARIHI { get; set; }
        public string ADSOYAD { get; set; } 
        [AllowHtml]
        public string METINONCEKI { get; set; }
        [AllowHtml]
        public string METINSONRAKI { get; set; }
        public string ATAYAN { get; set; }


        public virtual Dbs Dbs{get; set;}

    }
}