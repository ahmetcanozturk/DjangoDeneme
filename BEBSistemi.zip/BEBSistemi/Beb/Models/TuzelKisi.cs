﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Web;

namespace Beb.Models
{
    public partial class TuzelKisi
    {

        #region Properties
        public long Id { get; set; }

        [DisplayName("Unvanı:")]
        [NotMapped]
        public string Unvan { get; set; }


        public Nullable<bool> Aktif { get; set; }

        [DisplayName("Gerekli İmza Sayısı")]
        [Range(1, 5)]
        [Required(ErrorMessage = "İmza sayısı gereklidir.")]
        public int ImzaSayisi { get; set; }

        [DisplayName("İhraççı Tipi")]
        [Required(ErrorMessage = "İhraççı tipi gereklidir")]
        public long IhracciTipiId { get; set; }

        //public virtual IhracciTipi IhracciTipi { get; set; }

        //[Display(Name = "Tüzel Kişi Yetkilileri")]
        //public virtual ICollection<TuzelKisiYetkili> TuzelKisiYetkiliListesi { get; set; }


        [Required(ErrorMessage = "Unvan alanı gerekelidir")]
        public Guid SirketId { get; set; }
        #endregion

        #region Constructer
        public TuzelKisi()
        {
            //TuzelKisiYetkiliListesi = new HashSet<TuzelKisiYetkili>();

        }
        #endregion
    }
}