﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Beb.Models
{
    public class YapilanIslerRapor
    {
        public decimal ID { get; set; }
        public string UserID { get; set; }
        public string AdSoyadi { get; set; }
        public decimal? CimerGidenSayi { get; set; }
        public decimal? CimerGelenSayi { get; set; }
        public decimal? EdevletGelenSayi { get; set; }
        public decimal? EdevletGidenSayi { get; set; }
        public decimal? CimerKidCevapSayisi { get; set; }
        public decimal? EdevletKidCevapSayisi { get; set; }
        
        public YapilanIslerRapor()
        {

        }
    }
}