﻿using System;
using System.Data;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;


namespace Beb.Models
{
    public class OrtakSabitler
    {
        public static string TUZEL_GERCEKKISI_SECINIZ_KOD = "TG";
        public static string TUZELKISILER_KOD = "TG01";
        public static string GERCEKKISILER_KOD = "TG02";
        public static string BASVURU_TIPINI_SECINIZ_KOD = "BTIP00";
        public static string GORUS_ONERI_SIKAYET_KOD = "BTIP01";
        public static string BILGIEDINME_KOD = "BTIP02";
        public static string YATIRIMCI_GORUS_ONERI_SIKAYET_KOD = "BTIP03";
        public static string ISTEK = "BTIP04";
        public static string BASVURU_TURUNU_SECINIZ_KOD = "BTUR00";
        public static string BIMER_KOD = "BTUR01";
        public static string YAZI_KOD = "BTUR02";
        public static string INTERNET_KOD = "BTUR03";
        public static string ACIKTAN_BASVURU_KOD = "BTUR04";
        public static string CIMER_KOD = "BTUR05";
        public static string BASVURU_DURUMU_SECINIZ_KOD = "BDUR00";
        public static string ONAYLANMIS_BASVURU_KOD = "BDUR01";
        public static string YENI_BASVURU_KOD = "BDUR02";
        public static string YONLENDIRILMIS_BASVURU_KOD = "BDUR03";
        public static string DAIREONAY_BASVURU_KOD = "BDUR04";
        public static string KAPATILMIS_BASVURU_KOD = "BDUR05";
        //public static string IADE_EDILMIS_VE_KAPATILMIS_BASVURU_KOD = "BDUR05 DDUR06"; //SUNAY 05-01-22
        //public static string IADE_EDILMIS_BASVURU_KOD = "BDUR06";

        public static string DAIREONAY_KOD = "BDUR04";
        public static string OFD_BRM_KOD = "BRM07";
        public static string KOMBODOLDUR_SQL = "SELECT id, explanation FROM BilgiEdinmeSozluk where id = 'KON010000''";
        public static string TUZELKISI = "tuzel";
        public static string GERCEKKISI = "gercek";
        public static string KONUYU_SECINIZ_KOD = "KON000000";
        public static string ALTKONUYU_SECINIZ_KOD = "SUBKON";
        public static string IL_SECINIZ_KOD = "IL";
        public static string KURULICI_KURULDISI_SECINIZ_KOD = "KRL00";
        public static string KURULICI_KOD = "KRL01";
        public static string KURULDISI_KOD = "KRL02";
        public static string KURULILGISIZ_KOD = "KRL03";
        public static int ILGILI_KOD = 1;
        public static int ILGISIZ_KOD = 0;
        public static int TAMAMENILGISIZ_KOD = 2;
        public static int BEBKAPAT_KOD = 3;
        public static string FORM_KAYDET_SQL = "SELECT id, explanation FROM sozluk where id LIKE '";
        public static short ELEKTRONIK_CEVAP_KOD = 0;
        public static short YAZILI_CEVAP_KOD = 1;
        public static string ASCENDING = " ASC";
        public static string DESCENDING = " DESC";
        public static string RAPORSECINIZ_KOD = "RPR00";
        public static string STANDARTRAPOR_KOD = "RPR01";
        public static string PERFORMANSRAPOR_KOD = "RPR02";
        public static string GECIKMERAPOR_KOD = "RPR03";

        public static string strConnectionString;
        public static string strConnectionStringPublicUSer = "Data Source=SANKDBP00; Initial Catalog=public;  user=webwriter; password=SwDbuser1";
        public static string strRunTimeMode;
        //public static string KULLANICI_DEGISTIR="";
        public static string KULLANICI_DEGISTIR_IMID = "1";
        public static string KULLANICI_DEGISTIR_BIED = "2";
        public static string KULLANICI_DEGISTIR_AD = "3";
        public static string KULLANICI_DEGISTIR_BACKDOOR = "5";

        public static string UZMAN_LINK = "UzmanDetay";
        public static string DBS_LINK = "DBSDetay";

        public static string BACKDOOR_KULLANICI_ADI = "";
        public static string ROLES_BEB = "BEB";
        public static string ROLES_DBS = "DBS";
        public static string ROLES_DENETCI = "DENETCI";
        public static string ROLES_UZMAN = "UZMAN";
        //public static string KULLANICI_DAIRE="";
        //public static string LOGON_USER = "";
        public static string DAIRE_DURUM_DAIREYE_SECINIZ = "DDUR00";
        public static string KULLANIM_KILAVUZU_DAIRE_YETKILI = "http://spkportal/sites/bied/KullanimKilavuzlari/BEB_K%C4%B1lavuz_DaireYetkili.pdf";
        public static string KULLANIM_KILAVUZU_DAIRE_YONLENDIRILEN = "http://spkportal/sites/bied/KullanimKilavuzlari/BEB_K%C4%B1lavuz__DaireY%C3%B6nlendirilenKi%C5%9Fi.pdf";


        public static string DAIRE_DURUM_DAIREYE_YONLENDIRILMIS = "DDUR03";
        public static string DAIRE_DURUM_GOREVLIYE_YONLENDIRILMIS = "DDUR04";
        public static string DAIRE_DURUM_DAIRE_YETKILI_ONAYI_BEKLENIYOR = "DDUR01";
        public static string DAIRE_DURUM_DAIRE_YETKILI_IADESI_BEKLENIYOR = "DDUR02";
        public static string DAIRE_DURUM_DAIRE_YETKILISI_ONAYLADI = "DDUR05";
        public static string DAIRE_DURUM_DAIRE_YETKILISI_IADE_ETTI = "DDUR06";
        public static string DAIRE_DURUM_DAIRE_YETKILISI_ONAY_IADE_BEKLENIYOR = "DDUR07";

        public static string LOG_BASVURU_EKLE = "Basvuru Ekleme";
        public static string LOG_BASVURU_YONLENDIR = "Basvuru Daireye Yönlendirme";
        public static string LOG_BASVURU_KAPATMA = "Basvuru Kapatma";
        public static string LOG_BEB_ONAYLAMA = "BEB Onaylama";
        public static string LOG_BEB_YENIDENONAYLAMA = "BEB Yeniden Onaylama";
        public static string LOG_BEB_YENIDENIADE = "BEB Yeniden İade";
        public static string LOG_BEB_IADE = "BEB İade";
        public static string LOG_BEB_UZMAN_YONLENDIRME = "Beb Uzmana Yönlendirme";
        public static string LOG_BEB_UZMAN_ONAYA_GONDER = "Beb Uzman Onaya Gonderme";
        public static string LOG_BEB_UZMAN_IADEYE_GONDER = "Beb Uzman İadeye Gonderme";
        public static string LOG_ICERIK_ARA = "Başvuru İçerik Arama";
        public static string LOG_DOSYA_EKLE = "Dosya Ekleme";
        public static string LOG_DOSYA_SIL = "Dosya Silme";
        public static string LOG_DOSYA_GORUNTULE = "Dosya Görüntüleme";
        public static string LOG_DBSYONETIM_GORUNTULE = "DBS Yönetim Ekranı Görüntüleme";
        public static string LOG_BEBYONETIM_GORUNTULE = "BEB Yönetim Ekranı Görüntüleme";
        public static string LOG_UZMANYONETIM_GORUNTULE = "Uzman Yönetim Ekranı Görüntüleme";
        public static string LOG_BASVURUDETAY_GORUNTULE = "Basvuru Detay Ekranı Görüntüleme";
        public static string LOG_DBSDETAY_GORUNTULE = "DBS Detay Ekranı Görüntüleme";
        public static string LOG_FARKLIUZMANDETAY_GORUNTULE = "Uzman Farkli Detay Ekranı Görüntüleme";
        public static string LOG_UZMANDETAY_GORUNTULE = "Uzman Detay Ekranı Görüntüleme";
        public static string LOG_BEB_GUNCELLEME = "BEB Giriş Bilgileri Güncelleme";
        public static string LOG_GECIKME_RAPORU = "BEB Gecikme Raporu Görüntüleme";
        public static string LOG_BIRIMBAZLI_RAPORU = "BEB Birim Bazlı Rapor Görüntüleme";
        public static string LOG_KAYNAKDAG_RAPORU = "BEB Kaynak Dağılım Rapor Görüntüleme";
        public static string LOG_BEBKONU_RAPORU = "BEB Konu Görüntüleme";
        public static string LOG_BEBSONUC_RAPORU = "BEB Sonuç Rapor Görüntüleme";
        public static string LOG_SGOKonu_RAPORU = "BEB SGO Konu Rapor Görüntüleme";
        public static string LOG_BIRIMSUREC_RAPORU = "BEB Birim Süreç Rapor Görüntüleme";
        public static string LOG_KURULGENEL_RAPORU = "BEB Kurul Genel Rapor Görüntüleme";
        public static string LOG_SURESIGECEN_RAPORU = "BEB Süresi Gecen Rapor Görüntüleme";
        public static string LOG_BIRIMBAZLISURESIGECEN_RAPORU = "Bİrim Bazlı BEB Süresi Gecen Rapor Görüntüleme";
        public static string LOG_KIDORTSURE_RAPORU = "Kid Ortalama Süre Rapor Görüntüleme";
        public static string LOG_BEBGENEL_RAPORU = "BEB Genel Rapor Görüntüleme";
        public static string LOG_YETKI_CREATE_SUCCESS = "Yetki Verme İşlemi Başarılı";
        public static string LOG_YETKI_CREATE_ERROR = "Yetki Verme İşlemi Başarısız";
        public static string LOG_YETKI_UPDATE_SUCCESS = "Yetki Güncelleme İşlemi Başarılı";
        public static string LOG_YETKI_UPDATE_ERROR = "Yetki Güncelleme İşlemi Başarısız";
        public static string LOG_YETKI_DELETE_SUCCESS = "Yetki Silme İşlemi Başarılı";
        public static string LOG_YETKI_DELETE_ERROR = "Yetki Silme İşlemi Başarısız";
        //sunay
        public static string LOG_YETKI_SHOW = "Yetkilendirme Ekranı Görüntüleme";
        public static string LOG_KID_PERFORMANS_RAPORU_SHOW = "KİD Performans Raporu Görüntüleme";
        public static string LOG_KID_PERFORMANS_RAPORU_YAPILANISLER_DETAY_SHOW = "KİD Performans Raporu YapilanIsler_Detay ";
        public static string LOG_KID_PERFORMANS_RAPORU_YAPILANISLER_TOPLAM_SHOW = "KİD Performans Raporu YapilanIsler_Toplam";
        public static string LOG_KID_PERFORMANS_RAPORU_YAPILANISLER_SHOW = "KİD Performans Raporu YapilanIsler";
        public static string LOG_KID_PERFORMANS_RAPORU_YAPILANISLER_RAPOR_SHOW = "KİD Performans Raporu YapilanIsler_Rapor";






        public static string bebKanunu = "4982 sayılı Bilgi Edinme Hakkı Kanunu gereğince istediğim bilgi ve belgeler yukarıda belirtilmiştir. Gereğini arz ederim.";
        public static string strAppServer = "";
        public static string strMailSubject = "";

        public static string BEBUyari_Yonlendirme_Bekleyen = "Yönlendirmenizi Bekleyen";
        public static string BEBUyari_Onay_Bekleyen = "Onayınızı Bekleyen";
        public static string BEBUyari_Iade_Bekleyen = "İadenizi Bekleyen";
        public static string BEBUyari_Uzmanda_Bekleyen = "Uzmanda Bekleyen";
        public static string BEBUyari_Tarihi_Gecen = "Yasal Cevap Süresi Dolmuştur";
        public static string BEBUyari_Son_Gun = "Cevaplanması için Son Gün";
        public static string BEBUyari_Son_Uc_Gun = "Cevaplanması için Son Üç Gün";

        public static string DAIRE_AFD = "AFD";
        public static string DAIRE_OFD = "OFD";

        public static string GRUP_BASKANI = "GRUP BAŞKANI";

        public static int WEB_SERVISTEN_GELEN_UZMANDA_BEKLEYEN = 0;
        public static int WEB_SERVISTEN_GELEN_YONLENDIRMENIZI_BEKLEYEN = 1;
        public static int WEB_SERVISTEN_GELEN_ONAYIADE_BEKLEYEN = 2;
        public static int WEB_SERVISTEN_GELEN_YASAL_SURE_DOLMUS = 3;
        public static int WEB_SERVISTEN_GELEN_CEVAPLANMASI_SON_GUN = 4;
        public static int WEB_SERVISTEN_GELEN_CEVAPLANMASI_SON_UC_GUN = 5;
    }


}