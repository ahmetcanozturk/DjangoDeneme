﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Web;

namespace Beb.Models
{
    [Table("BSB_ROL")]
    public class Rol
    {
        [Key]
        //[DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int ROLID { get; set; }
        public string ROLADI { get; set; }

        //public virtual IList<KullaniciRol> KullaniciRol { get; set; }

    }
}