﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Beb.Models
{
    [Table("BSB_BEB")]
    public class Beb
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public decimal BEBID { get; set; }
        [ForeignKey("Sozluk")]
        public string BASVURUTURU { get; set; }
        [ForeignKey("BasvuruTipiBilgisi")]
        public string BASVURUTIPI { get; set; }
        public decimal? BASVURUID { get; set; }
        [ForeignKey("DurumBilgisi")]
        public string DURUM { get; set; }
        public string KAPANISMETNI { get; set; }
        public DateTime? KAPANISTARIHI { get; set; }
        public string KAPATANKULLANICI { get; set; }
        public string ACIKLAMA { get; set; }
        [ForeignKey("KurulIcDisBilgisi")]
        public string KURULICIDISI { get; set; }
        [AllowHtml]
        public string BASVURUCEVAPMAILI { get; set; }
        public string ILGI { get; set; }
        public string KAPATMAACIKLAMASI { get; set; }
        public string KURUMCEVAPMAILI { get; set; }
        public short? KURULILGI { get; set; }
        public string FARKLIKURUMEPOSTA { get; set; }
        //[ForeignKey("BasvuruSonucBilgisi")]
        public int? BASVURUSONUC { get; set; }

        public bool? YONBIT { get; set; }
        public bool? MAILGONDERME { get; set; }

        public string BASVURUSONUCACIKLAMA { get; set; }

        public virtual Basvuru Basvuru { get; set; }
        public virtual Sozluk Sozluk { get; set; }
        public virtual Sozluk DurumBilgisi { get; set; }
        public virtual Sozluk BasvuruTipiBilgisi { get; set; }
        public virtual Sozluk KurulIcDisBilgisi { get; set; }

        //public virtual Sozluk BasvuruSonucBilgisi { get; set; }
        public virtual IList<Dbs> DbsListesi { get; set; }
        //    public virtual Sozluk BasvuruSonucBilgisi { get; set; }

       
    }

    public class UzmanBebList
    {
        public Beb bebBilgi { get; set; }
        public Dbs DbsBilgi { get; set; }
        public DbsGorevli DbsGorevliBilgi { get; set; }
        public DaireDurum DaireDurumBilgi { get; set; }
    }
}