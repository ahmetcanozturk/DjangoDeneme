﻿using Beb.Interfaces;
using Beb.Logger;
using Beb.Models;
using Beb.UOW;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Beb.Filter
{
    public class ExFilter : FilterAttribute, IExceptionFilter
    {
        private IUnitOfWork _uow;
        public void OnException(ExceptionContext filterContext)
        {
             Exception exception = filterContext.Exception;
             filterContext.ExceptionHandled = true;
             _uow = new UnitOfWork();
              MyLogger logger = new MyLogger(_uow.AuditLoggerRepo.GetContext());
             logger.ExceptionLog(HttpContext.Current.Request.RawUrl, exception.GetType().ToString(), exception.Message, exception.StackTrace);
            filterContext.Result = new RedirectResult("/Base/NotFound");
       
        }
    }
}