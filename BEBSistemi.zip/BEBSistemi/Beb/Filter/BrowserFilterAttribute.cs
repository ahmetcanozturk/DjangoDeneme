﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Beb.Filter
{
    public class BrowserFilterAttribute : ActionFilterAttribute
    {
        public string[] _browserNames { get; set; }
        public BrowserFilterAttribute(params string[] browserNames)
        {
            _browserNames = browserNames;
        }

        public override void OnActionExecuting(ActionExecutingContext filterContext)
        {
            string currentBrowser = filterContext.HttpContext.Request.Browser.Browser;
            if (!_browserNames.Contains(currentBrowser))
                filterContext.Result = new RedirectToRouteResult(new System.Web.Routing.RouteValueDictionary(new { action = "InvalidBrowser", controller = "Uyari" }));
        }
    }
}