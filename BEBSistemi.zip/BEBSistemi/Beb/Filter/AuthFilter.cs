﻿using Beb.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.Routing;
using System.Security.Principal;
using System.Web;
using System.Web.Mvc;
using Beb.Interfaces;

using System.Runtime.Remoting.Contexts;

namespace Beb.Filter
{
    public class AuthFilter : AuthorizeAttribute
    {
        public string View { get; set; }

        //public AuthFilter(params string[] roles) : base()
        //{
        //    Roles = string.Join(",", roles);
        //}
        public override void OnAuthorization(AuthorizationContext filterContext)
        {
            if (filterContext.HttpContext.User == null) return;

            IUser _userManager;
            _userManager = new Users.UserManager();
            _userManager.CreateUser();
            List<string> roles = (List<string>)HttpContext.Current.Session["Rol"];
            if (roles.Count() == 0 || roles == null)
                roles.Add("UZMAN");
            if (string.IsNullOrEmpty(filterContext.HttpContext.Request.RawUrl) || filterContext.HttpContext.Request.RawUrl.Equals("/"))
            {
                if (roles.Contains("BEB"))
                {
                    filterContext.Result = new RedirectResult("/Home/BasvuruYonetimi");
                }
                else if (roles.Contains("DENETCI"))
                {
                    filterContext.Result = new RedirectResult("/Base/Raporlama");
                }
                else if (roles.Contains("DBS"))
                {
                    filterContext.Result = new RedirectResult("/Dbs/DbsYonetim");
                }
                else if (roles.Contains("UZMAN"))
                {
                    filterContext.Result = new RedirectResult("/Uzman/UzmanYonetim");
                }
            }
            //else
            //{
            //    foreach (var role in Roles.Split(','))
            //    {
            //        //if (roles.Any(i => i == role))
            //        //{
            //        //    return;
            //        //}
            //        foreach (var kullaniciRole in roles)
            //        {
            //            if (role.Equals(kullaniciRole)) return;
            //        }
            //    }
            //    filterContext.Result = new RedirectResult("/Base/YetkisizErisim");
            //}
            else if (string.Join(",", Roles).Contains(roles.First()))
            {

                return;
            }
            else
            {
                filterContext.Result = new RedirectResult("/Base/YetkisizErisim");

            }

        }
    }
}