﻿using Beb.Models;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.Mvc;

namespace Beb.Filter
{
    public class ActFilter : ActionFilterAttribute
    {

        public override void OnActionExecuting(ActionExecutingContext actionContext)
        {

            //if (actionContext.ActionParameters.ContainsKey("model"))
            //{
            //    Basvuru basvuru = actionContext.ActionParameters["model"] as Basvuru;
            //    Dbs dbs = actionContext.ActionParameters["model"] as Dbs;
            //    DbsGorevli dbsgorevli = actionContext.ActionParameters["model"] as DbsGorevli;
            //    string tagsDaireler = actionContext.ActionParameters["tagsDaireler"] as string;
            //    List<Tag> daireler = JsonConvert.DeserializeObject<List<Tag>>(tagsDaireler);
            //    string DaireIsim = "";
            //    foreach (Tag daire in daireler)
            //    {
            //        DaireIsim += daire.value + " ";
            //    }
            //    BEBDb db = new BEBDb();
            //    db.Log.Add(new Log
            //    {
            //        Islem = actionContext.ActionDescriptor.ActionName =="BasvuruDetay"? "Basvuru Yönlendirme" :"",
            //        IslemYapanId = actionContext.HttpContext.User.Identity.Name,
            //        IslemYapan = actionContext.HttpContext.User.Identity.Name,
            //        BasvuruId = basvuru.BASVURUID,
            //        DbsId = dbs?.DBSID,
            //        DbsGorevliId = dbsgorevli?.DBSGOREVLIID,
            //        Aciklama = DaireIsim != "" ? DaireIsim + "daire(lerine) yönlendirme yapılmıstır." : ""

            //    });
            //    db.SaveChanges();
            //}


        }

        public override void OnActionExecuted(ActionExecutedContext actionExecutedContext)
        {
            // _logger.Log();
            //var isMethodPost = actionExecutedContext.RequestContext.HttpContext.Request.HttpMethod;
            //if (isMethodPost.Equals("GET"))
            //    return;

            //if (actionExecutedContext.Controller.ViewData.ModelState.IsValid)
            //{
            //    Basvuru basvuru = actionExecutedContext.Controller.ViewData.Model as Basvuru;
            //    Dbs dbs = actionExecutedContext.Controller.ViewData.Model as Dbs;
            //    DbsGorevli dbsgorevli = actionExecutedContext.Controller.ViewData.Model as DbsGorevli;


            //    var forms = actionExecutedContext.HttpContext.Request.Form;
            //    string tags = forms["tagsDaireler"] != null ? (forms["tagsDaireler"]) : forms["tagsUzmanlar"] != null ? (forms["tagsUzmanlar"]) : "";

            //    string aciklamaDaireUzman = "";
            //    if (tags != null && tags != "")
            //    {
            //        List<Tag> tagler = JsonConvert.DeserializeObject<List<Tag>>(tags);
            //        foreach (Tag tag in tagler)
            //        {
            //            aciklamaDaireUzman += tag.value + " ";
            //        }
            //    }

            //    BEBDb db = new BEBDb();
            //    string actionName = actionExecutedContext.ActionDescriptor.ActionName;
            //    db.Log.Add(new Log
            //    {
            //        Islem = actionName == "BasvuruDetay" ? OrtakSabitler.LOG_BASVURU_YONLENDIR : actionName == "DBSDetay" ? OrtakSabitler.LOG_BEB_UZMAN_YONLENDIRME :
            //        actionName == "UzmanDetay" ? OrtakSabitler.LOG_BEB_UZMAN_ONAYA_GONDER : actionName == "BasvuruGiris" ? OrtakSabitler.LOG_BASVURU_EKLE :
            //        actionName == "BebKapatma" ? OrtakSabitler.LOG_BASVURU_KAPATMA : actionName == "DbsOnayla" ? OrtakSabitler.LOG_BEB_ONAYLAMA :
            //        actionName == "DbsIadeEt" ? OrtakSabitler.LOG_BEB_IADE : actionName == "UzmanIadeEt" ? OrtakSabitler.LOG_BEB_UZMAN_IADEYE_GONDER : "",
            //        IslemYapanId = actionExecutedContext.HttpContext.User.Identity.Name.Split('\\')[1].ToLowerInvariant(),
            //        IslemYapan = actionExecutedContext.HttpContext.User.Identity.Name.Split('\\')[1].ToLowerInvariant(),
            //        BasvuruId = dbsgorevli != null ? dbsgorevli.Dbs.Beb.BASVURUID : dbs != null ? dbs.Beb.BASVURUID : basvuru?.BASVURUID,
            //        DbsId = dbsgorevli != null ? dbsgorevli.DBSID : dbs?.DBSID,
            //        DbsGorevliId = dbsgorevli?.DBSGOREVLIID,
            //        Aciklama = aciklamaDaireUzman

            //    });
            //    db.SaveChanges();
            //}
            //else
            //{



            //}

        }


    }
}