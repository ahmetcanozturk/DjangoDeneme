﻿using Beb.Models;
using System;
using System.Collections.Generic;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Beb.Interfaces
{
    public interface ILogger
    {
        void Log(string islem, string aciklama, Basvuru basvuru = null, DbsGorevli dbsgorevli = null, Dbs dbs = null);
        void ExceptionLog(string rawUrl, string HataTipi, string HataMesaji, string stackTrace);

        //void Log(T old, U new); 
        Audit GetAudit(DbEntityEntry entry);

         void SetAddedProperties(DbEntityEntry entry, StringBuilder newData);
         void SetDeletedProperties(DbEntityEntry entry, StringBuilder oldData);

         void SetModifiedProperties(DbEntityEntry entry, StringBuilder oldData, StringBuilder newData);

         long? GetKeyValue(DbEntityEntry entry);

         string GetTableName(DbEntityEntry dbEntry);
    }
}
