﻿using Beb.Interfaces;
using Beb.Models;
using Beb.Repository;
using Beb.UOW;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Text;
using System.Web;

namespace Beb.Logger
{
    public class MyLogger : ILogger
    {

        private readonly BEBDb context;
        private IUnitOfWork _uow;
        
        public MyLogger(BEBDb context)
        {
            this.context = context;
            _uow = new UnitOfWork();
           //this.context= _uow.AuditLoggerRepo.GetContext();
        }
        public void ExceptionLog(string rawUrl, string HataTipi, string HataMesaji, string stackTrace)
        {
            IUser userman;
            userman = new Users.UserManager();
            SYN_DomainUsers kullanici = userman.UserInfo();

            HataLog hataLog = new HataLog
            {
                RawURL = rawUrl,
                HataTipi = HataTipi,
                HataMesaji = HataMesaji,
                StackTrace = stackTrace,
                OlusturanKullaniciAdi = kullanici.username,
                OlusturmaTarihi = DateTime.Now
            };
            _uow.HataLogRepo.Insert(hataLog);
        }


        public Audit GetAudit(DbEntityEntry entry)
        {
            var audit = new Audit();
            audit.UserId = HttpContext.Current != null ? HttpContext.Current.User.Identity.Name : "";
            //Change this line according to your needs
            audit.TableName = GetTableName(entry);
            //if (audit.TableName.Contains("_"))
            //    audit.TableName = audit.TableName.Split('_')[0];
            audit.UpdateDate = DateTime.Now;
            audit.TableIdValue = GetKeyValue(entry);

            //entry is Added 
            if (entry.State == EntityState.Added)
            {
                var newValues = new StringBuilder();
                SetAddedProperties(entry, newValues);
                audit.NewData = newValues.ToString();
                audit.Actions = AuditActions.I.ToString();
            }
            //entry in deleted
            else if (entry.State == EntityState.Deleted)
            {
                var oldValues = new StringBuilder();
                SetDeletedProperties(entry, oldValues);
                audit.OldData = oldValues.ToString();
                audit.Actions = AuditActions.D.ToString();
            }
            //entry is modified
            else if (entry.State == EntityState.Modified)
            {
                var oldValues = new StringBuilder();
                var newValues = new StringBuilder();
                SetModifiedProperties(entry, oldValues, newValues);
                audit.OldData = oldValues.ToString();
                audit.NewData = newValues.ToString();
                audit.Actions = AuditActions.U.ToString();
            }

            return audit;
        }

        public long? GetKeyValue(DbEntityEntry entry)
        {
            long id = 0;
            try
            {
                var objectStateEntry =
                    ((IObjectContextAdapter)context).ObjectContext.ObjectStateManager.GetObjectStateEntry(entry.Entity);
                if (objectStateEntry.EntityKey.EntityKeyValues != null)
                    id = Convert.ToInt64(objectStateEntry.EntityKey.EntityKeyValues[0].Value);
            }
            catch (Exception ex)
            {
                return -1;
            }
            return id;
        }

        public string GetTableName(DbEntityEntry dbEntry)
        {
            var tableAttr =
              dbEntry.Entity.GetType().GetCustomAttributes(typeof(TableAttribute), false).SingleOrDefault() as
                  TableAttribute;
            if (tableAttr != null) { 
                return tableAttr.Name;
            }
            else
            {
              return dbEntry.Entity.GetType().Name.Split('_')[0];
             }

            //var tableName = tableAttr != null ? tableAttr.Name : dbEntry.Entity.GetType().Name;
            //return tableName;
        }

        //public void Log(T old, U n)
        //{
        //    throw new NotImplementedException();
        //}

       
        public void Log(string islem, string aciklama, Basvuru basvuru = null, DbsGorevli dbsgorevli = null, Dbs dbs = null)
        {
            IUser userman;
            userman = new Users.UserManager();
            SYN_DomainUsers kullanici = userman.UserInfo(); 
            Log log=new Log {
                Islem = islem.ToString(),
                IslemYapanId = kullanici.username,
                IslemYapan = kullanici.adsoyad,
                BasvuruId = basvuru?.BASVURUID,
                DbsId = dbs?.DBSID,
                DbsGorevliId = dbsgorevli?.DBSGOREVLIID,
                Aciklama = aciklama

            };
            _uow.LogRepo.Insert(log);
          }

        public void SetAddedProperties(DbEntityEntry entry, StringBuilder newData)
        {
            foreach (var propertyName in entry.CurrentValues.PropertyNames)
            {
                var newVal = entry.CurrentValues[propertyName];
                if (newVal != null)
                {
                    newData.AppendFormat("{0}={1} || ", propertyName,
                        newVal);
                }
            }
            if (newData.Length > 0)
                newData = newData.Remove(newData.Length - 3, 3);
        }

        public void SetDeletedProperties(DbEntityEntry entry, StringBuilder oldData)
        {
            var dbValues = entry.GetDatabaseValues();
            foreach (var propertyName in dbValues.PropertyNames)
            {
                var oldVal = dbValues[propertyName];
                if (oldVal != null)
                {
                    oldData.AppendFormat("{0}={1} || ", propertyName,
                        oldVal);
                }
            }
            if (oldData.Length > 0)
                oldData = oldData.Remove(oldData.Length - 3, 3);
        }

        public void SetModifiedProperties(DbEntityEntry entry, StringBuilder oldData, StringBuilder newData)
        {
            var dbValues = entry.GetDatabaseValues();
            foreach (var propertyName in entry.OriginalValues.PropertyNames)
            {
                var oldVal = dbValues[propertyName];
                var newVal = entry.CurrentValues[propertyName];
                if (!Equals(oldVal, newVal))
                {
                    newData.AppendFormat("{0}={1} || ", propertyName, newVal);
                    oldData.AppendFormat("{0}={1} || ", propertyName, oldVal);
                }
            }
            if (oldData.Length > 0)
                oldData = oldData.Remove(oldData.Length - 3, 3);
            if (newData.Length > 0)
                newData = newData.Remove(newData.Length - 3, 3);
        }
        public enum AuditActions
        {
            I,
            U,
            D
        }
    }
}