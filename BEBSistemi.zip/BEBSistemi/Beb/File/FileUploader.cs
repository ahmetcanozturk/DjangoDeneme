﻿using Beb.Interfaces;
using Beb.Models;
using Beb.Repository;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;

namespace Beb.File
{
    public class FileUploader : IFileUploader
    {
        public bool Upload(decimal id, HttpPostedFileBase file, string tur)
        {
            BEBDb db = new BEBDb();
            var ms = new MemoryStream();
            file.InputStream.CopyTo(ms);
            byte[] data = ms.ToArray();



            if (tur.Equals("basvurugiris"))
            {
                Repository<UploadedBasvuruGirisFile> repo = new Repository<UploadedBasvuruGirisFile>(db);
                UploadedBasvuruGirisFile kontrolfile = repo.Find(f => f.filename == file.FileName && f.basvuruid == id);
                if (kontrolfile == null)
                {
                    repo.Insert(new UploadedBasvuruGirisFile
                    {
                        filename = file.FileName,
                        filetype = file.ContentType,
                        basvuruid = id,
                        filecontent = data

                    });

                    return true;
                }
                else
                {
                    return false;
                }
            }
            else
            {
                Repository<UploadedFile> repo = new Repository<UploadedFile>(db);
                UploadedFile kontrolfile = repo.Find(f => f.filename == file.FileName && f.basvuruid == id);
                if (kontrolfile == null)
                {
                    repo.Insert(new UploadedFile
                    {
                        filename = file.FileName,
                        filetype = file.ContentType,
                        basvuruid = id,
                        filecontent = data

                    });

                    return true;
                }
                else
                {
                    return false;
                }

            }
        }
        public bool Delete(decimal id, HttpPostedFileBase file, string tur)
        {
            BEBDb db = new BEBDb();
            if (tur.Equals("basvurugiris"))
            {
                Repository<UploadedBasvuruGirisFile> repo = new Repository<UploadedBasvuruGirisFile>(db);

                UploadedBasvuruGirisFile fileUpload = repo.Find(f => f.filename == file.FileName && f.basvuruid == id);
                if (fileUpload != null)
                {
                    repo.Delete(fileUpload);
                }
            }
            else
            {
                Repository<UploadedFile> repo = new Repository<UploadedFile>(db);

                UploadedFile fileUpload = repo.Find(f => f.filename == file.FileName && f.basvuruid == id);
                if (fileUpload != null)
                {
                    repo.Delete(fileUpload);
                }
            }
            return true;
        }
           
      }
}