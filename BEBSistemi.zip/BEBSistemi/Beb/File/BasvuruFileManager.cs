﻿using Beb.Interfaces;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;

namespace Beb.File
{
    public class BasvuruFileManager : IBasvuruFileManager
    {
        public BasvuruFile CreateFile(decimal id,HttpPostedFileBase file, string viewname)
        {
            var ms = new MemoryStream();
            file.InputStream.CopyTo(ms);
            byte[] data = ms.ToArray();

            BasvuruFile bfile = (new BasvuruFile
            {
                filename = file.FileName,
                filetype = file.ContentType,
                basvuruid = id,
                filecontent = data,
                Tip = viewname == "basvurugiris" ? 0 : 1 
            });
            return bfile;
        }
    }
}