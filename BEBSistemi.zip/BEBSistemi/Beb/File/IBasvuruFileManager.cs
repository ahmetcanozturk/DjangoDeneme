﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web;

namespace Beb.Interfaces
{
    interface IBasvuruFileManager
    {
        BasvuruFile CreateFile(decimal id, HttpPostedFileBase file, string viewname);
    }
}
