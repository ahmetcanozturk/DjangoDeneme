﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web;

namespace Beb.Interfaces
{
    public interface IFileUploader
    {
        bool Upload(decimal id, HttpPostedFileBase file, string tur);

        bool Delete(decimal id, HttpPostedFileBase file, string tur);
    }
}
