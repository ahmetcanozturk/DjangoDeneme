﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Beb.ViewModels.TuzelKisi
{
    public class TuzelKisiListView
    {
        public string Unvan { get; set; }
        public string IhracciTip { get; set; }
        public string MersisNo { get; set; }
        public Guid SirketId { get; set; }
    }
}