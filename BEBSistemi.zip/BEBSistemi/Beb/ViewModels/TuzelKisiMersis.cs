﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Beb.ViewModels
{
    public class TuzelKisiMersis
    {
        public long? ID { get; set; }
        public string MersisNo { get; set; }
        public Guid? SirketID { get; set; }
        public string Unvani { get; set; }
        public string IsletmeAdi { get; set; }
        public string FirmaNeviGrup { get; set; }
        public string TSMNo { get; set; }
        public string SicilNo { get; set; }
        public string VergiNo { get; set; }
        public string EskiMersisNo { get; set; }
        public string Durumu { get; set; }
        public string MerkezMiSubeMi { get; set; }
        public string SubeMerkeziMersisNo { get; set; }
        public string TescilTarihi { get; set; }
        public string IseBaslamaTarihi { get; set; }
        public string KapanisTarihi { get; set; }
        public string VergiDairesi { get; set; }
        public string TSM { get; set; }
        public string TSMIl { get; set; }
        public string Adres { get; set; }
        public string AdresIl { get; set; }
        public string AdresIlce { get; set; }
        public string FirmaDurumTipNo { get; set; }
        public string MKKSicilNo { get; set; }
        public string KEPAdresi { get; set; }




    }
}