﻿
//notification için eklendi.
//var dataexists = '@TempData["message"]'; 
//alert('@TempData["message"]'); 
//alert(dataexists);
//if (dataexists != '') {
//    showNotification("bg-purple", dataexists, "top", "center", null, null);
//    //alert(dataexists);
//}
//var dataexists = '@ViewBag.BasvuruYonlendirildi';

//if (dataexists != '') {
//    showNotification("bg-purple", dataexists, "top", "center", null, null);
//    //alert(dataexists);
//}

function Init(data){
    //alert('test');  
    if (data != '') {
    showNotification("bg-purple", data, "top", "center", null, null);
    }
}

Dropzone.options.frmFileUpload = {
    paramName: "file",
    dictDefaultMessage: "Sürükleyip bırakın veya tıklayın",
    dictRemoveFile: "Dosyayı Sil",
    addRemoveLinks: true,

    init: function () {
        this.on("removedfile", function (file) {

            //alert(file.name);
            var fileData = new FormData();
            fileData.append(file.name, file);
            $.ajax({
                processData: false,
                contentType: false,
                method: "POST",
                url: $("#dosyaSil").attr("data-url"),
                //url: "@Url.Action("DosyaSil", "Base")" + '/' + @(Model ?.BASVURUID ?? 0),
            data: fileData
           })
    }),
            this.on("addedfile", function (file) {
            this.options.url = $("#dosyaSil").attr("data-url2");
            }),
    this.on("error", function (file, response) {
        // do stuff here.
        showNotification("bg-red", "Aynı dosya birden fazla eklenemez.", "top", "center", null, null);
        var errorDisplay = document.querySelectorAll('[data-dz-errormessage]');
        errorDisplay[errorDisplay.length - 1].innerHTML = 'Aynı dosya 2. kez eklendi.';

        //this.removeFile(file);
    })


}
           
      
        };
    function showNotification(colorName, text, placementFrom, placementAlign, animateEnter, animateExit) {
        if (colorName === null || colorName === '') { colorName = 'bg-black'; }
        if (text === null || text === '') { text = 'Turning standard Bootstrap alerts'; }
        if (animateEnter === null || animateEnter === '') { animateEnter = 'animated fadeInDown'; }
        if (animateExit === null || animateExit === '') { animateExit = 'animated fadeOutUp'; }
        var allowDismiss = true;

        $.notify({
            message: text
        },
            {
                type: colorName,
                allow_dismiss: allowDismiss,
                newest_on_top: true,
                timer: 1000,
                placement: {
                    from: placementFrom,
                    align: placementAlign
                },
                animate: {
                    enter: animateEnter,
                    exit: animateExit
                },
                template: '<div data-notify="container" class="bootstrap-notify-container alert alert-dismissible {0} ' + (allowDismiss ? "p-r-35" : "") + '" role="alert">' +
                    '<button type="button" aria-hidden="true" class="close" data-notify="dismiss">×</button>' +
                    '<span data-notify="icon"></span> ' +
                    '<span data-notify="title">{1}</span> ' +
                    '<span data-notify="message">{2}</span>' +
                    '<div class="progress" data-notify="progressbar">' +
                    '<div class="progress-bar progress-bar-{0}" role="progressbar" aria-valuenow="20" aria-valuemin="0" aria-valuemax="100" style="width: 60%"></div>' +
                    '</div>' +
                    '<a href="{3}" target="{4}" data-notify="url"></a>' +
                    '</div>'
            });
    } 
  
   